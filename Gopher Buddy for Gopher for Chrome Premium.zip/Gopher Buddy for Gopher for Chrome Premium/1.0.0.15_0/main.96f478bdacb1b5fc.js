/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 2032:
/*!***************************************************************************!*\
  !*** ./apps/gopher-for-chrome/gopher-buddy/src/app/+state/app.actions.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "initApp": () => (/* binding */ initApp),
/* harmony export */   "loadAppFailure": () => (/* binding */ loadAppFailure),
/* harmony export */   "loadAppSuccess": () => (/* binding */ loadAppSuccess),
/* harmony export */   "syncAppState": () => (/* binding */ syncAppState),
/* harmony export */   "toggleHelp": () => (/* binding */ toggleHelp)
/* harmony export */ });
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ngrx/store */ 3488);

const initApp = (0,_ngrx_store__WEBPACK_IMPORTED_MODULE_0__.createAction)('[App Page] Init');
const syncAppState = (0,_ngrx_store__WEBPACK_IMPORTED_MODULE_0__.createAction)('[App Page] SyncAppState');
const loadAppSuccess = (0,_ngrx_store__WEBPACK_IMPORTED_MODULE_0__.createAction)('[App/API] Load App Success', (0,_ngrx_store__WEBPACK_IMPORTED_MODULE_0__.props)());
const loadAppFailure = (0,_ngrx_store__WEBPACK_IMPORTED_MODULE_0__.createAction)('[App/API] Load App Failure', (0,_ngrx_store__WEBPACK_IMPORTED_MODULE_0__.props)());
const toggleHelp = (0,_ngrx_store__WEBPACK_IMPORTED_MODULE_0__.createAction)('[App Help] Toggle Help', (0,_ngrx_store__WEBPACK_IMPORTED_MODULE_0__.props)());

/***/ }),

/***/ 151:
/*!***************************************************************************!*\
  !*** ./apps/gopher-for-chrome/gopher-buddy/src/app/+state/app.effects.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppEffects": () => (/* binding */ AppEffects)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngrx/effects */ 5405);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 2673);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 745);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 3158);
/* harmony import */ var _app_actions__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app.actions */ 2032);
/* harmony import */ var _services_app_state_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./services/app-state.service */ 9117);







class AppEffects {
  constructor(actions$) {
    this.actions$ = actions$;
    this.appStateService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.inject)(_services_app_state_service__WEBPACK_IMPORTED_MODULE_1__.AppStateService);
    this.zone = (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.inject)(_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgZone); // Inject NgZone
    this.init$ = (0,_ngrx_effects__WEBPACK_IMPORTED_MODULE_3__.createEffect)(() => this.actions$.pipe((0,_ngrx_effects__WEBPACK_IMPORTED_MODULE_3__.ofType)(_ngrx_effects__WEBPACK_IMPORTED_MODULE_3__.ROOT_EFFECTS_INIT), (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.switchMap)(() => this.appStateService.loadState()),
    // Wrap the action dispatch in NgZone.run()
    (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.switchMap)(appState => this.zone.run(() => (0,rxjs__WEBPACK_IMPORTED_MODULE_5__.of)(_app_actions__WEBPACK_IMPORTED_MODULE_0__.loadAppSuccess({
      app: {
        settings: appState
      }
    })))), (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.catchError)(error => this.zone.run(() => (0,rxjs__WEBPACK_IMPORTED_MODULE_5__.of)(_app_actions__WEBPACK_IMPORTED_MODULE_0__.loadAppFailure({
      error: error
    }))) // Also wrap error action
    )));
    this.sync$ = (0,_ngrx_effects__WEBPACK_IMPORTED_MODULE_3__.createEffect)(() => this.actions$.pipe((0,_ngrx_effects__WEBPACK_IMPORTED_MODULE_3__.ofType)(_app_actions__WEBPACK_IMPORTED_MODULE_0__.syncAppState), (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.switchMap)(() => this.appStateService.loadState()),
    // Wrap the action dispatch in NgZone.run()
    (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.switchMap)(appState => this.zone.run(() => (0,rxjs__WEBPACK_IMPORTED_MODULE_5__.of)(_app_actions__WEBPACK_IMPORTED_MODULE_0__.loadAppSuccess({
      app: {
        settings: appState
      }
    })))), (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.catchError)(error => this.zone.run(() => (0,rxjs__WEBPACK_IMPORTED_MODULE_5__.of)(_app_actions__WEBPACK_IMPORTED_MODULE_0__.loadAppFailure({
      error: error
    }))) // Also wrap error action
    )));
  }
  static #_ = this.ɵfac = function AppEffects_Factory(t) {
    return new (t || AppEffects)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_ngrx_effects__WEBPACK_IMPORTED_MODULE_3__.Actions));
  };
  static #_2 = this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjectable"]({
    token: AppEffects,
    factory: AppEffects.ɵfac
  });
}

/***/ }),

/***/ 580:
/*!***************************************************************************!*\
  !*** ./apps/gopher-for-chrome/gopher-buddy/src/app/+state/app.reducer.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "APP_FEATURE_KEY": () => (/* binding */ APP_FEATURE_KEY),
/* harmony export */   "appReducer": () => (/* binding */ appReducer),
/* harmony export */   "initialAppState": () => (/* binding */ initialAppState)
/* harmony export */ });
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ngrx/store */ 3488);
/* harmony import */ var _app_actions__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app.actions */ 2032);


const APP_FEATURE_KEY = 'app';
const initialAppState = {
  loaded: false,
  helpOpen: false
};
const reducer = (0,_ngrx_store__WEBPACK_IMPORTED_MODULE_1__.createReducer)(initialAppState, (0,_ngrx_store__WEBPACK_IMPORTED_MODULE_1__.on)(_app_actions__WEBPACK_IMPORTED_MODULE_0__.initApp, state => ({
  ...state,
  loaded: false,
  error: null
})), (0,_ngrx_store__WEBPACK_IMPORTED_MODULE_1__.on)(_app_actions__WEBPACK_IMPORTED_MODULE_0__.loadAppSuccess, (state, {
  app
}) => ({
  ...app,
  loaded: true,
  helpOpen: state.helpOpen
})), (0,_ngrx_store__WEBPACK_IMPORTED_MODULE_1__.on)(_app_actions__WEBPACK_IMPORTED_MODULE_0__.loadAppFailure, (state, {
  error
}) => ({
  ...state,
  error
})), (0,_ngrx_store__WEBPACK_IMPORTED_MODULE_1__.on)(_app_actions__WEBPACK_IMPORTED_MODULE_0__.toggleHelp, (state, {
  open
}) => ({
  ...state,
  helpOpen: open
})));
function appReducer(state, action) {
  return reducer(state, action);
}

/***/ }),

/***/ 711:
/*!*****************************************************************************!*\
  !*** ./apps/gopher-for-chrome/gopher-buddy/src/app/+state/app.selectors.ts ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getAppError": () => (/* binding */ getAppError),
/* harmony export */   "getAppSettings": () => (/* binding */ getAppSettings),
/* harmony export */   "getHelpState": () => (/* binding */ getHelpState),
/* harmony export */   "isAppLoaded": () => (/* binding */ isAppLoaded),
/* harmony export */   "selectAppState": () => (/* binding */ selectAppState)
/* harmony export */ });
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ngrx/store */ 3488);
/* harmony import */ var _app_reducer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app.reducer */ 580);


// Lookup the 'App' feature state managed by NgRx
const selectAppState = (0,_ngrx_store__WEBPACK_IMPORTED_MODULE_1__.createFeatureSelector)(_app_reducer__WEBPACK_IMPORTED_MODULE_0__.APP_FEATURE_KEY);
const isAppLoaded = (0,_ngrx_store__WEBPACK_IMPORTED_MODULE_1__.createSelector)(selectAppState, state => state.loaded);
const getAppError = (0,_ngrx_store__WEBPACK_IMPORTED_MODULE_1__.createSelector)(selectAppState, state => state.error);
const getAppSettings = (0,_ngrx_store__WEBPACK_IMPORTED_MODULE_1__.createSelector)(selectAppState, state => state.settings);
const getHelpState = (0,_ngrx_store__WEBPACK_IMPORTED_MODULE_1__.createSelector)(selectAppState, state => state.helpOpen);

/***/ }),

/***/ 9117:
/*!******************************************************************************************!*\
  !*** ./apps/gopher-for-chrome/gopher-buddy/src/app/+state/services/app-state.service.ts ***!
  \******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppStateService": () => (/* binding */ AppStateService)
/* harmony export */ });
/* harmony import */ var _background_service_worker_services_message_handler_message_handler_interfaces__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../background-service-worker/services/message-handler/message-handler.interfaces */ 3374);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 2560);


class AppStateService {
  constructor() {
    this.loadState = () => chrome.runtime.sendMessage(_background_service_worker_services_message_handler_message_handler_interfaces__WEBPACK_IMPORTED_MODULE_0__.GBMessages.GET_EXTENSION_STATE);
  }
  static #_ = this.ɵfac = function AppStateService_Factory(t) {
    return new (t || AppStateService)();
  };
  static #_2 = this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({
    token: AppStateService,
    factory: AppStateService.ɵfac,
    providedIn: 'root'
  });
}

/***/ }),

/***/ 5006:
/*!**********************************************************************!*\
  !*** ./apps/gopher-for-chrome/gopher-buddy/src/app/app.component.ts ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppComponent": () => (/* binding */ AppComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ 124);


class AppComponent {
  constructor() {
    this.title = 'gopher-buddy-extension';
  }
  static #_ = this.ɵfac = function AppComponent_Factory(t) {
    return new (t || AppComponent)();
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
    type: AppComponent,
    selectors: [["app-root"]],
    decls: 1,
    vars: 0,
    template: function AppComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "router-outlet");
      }
    },
    dependencies: [_angular_router__WEBPACK_IMPORTED_MODULE_1__.RouterOutlet],
    styles: ["\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 3787:
/*!*******************************************************************!*\
  !*** ./apps/gopher-for-chrome/gopher-buddy/src/app/app.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppModule": () => (/* binding */ AppModule)
/* harmony export */ });
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/platform-browser */ 4497);
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @angular/platform-browser/animations */ 7146);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @ngrx/effects */ 5405);
/* harmony import */ var _ngrx_router_store__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @ngrx/router-store */ 1611);
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @ngrx/store */ 3488);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! rxjs */ 8947);
/* harmony import */ var _state_app_actions__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./+state/app.actions */ 2032);
/* harmony import */ var _state_app_effects__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./+state/app.effects */ 151);
/* harmony import */ var _state_app_reducer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./+state/app.reducer */ 580);
/* harmony import */ var _state_services_app_state_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./+state/services/app-state.service */ 9117);
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./app.component */ 5006);
/* harmony import */ var _app_routes__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./app.routes */ 8147);
/* harmony import */ var _common_components_device_info_device_info_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./common/components/device-info/device-info.component */ 3525);
/* harmony import */ var _common_components_gb_footer_gb_footer_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./common/components/gb-footer/gb-footer.component */ 1538);
/* harmony import */ var _common_components_help_help_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./common/components/help/help.component */ 1186);
/* harmony import */ var _common_external_launcher_launcher_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./common/external/launcher/launcher.component */ 3093);
/* harmony import */ var _common_internal_gb_options_gb_options_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./common/internal/gb-options/gb-options.component */ 7558);
/* harmony import */ var _common_material_material_module_ts_material_material_module__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./common/material/material.module.ts/material/material.module */ 7854);
/* harmony import */ var _common_services_ui_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./common/services/ui.service */ 515);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/core */ 2560);

























class AppModule {
  constructor(appState) {
    this.appState = appState;
    this.appStateSyncTimer$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_13__.timer)(5000, 10 * 1000);
    this.appStateSyncTimer$.subscribe(() => {
      appState.dispatch((0,_state_app_actions__WEBPACK_IMPORTED_MODULE_0__.syncAppState)());
    });
  }
  static #_ = this.ɵfac = function AppModule_Factory(t) {
    return new (t || AppModule)(_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵinject"](_ngrx_store__WEBPACK_IMPORTED_MODULE_15__.Store));
  };
  static #_2 = this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdefineNgModule"]({
    type: AppModule,
    bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_4__.AppComponent]
  });
  static #_3 = this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdefineInjector"]({
    providers: [_state_services_app_state_service__WEBPACK_IMPORTED_MODULE_3__.AppStateService, _common_services_ui_service__WEBPACK_IMPORTED_MODULE_12__.UiService],
    imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_16__.BrowserModule, _angular_router__WEBPACK_IMPORTED_MODULE_17__.RouterModule.forRoot(_app_routes__WEBPACK_IMPORTED_MODULE_5__.appRoutes), _ngrx_store__WEBPACK_IMPORTED_MODULE_15__.StoreModule.forRoot({
      [_state_app_reducer__WEBPACK_IMPORTED_MODULE_2__.APP_FEATURE_KEY]: _state_app_reducer__WEBPACK_IMPORTED_MODULE_2__.appReducer
    }, {
      metaReducers: [],
      runtimeChecks: {
        strictActionImmutability: true,
        strictStateImmutability: true
      }
    }), _ngrx_effects__WEBPACK_IMPORTED_MODULE_18__.EffectsModule.forRoot([_state_app_effects__WEBPACK_IMPORTED_MODULE_1__.AppEffects]), _ngrx_router_store__WEBPACK_IMPORTED_MODULE_19__.StoreRouterConnectingModule.forRoot(), _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_20__.BrowserAnimationsModule, _common_material_material_module_ts_material_material_module__WEBPACK_IMPORTED_MODULE_11__.MaterialModule, _common_components_gb_footer_gb_footer_component__WEBPACK_IMPORTED_MODULE_7__.GbFooterComponent, _common_components_help_help_component__WEBPACK_IMPORTED_MODULE_8__.HelpComponent, _common_components_device_info_device_info_component__WEBPACK_IMPORTED_MODULE_6__.DeviceInfoComponent]
  });
}
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵsetNgModuleScope"](AppModule, {
    declarations: [_app_component__WEBPACK_IMPORTED_MODULE_4__.AppComponent, _common_external_launcher_launcher_component__WEBPACK_IMPORTED_MODULE_9__.LauncherComponent, _common_internal_gb_options_gb_options_component__WEBPACK_IMPORTED_MODULE_10__.GbOptionsComponent],
    imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_16__.BrowserModule, _angular_router__WEBPACK_IMPORTED_MODULE_17__.RouterModule, _ngrx_store__WEBPACK_IMPORTED_MODULE_15__.StoreRootModule, _ngrx_effects__WEBPACK_IMPORTED_MODULE_18__.EffectsRootModule, _ngrx_router_store__WEBPACK_IMPORTED_MODULE_19__.StoreRouterConnectingModule, _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_20__.BrowserAnimationsModule, _common_material_material_module_ts_material_material_module__WEBPACK_IMPORTED_MODULE_11__.MaterialModule, _common_components_gb_footer_gb_footer_component__WEBPACK_IMPORTED_MODULE_7__.GbFooterComponent, _common_components_help_help_component__WEBPACK_IMPORTED_MODULE_8__.HelpComponent, _common_components_device_info_device_info_component__WEBPACK_IMPORTED_MODULE_6__.DeviceInfoComponent]
  });
})();

/***/ }),

/***/ 8147:
/*!*******************************************************************!*\
  !*** ./apps/gopher-for-chrome/gopher-buddy/src/app/app.routes.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "appRoutes": () => (/* binding */ appRoutes)
/* harmony export */ });
/* harmony import */ var _common_external_launcher_launcher_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./common/external/launcher/launcher.component */ 3093);

const appRoutes = [{
  path: '**',
  component: _common_external_launcher_launcher_component__WEBPACK_IMPORTED_MODULE_0__.LauncherComponent
}];

/***/ }),

/***/ 3525:
/*!************************************************************************************************************!*\
  !*** ./apps/gopher-for-chrome/gopher-buddy/src/app/common/components/device-info/device-info.component.ts ***!
  \************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DeviceInfoComponent": () => (/* binding */ DeviceInfoComponent)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _material_material_module_ts_material_material_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../material/material.module.ts/material/material.module */ 7854);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngrx/store */ 3488);
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/material/button */ 4522);
/* harmony import */ var _angular_material_icon__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/material/icon */ 7822);
/* harmony import */ var _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/material/tooltip */ 6896);
/* harmony import */ var _angular_cdk_clipboard__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/cdk/clipboard */ 6079);










function DeviceInfoComponent_div_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 1)(1, "div", 2)(2, "div", 3)(3, "div", 4)(4, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](5, "Model:");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](6, "div", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](8, "button", 6)(9, "mat-icon", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](10, "content_copy");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](11, "div", 3)(12, "div", 4)(13, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](14, "Serial number:");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](15, "div", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](16);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](17, "button", 6)(18, "mat-icon", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](19, "content_copy");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](20, "div", 3)(21, "div", 4)(22, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](23, "Chrome version:");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](24, "div", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](25);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](26, "button", 6)(27, "mat-icon", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](28, "content_copy");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](29, "div", 3)(30, "div", 4)(31, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](32, "Id:");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](33, "div", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](34);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](35, "button", 6)(36, "mat-icon", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](37, "content_copy");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()()()();
  }
  if (rf & 2) {
    const appStateData_r1 = ctx.ngIf;
    let tmp_0_0;
    let tmp_2_0;
    let tmp_3_0;
    let tmp_5_0;
    let tmp_6_0;
    let tmp_8_0;
    let tmp_9_0;
    let tmp_11_0;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("matTooltip", (tmp_0_0 = appStateData_r1.app.settings == null ? null : appStateData_r1.app.settings.deviceDetails == null ? null : appStateData_r1.app.settings.deviceDetails.deviceResource == null ? null : appStateData_r1.app.settings.deviceDetails.deviceResource.model) !== null && tmp_0_0 !== undefined ? tmp_0_0 : "");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", appStateData_r1.app.settings == null ? null : appStateData_r1.app.settings.deviceDetails == null ? null : appStateData_r1.app.settings.deviceDetails.deviceResource == null ? null : appStateData_r1.app.settings.deviceDetails.deviceResource.model, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("cdkCopyToClipboard", (tmp_2_0 = appStateData_r1.app.settings == null ? null : appStateData_r1.app.settings.deviceDetails == null ? null : appStateData_r1.app.settings.deviceDetails.deviceResource == null ? null : appStateData_r1.app.settings.deviceDetails.deviceResource.model) !== null && tmp_2_0 !== undefined ? tmp_2_0 : "");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("matTooltip", (tmp_3_0 = appStateData_r1.app.settings == null ? null : appStateData_r1.app.settings.deviceDetails == null ? null : appStateData_r1.app.settings.deviceDetails.details == null ? null : appStateData_r1.app.settings.deviceDetails.details.serialNumber) !== null && tmp_3_0 !== undefined ? tmp_3_0 : "");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", appStateData_r1.app.settings == null ? null : appStateData_r1.app.settings.deviceDetails == null ? null : appStateData_r1.app.settings.deviceDetails.details == null ? null : appStateData_r1.app.settings.deviceDetails.details.serialNumber, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("cdkCopyToClipboard", (tmp_5_0 = appStateData_r1.app.settings == null ? null : appStateData_r1.app.settings.deviceDetails == null ? null : appStateData_r1.app.settings.deviceDetails.details == null ? null : appStateData_r1.app.settings.deviceDetails.details.serialNumber) !== null && tmp_5_0 !== undefined ? tmp_5_0 : "");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("matTooltip", (tmp_6_0 = appStateData_r1.app.settings == null ? null : appStateData_r1.app.settings.deviceDetails == null ? null : appStateData_r1.app.settings.deviceDetails.details == null ? null : appStateData_r1.app.settings.deviceDetails.details.OSVersion) !== null && tmp_6_0 !== undefined ? tmp_6_0 : "");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", appStateData_r1.app.settings == null ? null : appStateData_r1.app.settings.deviceDetails == null ? null : appStateData_r1.app.settings.deviceDetails.details == null ? null : appStateData_r1.app.settings.deviceDetails.details.OSVersion, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("cdkCopyToClipboard", (tmp_8_0 = appStateData_r1.app.settings == null ? null : appStateData_r1.app.settings.deviceDetails == null ? null : appStateData_r1.app.settings.deviceDetails.details == null ? null : appStateData_r1.app.settings.deviceDetails.details.OSVersion) !== null && tmp_8_0 !== undefined ? tmp_8_0 : "");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("matTooltip", (tmp_9_0 = appStateData_r1.app.settings == null ? null : appStateData_r1.app.settings.deviceDetails == null ? null : appStateData_r1.app.settings.deviceDetails.details == null ? null : appStateData_r1.app.settings.deviceDetails.details.id) !== null && tmp_9_0 !== undefined ? tmp_9_0 : "");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", appStateData_r1.app.settings == null ? null : appStateData_r1.app.settings.deviceDetails == null ? null : appStateData_r1.app.settings.deviceDetails.details == null ? null : appStateData_r1.app.settings.deviceDetails.details.id, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("cdkCopyToClipboard", (tmp_11_0 = appStateData_r1.app.settings == null ? null : appStateData_r1.app.settings.deviceDetails == null ? null : appStateData_r1.app.settings.deviceDetails.details == null ? null : appStateData_r1.app.settings.deviceDetails.details.id) !== null && tmp_11_0 !== undefined ? tmp_11_0 : "");
  }
}
class DeviceInfoComponent {
  constructor(appState) {
    this.appState = appState;
  }
  static #_ = this.ɵfac = function DeviceInfoComponent_Factory(t) {
    return new (t || DeviceInfoComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_ngrx_store__WEBPACK_IMPORTED_MODULE_2__.Store));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
    type: DeviceInfoComponent,
    selectors: [["app-gb-deviceinfo"]],
    standalone: true,
    features: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵStandaloneFeature"]],
    decls: 2,
    vars: 3,
    consts: [["class", "app-bg p-4", 4, "ngIf"], [1, "app-bg", "p-4"], [1, "flex", "flex-col", "gap-y-1"], [1, "flex", "justify-between", "items-end"], [1, "flex", "flex-col"], [1, "font-bold", "truncate", "max-w-[200px]", 3, "matTooltip"], ["mat-icon-button", "", 3, "cdkCopyToClipboard"], [1, "text-base"]],
    template: function DeviceInfoComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](0, DeviceInfoComponent_div_0_Template, 38, 12, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](1, "async");
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](1, 1, ctx.appState));
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule, _angular_common__WEBPACK_IMPORTED_MODULE_3__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_3__.AsyncPipe, _material_material_module_ts_material_material_module__WEBPACK_IMPORTED_MODULE_0__.MaterialModule, _angular_material_button__WEBPACK_IMPORTED_MODULE_4__.MatIconButton, _angular_material_icon__WEBPACK_IMPORTED_MODULE_5__.MatIcon, _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_6__.MatTooltip, _angular_cdk_clipboard__WEBPACK_IMPORTED_MODULE_7__.CdkCopyToClipboard],
    styles: [".app-bg[_ngcontent-%COMP%] {\n  background-color: #f8fafe;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcHMvZ29waGVyLWZvci1jaHJvbWUvZ29waGVyLWJ1ZGR5L3NyYy9hcHAvY29tbW9uL2NvbXBvbmVudHMvZGV2aWNlLWluZm8vZGV2aWNlLWluZm8uY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBRUE7RUFDRSx5QkFBQTtBQURGIiwic291cmNlc0NvbnRlbnQiOlsiQGltcG9ydCAnLi4vLi4vLi4vY29sb3JzL2Nkd19icmFuZF9jb2xvcnMuc2Nzcyc7XG5cbi5hcHAtYmcge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAkc3VwZXItbGlnaHQtZ3JleTtcbn1cbiJdLCJzb3VyY2VSb290IjoiIn0= */"]
  });
}

/***/ }),

/***/ 1538:
/*!********************************************************************************************************!*\
  !*** ./apps/gopher-for-chrome/gopher-buddy/src/app/common/components/gb-footer/gb-footer.component.ts ***!
  \********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GbFooterComponent": () => (/* binding */ GbFooterComponent)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _state_app_actions__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../+state/app.actions */ 2032);
/* harmony import */ var _background_service_worker_services_message_handler_message_handler_interfaces__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../background-service-worker/services/message-handler/message-handler.interfaces */ 3374);
/* harmony import */ var _material_material_module_ts_material_material_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../material/material.module.ts/material/material.module */ 7854);
/* harmony import */ var _services_ui_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/ui.service */ 515);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngrx/store */ 3488);
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/material/button */ 4522);
/* harmony import */ var _angular_material_icon__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/material/icon */ 7822);
/* harmony import */ var _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/material/tooltip */ 6896);













function GbFooterComponent_div_0_button_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "button", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function GbFooterComponent_div_0_button_5_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r4);
      const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵresetView"](ctx_r3.recheckBrowserVersion());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "mat-icon", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](2, "browser_updated");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
  }
}
function GbFooterComponent_div_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r6 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 1)(1, "button", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function GbFooterComponent_div_0_Template_button_click_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r6);
      const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵresetView"](ctx_r5.openFAQ());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "mat-icon", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](3, "help");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](4, "span", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](5, GbFooterComponent_div_0_button_5_Template, 3, 0, "button", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "button", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function GbFooterComponent_div_0_Template_button_click_6_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r6);
      const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵresetView"](ctx_r7.reloadExtension());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](7, "mat-icon", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](8, "restart_alt");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const appState_r1 = ctx.ngIf;
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx_r0.checkVersionEnabled(appState_r1));
  }
}
class GbFooterComponent {
  constructor(uiService, appStore) {
    this.uiService = uiService;
    this.appStore = appStore;
    this.appState = this.appStore;
    this.appSyncing = false;
    this.checkVersionEnabled = appState => appState.app.settings?.customerState.customerSettings?.settings.allowChromeOsUpdateReminders ?? false;
    this.recheckBrowserVersion = () => {
      this.appSyncing = true;
      chrome.runtime.sendMessage(_background_service_worker_services_message_handler_message_handler_interfaces__WEBPACK_IMPORTED_MODULE_1__.GBMessages.CHECK_VERSION, response => {
        this.appSyncing = false;
        const message = response.success ? 'Version check successful' : 'Version check failed';
        this.uiService.showNotification('version_check', message);
      });
    };
    this.resyncExtension = () => {
      this.appSyncing = true;
      chrome.runtime.sendMessage(_background_service_worker_services_message_handler_message_handler_interfaces__WEBPACK_IMPORTED_MODULE_1__.GBMessages.RESYNC_EXTENSION, response => {
        this.appSyncing = false;
        const message = response.success ? 'Resync successful' : 'Resync failed';
        this.uiService.showNotification('resync', message);
      });
    };
    this.reloadExtension = () => {
      chrome.runtime.sendMessage(_background_service_worker_services_message_handler_message_handler_interfaces__WEBPACK_IMPORTED_MODULE_1__.GBMessages.RELOAD_EXTENSION, () => {});
    };
    this.showHelp = appState => {
      this.appStore.dispatch((0,_state_app_actions__WEBPACK_IMPORTED_MODULE_0__.toggleHelp)({
        open: !appState.app.helpOpen
      }));
    };
    this.openFAQ = () => {
      chrome.runtime.sendMessage(_background_service_worker_services_message_handler_message_handler_interfaces__WEBPACK_IMPORTED_MODULE_1__.GBMessages.OPEN_FAQ, () => {});
    };
  }
  static #_ = this.ɵfac = function GbFooterComponent_Factory(t) {
    return new (t || GbFooterComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_services_ui_service__WEBPACK_IMPORTED_MODULE_3__.UiService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_ngrx_store__WEBPACK_IMPORTED_MODULE_5__.Store));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({
    type: GbFooterComponent,
    selectors: [["app-gb-footer"]],
    standalone: true,
    features: [_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵStandaloneFeature"]],
    decls: 2,
    vars: 3,
    consts: [["class", "flex justify-between items-center footer-bg", 4, "ngIf"], [1, "flex", "justify-between", "items-center", "footer-bg"], ["matTooltip", "Get help", "mat-icon-button", "", 3, "click"], [1, "text-white"], [1, "grow"], ["matTooltip", "Recheck browser version", "mat-icon-button", "", 3, "click", 4, "ngIf"], ["matTooltip", "Reload extension", "mat-icon-button", "", 3, "click"], ["matTooltip", "Recheck browser version", "mat-icon-button", "", 3, "click"]],
    template: function GbFooterComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](0, GbFooterComponent_div_0_Template, 9, 1, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](1, "async");
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](1, 1, ctx.appState));
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule, _angular_common__WEBPACK_IMPORTED_MODULE_6__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_6__.AsyncPipe, _material_material_module_ts_material_material_module__WEBPACK_IMPORTED_MODULE_2__.MaterialModule, _angular_material_button__WEBPACK_IMPORTED_MODULE_7__.MatIconButton, _angular_material_icon__WEBPACK_IMPORTED_MODULE_8__.MatIcon, _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_9__.MatTooltip],
    styles: [".footer-bg[_ngcontent-%COMP%] {\n  background-color: #a6192e;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcHMvZ29waGVyLWZvci1jaHJvbWUvZ29waGVyLWJ1ZGR5L3NyYy9hcHAvY29tbW9uL2NvbXBvbmVudHMvZ2ItZm9vdGVyL2diLWZvb3Rlci5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFFQTtFQUNFLHlCQUFBO0FBREYiLCJzb3VyY2VzQ29udGVudCI6WyJAaW1wb3J0ICcuLi8uLi8uLi9jb2xvcnMvY2R3X2JyYW5kX2NvbG9ycy5zY3NzJztcblxuLmZvb3Rlci1iZyB7XG4gIGJhY2tncm91bmQtY29sb3I6ICRkYXJrLXJlZDtcbn1cbiJdLCJzb3VyY2VSb290IjoiIn0= */"]
  });
}

/***/ }),

/***/ 1186:
/*!**********************************************************************************************!*\
  !*** ./apps/gopher-for-chrome/gopher-buddy/src/app/common/components/help/help.component.ts ***!
  \**********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HelpComponent": () => (/* binding */ HelpComponent)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _background_service_worker_services_message_handler_message_handler_interfaces__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../background-service-worker/services/message-handler/message-handler.interfaces */ 3374);
/* harmony import */ var _material_material_module_ts_material_material_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../material/material.module.ts/material/material.module */ 7854);
/* harmony import */ var _services_ui_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/ui.service */ 515);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ngrx/store */ 3488);
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/material/button */ 4522);








class HelpComponent {
  constructor(appStore) {
    this.appStore = appStore;
    this.openFAQ = () => {
      chrome.runtime.sendMessage(_background_service_worker_services_message_handler_message_handler_interfaces__WEBPACK_IMPORTED_MODULE_0__.GBMessages.OPEN_FAQ, () => {});
    };
  }
  static #_ = this.ɵfac = function HelpComponent_Factory(t) {
    return new (t || HelpComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_ngrx_store__WEBPACK_IMPORTED_MODULE_4__.Store));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
    type: HelpComponent,
    selectors: [["app-gb-help"]],
    standalone: true,
    features: [_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵProvidersFeature"]([_services_ui_service__WEBPACK_IMPORTED_MODULE_2__.UiService]), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵStandaloneFeature"]],
    decls: 92,
    vars: 0,
    consts: [[1, "app-bg"], [1, "flex", "flex-col", "justify-center", "items-center", "gap-y-2"], [1, "flex", "flex-col", "h-[250px]", "overflow-y-auto", "gap-y-2"], [1, "flex", "flex-col"], [1, "text-base", "font-bold"], [1, "flex", "flex-col", "mt-2"], [1, "flex", "flex-row", "items-center", "gap-x-2"], ["src", "assets/images/help/show-help.png", "alt", "show help icon", 1, "h-[30px]"], [1, "font-bold"], ["src", "assets/images/help/recheck-version.png", "alt", "recheck version icon", 1, "h-[30px]"], ["src", "assets/images/help/reload-extension.png", "alt", "reload extension icon", 1, "h-[30px]"], ["src", "assets/images/help/chrome-update.png", "alt", "chrome update icon", 1, "h-[30px]"], ["src", "assets/images/help/quick-device-info.png", "alt", "quick device info icon", 1, "h-[30px]"], ["src", "assets/images/help/clear-cache.png", "alt", "clear cache button", 1, "h-[30px]"], ["src", "assets/images/help/device-info.png", "alt", "device info button", 1, "h-[30px]"], ["src", "assets/images/help/fix-it.png", "alt", "Fix-it button", 1, "h-[30px]"], ["mat-raised-button", "", "color", "primary", 3, "click"]],
    template: function HelpComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](4, "Gopher Buddy is a tool to help your school keep up-to-date with all of their Chromebooks.");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](5, "div", 3)(6, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](7, "It ");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](8, "strong");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](9, "does");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](10, " let your school:");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](11, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](12, "\u2022 know who is using the Chromebook");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](13, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](14, "\u2022 know when the Chromebook is used");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](15, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](16, "\u2022 notify you if the Chromebook needs updating");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](17, "div", 3)(18, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](19, "It does ");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](20, "strong");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](21, "NOT");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](22, " record:");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](23, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](24, "\u2022 what you type");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](25, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](26, "\u2022 websites you visit");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](27, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](28, "\u2022 images, video or audio");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](29, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](30, "\u2022 the files on your chromebook");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](31, "div", 3)(32, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](33, "What do all the buttons do?");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](34, "div", 5)(35, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](36, "img", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](37, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](38, "Show help");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](39, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](40, "Opens and closes this help page.");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](41, "div", 5)(42, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](43, "img", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](44, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](45, "Recheck Chrome verions");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](46, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](47, "Forces Gopher Buddy to recheck your version of Chrome.");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](48, "div", 5)(49, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](50, "img", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](51, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](52, "Reload Gopher Buddy");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](53, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](54, "Reloads the Gopher Buddy Extension. Use this if the extension is acting odd.");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](55, "div", 5)(56, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](57, "img", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](58, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](59, "Chrome update info");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](60, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](61, "Shows info about the current version of Chrome.");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](62, "div", 5)(63, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](64, "img", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](65, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](66, "Quick device info");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](67, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](68, "Shows a short list of info about this Chromebook");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](69, "div", 5)(70, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](71, "img", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](72, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](73, "Clear cache");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](74, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](75, "Clears the Chromebook's cache. Useful if a website is missbehaving.");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](76, "div", 5)(77, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](78, "img", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](79, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](80, "Device info");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](81, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](82, " Takes you to a Gopher Buddy webapp to see addition information about this Chromebook. This button may be turned off by your school. ");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](83, "div", 5)(84, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](85, "img", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](86, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](87, "Fix it");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](88, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](89, "Opens the settings page in Chrome. Chrome update settings are on this page.");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](90, "button", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function HelpComponent_Template_button_click_90_listener() {
          return ctx.openFAQ();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](91, "Read the faq");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()();
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule, _material_material_module_ts_material_material_module__WEBPACK_IMPORTED_MODULE_1__.MaterialModule, _angular_material_button__WEBPACK_IMPORTED_MODULE_6__.MatButton],
    styles: [".app-bg[_ngcontent-%COMP%] {\n  background-color: #f8fafe;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcHMvZ29waGVyLWZvci1jaHJvbWUvZ29waGVyLWJ1ZGR5L3NyYy9hcHAvY29tbW9uL2NvbXBvbmVudHMvaGVscC9oZWxwLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUVBO0VBQ0UseUJBQUE7QUFERiIsInNvdXJjZXNDb250ZW50IjpbIkBpbXBvcnQgJy4uLy4uLy4uL2NvbG9ycy9jZHdfYnJhbmRfY29sb3JzLnNjc3MnO1xuXG4uYXBwLWJnIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogJHN1cGVyLWxpZ2h0LWdyZXk7XG59XG4iXSwic291cmNlUm9vdCI6IiJ9 */"]
  });
}

/***/ }),

/***/ 3093:
/*!****************************************************************************************************!*\
  !*** ./apps/gopher-for-chrome/gopher-buddy/src/app/common/external/launcher/launcher.component.ts ***!
  \****************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LauncherComponent": () => (/* binding */ LauncherComponent)
/* harmony export */ });
/* harmony import */ var _home_seaston_CDW_cdw_saas_tools_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! rxjs */ 635);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! rxjs */ 8947);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! rxjs */ 9295);
/* harmony import */ var _state_app_actions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../+state/app.actions */ 2032);
/* harmony import */ var _state_app_selectors__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../+state/app.selectors */ 711);
/* harmony import */ var _background_service_worker_services_extension_store_interfaces_extension_store_interfaces__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../background-service-worker/services/extension-store/interfaces/extension-store.interfaces */ 4779);
/* harmony import */ var _background_service_worker_services_message_handler_message_handler_interfaces__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../../background-service-worker/services/message-handler/message-handler.interfaces */ 3374);
/* harmony import */ var _background_service_worker_services_user_profile_user_profile_state__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../../background-service-worker/services/user-profile/user-profile.state */ 892);
/* harmony import */ var _services_ui_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../services/ui.service */ 515);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @ngrx/store */ 3488);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/material/button */ 4522);
/* harmony import */ var _angular_material_icon__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/material/icon */ 7822);
/* harmony import */ var _angular_material_sidenav__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/material/sidenav */ 6643);
/* harmony import */ var _angular_material_tabs__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @angular/material/tabs */ 5892);
/* harmony import */ var _components_gb_footer_gb_footer_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../components/gb-footer/gb-footer.component */ 1538);
/* harmony import */ var _components_help_help_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../components/help/help.component */ 1186);
/* harmony import */ var _components_device_info_device_info_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../components/device-info/device-info.component */ 3525);




// Added take(1) for synchronous state fetch, Subscription


















const _c0 = ["helpDrawer"];
function LauncherComponent_div_5_ng_template_8_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "mat-icon");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1, "system_update_alt");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
}
const _c1 = function (a0) {
  return {
    appStateData: a0
  };
};
function LauncherComponent_div_5_ng_container_9_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementContainer"](0, 20);
  }
  if (rf & 2) {
    const appStateData_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]().ngIf;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]();
    const _r5 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵreference"](13);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngTemplateOutlet", _r5)("ngTemplateOutletContext", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpureFunction1"](2, _c1, appStateData_r13));
  }
}
function LauncherComponent_div_5_ng_container_10_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementContainer"](0, 20);
  }
  if (rf & 2) {
    const appStateData_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"](2).ngIf;
    const ctx_r20 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]();
    const _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵreference"](11);
    const _r9 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵreference"](17);
    const _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵreference"](15);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngTemplateOutlet", ctx_r20.isManaged(appStateData_r13) ? ctx_r20.isValidCustomer(appStateData_r13) ? _r3 : _r9 : _r7)("ngTemplateOutletContext", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpureFunction1"](2, _c1, appStateData_r13));
  }
}
function LauncherComponent_div_5_ng_container_10_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementContainer"](0, 20);
  }
  if (rf & 2) {
    const appStateData_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"](2).ngIf;
    const ctx_r21 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]();
    const _r11 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵreference"](19);
    const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵreference"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngTemplateOutlet", ctx_r21.loadingTimedOut ? _r11 : _r1)("ngTemplateOutletContext", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpureFunction1"](2, _c1, appStateData_r13));
  }
}
function LauncherComponent_div_5_ng_container_10_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](1, LauncherComponent_div_5_ng_container_10_ng_container_1_Template, 1, 4, "ng-container", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](2, LauncherComponent_div_5_ng_container_10_ng_container_2_Template, 1, 4, "ng-container", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const appStateData_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]().ngIf;
    const ctx_r17 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", ctx_r17.isLoaded(appStateData_r13));
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", !ctx_r17.isLoaded(appStateData_r13));
  }
}
function LauncherComponent_div_5_ng_template_12_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "mat-icon");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1, "laptop_chromebook");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
}
function LauncherComponent_div_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 12)(1, "mat-drawer-container", 12)(2, "mat-drawer", 13, 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](4, "app-gb-help");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](5, "mat-drawer-content", 12)(6, "mat-tab-group", 12)(7, "mat-tab", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](8, LauncherComponent_div_5_ng_template_8_Template, 2, 0, "ng-template", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](9, LauncherComponent_div_5_ng_container_9_Template, 1, 4, "ng-container", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](10, LauncherComponent_div_5_ng_container_10_Template, 3, 2, "ng-container", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](11, "mat-tab", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](12, LauncherComponent_div_5_ng_template_12_Template, 2, 0, "ng-template", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](13, "app-gb-deviceinfo");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()()()();
  }
  if (rf & 2) {
    const appStateData_r13 = ctx.ngIf;
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", ctx_r0.hasErrors(appStateData_r13));
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", !ctx_r0.hasErrors(appStateData_r13));
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("disabled", !ctx_r0.isManaged(appStateData_r13));
  }
}
function LauncherComponent_ng_template_8_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](1, "div", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](2, "span", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](3, "Checking In");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
  }
}
function LauncherComponent_ng_template_10_div_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div")(1, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](2, " Checking Chrome version");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](3, "br");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](4, " in Gopher Buddy");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](5, "br");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](6, " is disabled by your admin ");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
  }
}
function LauncherComponent_ng_template_10_div_2_div_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 30)(1, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](2, "Gopher Buddy says");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](3, "div", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](4, "Chrome is up to date!");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](5, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](6, "\u00A0");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](7, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](8, "Last Checked:");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](9, "div", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipe"](11, "date");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const appState_r26 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"](2).appStateData;
    const ctx_r30 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipeBind2"](11, 1, ctx_r30.lastVersionCheck(appState_r26), "short"));
  }
}
function LauncherComponent_ng_template_10_div_2_div_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r34 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 31)(1, "div", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](2, "Chrome needs to update!");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](3, "div", 21)(4, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](5, "Your version:");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](6, "div", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](8, "div", 21)(9, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](10, "Newest version:");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](11, "div", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](12);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](13, "button", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function LauncherComponent_ng_template_10_div_2_div_2_Template_button_click_13_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵrestoreView"](_r34);
      const ctx_r33 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"](3);
      return _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵresetView"](ctx_r33.onFixVersion());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](14, "Fix it");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const appState_r26 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"](2).appStateData;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate"](appState_r26.app.settings == null ? null : appState_r26.app.settings.deviceDetails == null ? null : appState_r26.app.settings.deviceDetails.details.OSVersion);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate"](appState_r26.app.settings == null ? null : appState_r26.app.settings.deviceDetails.deviceResource == null ? null : appState_r26.app.settings.deviceDetails.deviceResource.latestStableVersion);
  }
}
function LauncherComponent_ng_template_10_div_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](1, LauncherComponent_ng_template_10_div_2_div_1_Template, 12, 4, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](2, LauncherComponent_ng_template_10_div_2_div_2_Template, 15, 2, "div", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const appState_r26 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]().appStateData;
    const ctx_r28 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", ctx_r28.versionIsCurrent(appState_r26));
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", !ctx_r28.versionIsCurrent(appState_r26));
  }
}
function LauncherComponent_ng_template_10_div_7_Template(rf, ctx) {
  if (rf & 1) {
    const _r38 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 2)(1, "button", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function LauncherComponent_ng_template_10_div_7_Template_button_click_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵrestoreView"](_r38);
      const ctx_r37 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵresetView"](ctx_r37.openDeviceDetails());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](2, "Device info");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
  }
}
function LauncherComponent_ng_template_10_Template(rf, ctx) {
  if (rf & 1) {
    const _r40 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](1, LauncherComponent_ng_template_10_div_1_Template, 7, 0, "div", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](2, LauncherComponent_ng_template_10_div_2_Template, 3, 2, "div", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](3, "div", 25)(4, "div", 2)(5, "button", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function LauncherComponent_ng_template_10_Template_button_click_5_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵrestoreView"](_r40);
      const ctx_r39 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵresetView"](ctx_r39.clearCache());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](6, "Clear cache");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](7, LauncherComponent_ng_template_10_div_7_Template, 3, 0, "div", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const appState_r26 = ctx.appStateData;
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", !ctx_r4.checkVersionEnabled(appState_r26));
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", ctx_r4.checkVersionEnabled(appState_r26));
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("disabled", ctx_r4.cacheClearing);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", ctx_r4.hasDeviceInfoAccess(appState_r26));
  }
}
function LauncherComponent_ng_template_12_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 30)(1, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](2, "Error loading Gopher Buddy ");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](3, "strong");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](4, ":(");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](5, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](6, "We'll keep trying...");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](7, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](8, "\u00A0");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](9, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](10, "If you continue to see this message,");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](11, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](12, "contact your school's computer support");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](13, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](14, "and let them know.");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
  }
}
function LauncherComponent_ng_template_14_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 21)(1, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](2, "Gopher Buddy is an admin tool for");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](3, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](4, "managed Chromebooks on");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](5, "div", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](7, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](8, "\u00A0");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](9, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](10, "It performs no actions on Chrome browsers.");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const appState_r42 = ctx.appStateData;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate"](appState_r42.app.settings == null ? null : appState_r42.app.settings.userProfile.userProfile.domain);
  }
}
function LauncherComponent_ng_template_16_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 21)(1, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](2, "Gopher Buddy is still trying to check-in.");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](3, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](4, "Go ahead and close this window");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](5, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](6, "and check back in a few minutes");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
  }
}
function LauncherComponent_ng_template_18_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 21)(1, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](2, "Gopher Buddy is still trying to check-in.");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](3, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](4, "Go ahead and close this window");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](5, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](6, "and check back in a few minutes");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
  }
}
// Added OnInit, OnDestroy
class LauncherComponent {
  constructor(appState, uiService, cdr // Injected ChangeDetectorRef
  ) {
    this.appState = appState;
    this.uiService = uiService;
    this.cdr = cdr;
    this.cacheClearing = false;
    this.loadingTimedOut = false; // Added timeout flag
    this.isCheckedIn = appState => appState.app.settings?.checkInState.status === _background_service_worker_services_extension_store_interfaces_extension_store_interfaces__WEBPACK_IMPORTED_MODULE_3__.StateStatus.SUCCESS;
    this.isLoaded = appState => appState.app.settings?.globalAppFlagsState.isLoaded === true;
    this.isValidCustomer = appState => appState.app.settings?.checkInState.isCustomerValid ?? false;
    this.isManaged = appState => appState.app.settings?.globalAppFlagsState.deviceManagedState === _background_service_worker_services_extension_store_interfaces_extension_store_interfaces__WEBPACK_IMPORTED_MODULE_3__.DeviceManagedState.MANAGED;
    this.hasErrors = appState => appState.app.settings?.checkInState.status === _background_service_worker_services_extension_store_interfaces_extension_store_interfaces__WEBPACK_IMPORTED_MODULE_3__.StateStatus.FAILED;
    this.hasDeviceInfoAccess = appState => appState.app.settings?.userProfile.userProfile?.accessLevel === _background_service_worker_services_user_profile_user_profile_state__WEBPACK_IMPORTED_MODULE_5__.UserAccessType.BASIC || appState.app.settings?.userProfile.userProfile?.accessLevel === _background_service_worker_services_user_profile_user_profile_state__WEBPACK_IMPORTED_MODULE_5__.UserAccessType.FULL;
    this.checkVersionEnabled = appState => appState.app.settings?.customerState.customerSettings?.settings.allowChromeOsUpdateReminders ?? false;
    this.versionIsCurrent = appState => appState.app.settings?.versionUpdateState.updateNeeded === false;
    this.lastVersionCheck = appState => new Date(appState.app.settings?.checkInState.lastCheckIn ?? Date.now());
    this.clearCache = () => {
      this.cacheClearing = true;
      chrome.runtime.sendMessage(_background_service_worker_services_message_handler_message_handler_interfaces__WEBPACK_IMPORTED_MODULE_4__.GBMessages.CLEAR_CACHE, response => {
        this.cacheClearing = false;
        const message = response.success ? 'Your device cache has successfully been cleared.' : 'Your device cache failed to clear';
        this.uiService.showNotification('clear_cache', message);
        this.cdr.detectChanges(); // Trigger change detection after async operation
      });
    };
    this.openDeviceDetails = () => {
      chrome.runtime.sendMessage(_background_service_worker_services_message_handler_message_handler_interfaces__WEBPACK_IMPORTED_MODULE_4__.GBMessages.OPEN_DEVICE_INFO, () => {});
    };
    this.openUpdateHelp = () => {
      chrome.runtime.sendMessage(_background_service_worker_services_message_handler_message_handler_interfaces__WEBPACK_IMPORTED_MODULE_4__.GBMessages.OPEN_HELP, () => {});
    };
    this.onFixVersion = () => {
      chrome.runtime.sendMessage(_background_service_worker_services_message_handler_message_handler_interfaces__WEBPACK_IMPORTED_MODULE_4__.GBMessages.FIX_VERSION, () => {});
    };
    this.appState$ = appState.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_11__.map)(gbAppState => gbAppState));
  }
  ngOnInit() {
    // Added OnInit
    // Start the loading timeout timer (3 minutes = 180,000 ms)
    this.loadingTimeoutSubscription = (0,rxjs__WEBPACK_IMPORTED_MODULE_12__.timer)(180000).subscribe(() => {
      // Use take(1) to get the current state synchronously and complete
      this.appState.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_13__.take)(1)).subscribe(currentState => {
        if (!this.isLoaded(currentState)) {
          this.loadingTimedOut = true;
          this.cdr.detectChanges(); //
        }
      });
    });
  }
  ngOnDestroy() {
    // Added OnDestroy
    // Clean up subscriptions
    if (this.helpStateSubscription) {
      this.helpStateSubscription.unsubscribe();
    }
    if (this.loadingTimeoutSubscription) {
      this.loadingTimeoutSubscription.unsubscribe();
    }
  }
  ngAfterViewInit() {
    var _this = this;
    // Store subscription for cleanup
    this.helpStateSubscription = this.appState.select(_state_app_selectors__WEBPACK_IMPORTED_MODULE_2__.getHelpState).subscribe( /*#__PURE__*/function () {
      var _ref = (0,_home_seaston_CDW_cdw_saas_tools_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (helpState) {
        if (!_this.helpDrawer) return; // Guard against potential timing issues
        if (helpState) {
          yield _this.helpDrawer.open();
          return;
        }
        yield _this.helpDrawer.close();
      });
      return function (_x) {
        return _ref.apply(this, arguments);
      };
    }());
    // If the user closes the infoDrawer mark all toggle-able Panels as closed.
    // Ensure helpDrawer exists before subscribing
    if (this.helpDrawer) {
      this.helpDrawer.openedChange.subscribe(isOpen => {
        if (!isOpen) {
          this.appState.dispatch((0,_state_app_actions__WEBPACK_IMPORTED_MODULE_1__.toggleHelp)({
            open: false
          }));
        }
      });
    }
  }
  static #_ = this.ɵfac = function LauncherComponent_Factory(t) {
    return new (t || LauncherComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](_ngrx_store__WEBPACK_IMPORTED_MODULE_14__.Store), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](_services_ui_service__WEBPACK_IMPORTED_MODULE_6__.UiService), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_10__.ChangeDetectorRef));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdefineComponent"]({
    type: LauncherComponent,
    selectors: [["app-launcher"]],
    viewQuery: function LauncherComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵviewQuery"](_c0, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵloadQuery"]()) && (ctx.helpDrawer = _t.first);
      }
    },
    decls: 20,
    vars: 3,
    consts: [[1, "w-80", "min-h-[485px]", "flex", "flex-col", "rounded-md"], [1, "flex", "flex-col", "grow"], [1, "flex", "justify-center", "items-center"], [1, "flex", "flex-col", "items-center"], ["src", "assets/images/gopher_buddy_logo.png", "alt", "Gopher Buddy Logo", 1, "h-[100px]"], ["class", "!flex flex-col grow", 4, "ngIf"], ["LoadingPanel", ""], ["ValidCustomerPanel", ""], ["ErrorPanel", ""], ["NotManagedPanel", ""], ["NotValidCustomerPanel", ""], ["LoadingTimeoutPanel", ""], [1, "!flex", "flex-col", "grow"], ["mode", "over", "position", "end", 1, "w-[300px]", "p-2"], ["helpDrawer", ""], ["label", "Chrome update info"], ["mat-tab-label", ""], [3, "ngTemplateOutlet", "ngTemplateOutletContext", 4, "ngIf"], [4, "ngIf"], ["label", "Your device info", 3, "disabled"], [3, "ngTemplateOutlet", "ngTemplateOutletContext"], [1, "flex", "flex-col", "justify-center", "items-center"], [1, "animate-spin", "rounded-full", "h-12", "w-12", "border-t-2", "border-b-2", "border-gray-600"], [1, "font-bold"], [1, "flex", "flex-col", "flex-justify-center", "items-center"], [1, "flex", "justify-center", "items-center", "gap-x-2"], ["mat-raised-button", "", 3, "disabled", "click"], ["class", "flex justify-center items-center", 4, "ngIf"], ["class", "flex flex-col justify-center items-center text-base", 4, "ngIf"], ["class", "flex flex-col justify-center items-center gap-y-1 text-base", 4, "ngIf"], [1, "flex", "flex-col", "justify-center", "items-center", "text-base"], [1, "flex", "flex-col", "justify-center", "items-center", "gap-y-1", "text-base"], ["mat-raised-button", "", "color", "primary", 1, "w-full", 3, "click"], ["mat-raised-button", "", 3, "click"]],
    template: function LauncherComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](4, "img", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](5, LauncherComponent_div_5_Template, 14, 3, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipe"](6, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](7, "app-gb-footer");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](8, LauncherComponent_ng_template_8_Template, 4, 0, "ng-template", null, 6, _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplateRefExtractor"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](10, LauncherComponent_ng_template_10_Template, 8, 4, "ng-template", null, 7, _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplateRefExtractor"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](12, LauncherComponent_ng_template_12_Template, 15, 0, "ng-template", null, 8, _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplateRefExtractor"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](14, LauncherComponent_ng_template_14_Template, 11, 1, "ng-template", null, 9, _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplateRefExtractor"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](16, LauncherComponent_ng_template_16_Template, 7, 0, "ng-template", null, 10, _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplateRefExtractor"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](18, LauncherComponent_ng_template_18_Template, 7, 0, "ng-template", null, 11, _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplateRefExtractor"]);
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipeBind1"](6, 1, ctx.appState$));
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_15__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_15__.NgTemplateOutlet, _angular_material_button__WEBPACK_IMPORTED_MODULE_16__.MatButton, _angular_material_icon__WEBPACK_IMPORTED_MODULE_17__.MatIcon, _angular_material_sidenav__WEBPACK_IMPORTED_MODULE_18__.MatDrawer, _angular_material_sidenav__WEBPACK_IMPORTED_MODULE_18__.MatDrawerContainer, _angular_material_sidenav__WEBPACK_IMPORTED_MODULE_18__.MatDrawerContent, _angular_material_tabs__WEBPACK_IMPORTED_MODULE_19__.MatTabLabel, _angular_material_tabs__WEBPACK_IMPORTED_MODULE_19__.MatTab, _angular_material_tabs__WEBPACK_IMPORTED_MODULE_19__.MatTabGroup, _components_gb_footer_gb_footer_component__WEBPACK_IMPORTED_MODULE_7__.GbFooterComponent, _components_help_help_component__WEBPACK_IMPORTED_MODULE_8__.HelpComponent, _components_device_info_device_info_component__WEBPACK_IMPORTED_MODULE_9__.DeviceInfoComponent, _angular_common__WEBPACK_IMPORTED_MODULE_15__.AsyncPipe, _angular_common__WEBPACK_IMPORTED_MODULE_15__.DatePipe],
    styles: [".mat-mdc-tab-body-wrapper {\n  flex-grow: 1;\n}\n\n  .mat-mdc-tab-body-content {\n  display: flex;\n  flex-direction: column;\n  justify-content: space-around;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcHMvZ29waGVyLWZvci1jaHJvbWUvZ29waGVyLWJ1ZGR5L3NyYy9hcHAvY29tbW9uL2V4dGVybmFsL2xhdW5jaGVyL2xhdW5jaGVyLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUVBO0VBQ0UsWUFBQTtBQURGOztBQUlBO0VBQ0UsYUFBQTtFQUNBLHNCQUFBO0VBQ0EsNkJBQUE7QUFERiIsInNvdXJjZXNDb250ZW50IjpbIkBpbXBvcnQgJy4uLy4uLy4uL2NvbG9ycy9jZHdfYnJhbmRfY29sb3JzLnNjc3MnO1xuXG46Om5nLWRlZXAgLm1hdC1tZGMtdGFiLWJvZHktd3JhcHBlciB7XG4gIGZsZXgtZ3JvdzogMTtcbn1cblxuOjpuZy1kZWVwIC5tYXQtbWRjLXRhYi1ib2R5LWNvbnRlbnQge1xuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWFyb3VuZDtcbn1cbiJdLCJzb3VyY2VSb290IjoiIn0= */"]
  });
}

/***/ }),

/***/ 7558:
/*!********************************************************************************************************!*\
  !*** ./apps/gopher-for-chrome/gopher-buddy/src/app/common/internal/gb-options/gb-options.component.ts ***!
  \********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GbOptionsComponent": () => (/* binding */ GbOptionsComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 2560);

class GbOptionsComponent {
  static #_ = this.ɵfac = function GbOptionsComponent_Factory(t) {
    return new (t || GbOptionsComponent)();
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
    type: GbOptionsComponent,
    selectors: [["app-gb-options"]],
    decls: 2,
    vars: 0,
    template: function GbOptionsComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "Maybe in the Future we will add a logged in settings page.");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }
    },
    styles: ["[_nghost-%COMP%] {\n  display: block;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcHMvZ29waGVyLWZvci1jaHJvbWUvZ29waGVyLWJ1ZGR5L3NyYy9hcHAvY29tbW9uL2ludGVybmFsL2diLW9wdGlvbnMvZ2Itb3B0aW9ucy5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGNBQUE7QUFDRiIsInNvdXJjZXNDb250ZW50IjpbIjpob3N0IHtcbiAgZGlzcGxheTogYmxvY2s7XG59XG4iXSwic291cmNlUm9vdCI6IiJ9 */"],
    changeDetection: 0
  });
}

/***/ }),

/***/ 7854:
/*!********************************************************************************************************************!*\
  !*** ./apps/gopher-for-chrome/gopher-buddy/src/app/common/material/material.module.ts/material/material.module.ts ***!
  \********************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MaterialModule": () => (/* binding */ MaterialModule)
/* harmony export */ });
/* harmony import */ var _angular_cdk_clipboard__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/cdk/clipboard */ 6079);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/material/button */ 4522);
/* harmony import */ var _angular_material_icon__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/material/icon */ 7822);
/* harmony import */ var _angular_material_sidenav__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/material/sidenav */ 6643);
/* harmony import */ var _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material/snack-bar */ 930);
/* harmony import */ var _angular_material_tabs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/material/tabs */ 5892);
/* harmony import */ var _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/material/tooltip */ 6896);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 2560);









class MaterialModule {
  static #_ = this.ɵfac = function MaterialModule_Factory(t) {
    return new (t || MaterialModule)();
  };
  static #_2 = this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({
    type: MaterialModule
  });
  static #_3 = this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__.CommonModule, _angular_material_button__WEBPACK_IMPORTED_MODULE_2__.MatButtonModule, _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_3__.MatSnackBarModule, _angular_material_icon__WEBPACK_IMPORTED_MODULE_4__.MatIconModule, _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_5__.MatTooltipModule, _angular_material_sidenav__WEBPACK_IMPORTED_MODULE_6__.MatSidenavModule, _angular_material_tabs__WEBPACK_IMPORTED_MODULE_7__.MatTabsModule, _angular_cdk_clipboard__WEBPACK_IMPORTED_MODULE_8__.ClipboardModule, _angular_material_button__WEBPACK_IMPORTED_MODULE_2__.MatButtonModule, _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_3__.MatSnackBarModule, _angular_material_icon__WEBPACK_IMPORTED_MODULE_4__.MatIconModule, _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_5__.MatTooltipModule, _angular_material_sidenav__WEBPACK_IMPORTED_MODULE_6__.MatSidenavModule, _angular_material_tabs__WEBPACK_IMPORTED_MODULE_7__.MatTabsModule, _angular_cdk_clipboard__WEBPACK_IMPORTED_MODULE_8__.ClipboardModule]
  });
}
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsetNgModuleScope"](MaterialModule, {
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__.CommonModule, _angular_material_button__WEBPACK_IMPORTED_MODULE_2__.MatButtonModule, _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_3__.MatSnackBarModule, _angular_material_icon__WEBPACK_IMPORTED_MODULE_4__.MatIconModule, _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_5__.MatTooltipModule, _angular_material_sidenav__WEBPACK_IMPORTED_MODULE_6__.MatSidenavModule, _angular_material_tabs__WEBPACK_IMPORTED_MODULE_7__.MatTabsModule, _angular_cdk_clipboard__WEBPACK_IMPORTED_MODULE_8__.ClipboardModule],
    exports: [_angular_material_button__WEBPACK_IMPORTED_MODULE_2__.MatButtonModule, _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_3__.MatSnackBarModule, _angular_material_icon__WEBPACK_IMPORTED_MODULE_4__.MatIconModule, _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_5__.MatTooltipModule, _angular_material_sidenav__WEBPACK_IMPORTED_MODULE_6__.MatSidenavModule, _angular_material_tabs__WEBPACK_IMPORTED_MODULE_7__.MatTabsModule, _angular_cdk_clipboard__WEBPACK_IMPORTED_MODULE_8__.ClipboardModule]
  });
})();

/***/ }),

/***/ 515:
/*!***********************************************************************************!*\
  !*** ./apps/gopher-for-chrome/gopher-buddy/src/app/common/services/ui.service.ts ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UiService": () => (/* binding */ UiService)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 2560);

class UiService {
  constructor() {
    this.showNotification = (id, message, title = 'Gopher Buddy') => {
      chrome.notifications.clear(id, () => {});
      chrome.notifications.create(id, {
        message,
        title,
        type: 'basic',
        iconUrl: 'assets/images/gb_default_icon.png'
      }, () => {});
    };
  }
  static #_ = this.ɵfac = function UiService_Factory(t) {
    return new (t || UiService)();
  };
  static #_2 = this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({
    token: UiService,
    factory: UiService.ɵfac,
    providedIn: 'root'
  });
}

/***/ }),

/***/ 4779:
/*!*********************************************************************************************************************************************!*\
  !*** ./apps/gopher-for-chrome/gopher-buddy/src/background-service-worker/services/extension-store/interfaces/extension-store.interfaces.ts ***!
  \*********************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DeviceManagedState": () => (/* binding */ DeviceManagedState),
/* harmony export */   "StateStatus": () => (/* binding */ StateStatus)
/* harmony export */ });
var StateStatus;
(function (StateStatus) {
  StateStatus["IDLE"] = "idle";
  StateStatus["LOADING"] = "loading";
  StateStatus["SUCCESS"] = "success";
  StateStatus["FAILED"] = "failed";
})(StateStatus || (StateStatus = {}));
var DeviceManagedState;
(function (DeviceManagedState) {
  DeviceManagedState["MANAGED"] = "managed";
  DeviceManagedState["NOT_MANAGED"] = "notManaged";
})(DeviceManagedState || (DeviceManagedState = {}));

/***/ }),

/***/ 3374:
/*!**********************************************************************************************************************************!*\
  !*** ./apps/gopher-for-chrome/gopher-buddy/src/background-service-worker/services/message-handler/message-handler.interfaces.ts ***!
  \**********************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GBMessages": () => (/* binding */ GBMessages)
/* harmony export */ });
var GBMessages;
(function (GBMessages) {
  GBMessages["GET_EXTENSION_STATE"] = "getExtensionState";
  GBMessages["CLEAR_CACHE"] = "clearCache";
  GBMessages["RELOAD_EXTENSION"] = "reloadExtension";
  GBMessages["RESYNC_EXTENSION"] = "resyncExtension";
  GBMessages["OPEN_HELP"] = "openChromeHelp";
  GBMessages["OPEN_DEVICE_INFO"] = "openDeviceInfo";
  GBMessages["CHECK_VERSION"] = "checkVersion";
  GBMessages["FIX_VERSION"] = "fixVersion";
  GBMessages["OPEN_FAQ"] = "openFAQ";
})(GBMessages || (GBMessages = {}));

/***/ }),

/***/ 892:
/*!***********************************************************************************************************************!*\
  !*** ./apps/gopher-for-chrome/gopher-buddy/src/background-service-worker/services/user-profile/user-profile.state.ts ***!
  \***********************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UserAccessType": () => (/* binding */ UserAccessType),
/* harmony export */   "UserProfileEffects": () => (/* binding */ UserProfileEffects),
/* harmony export */   "UserProfileState": () => (/* binding */ UserProfileState),
/* harmony export */   "getUserProfile": () => (/* binding */ getUserProfile),
/* harmony export */   "setDomain": () => (/* binding */ setDomain),
/* harmony export */   "setEmail": () => (/* binding */ setEmail),
/* harmony export */   "setId": () => (/* binding */ setId),
/* harmony export */   "setProfileDetails": () => (/* binding */ setProfileDetails),
/* harmony export */   "setUserAccessLevel": () => (/* binding */ setUserAccessLevel),
/* harmony export */   "setUserJWT": () => (/* binding */ setUserJWT)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @reduxjs/toolkit */ 3869);
/* harmony import */ var _extension_store_interfaces_extension_store_interfaces__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../extension-store/interfaces/extension-store.interfaces */ 4779);


var UserAccessType;
(function (UserAccessType) {
  UserAccessType["NONE"] = "none";
  UserAccessType["BASIC"] = "basic";
  UserAccessType["FULL"] = "full";
})(UserAccessType || (UserAccessType = {}));
const initialState = {
  error: null,
  status: _extension_store_interfaces_extension_store_interfaces__WEBPACK_IMPORTED_MODULE_0__.StateStatus.IDLE,
  userProfile: {
    email: '',
    id: '',
    domain: '',
    accessLevel: UserAccessType.NONE
  }
};
const UserProfileEffects = {
  fetchUserProfile: () => {
    console.log('fetchUserProfile');
  }
};
const UserProfileState = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__.createSlice)({
  name: 'UserProfileReducer',
  initialState,
  reducers: {
    setProfileDetails: (mutableState, action) => {
      mutableState.userProfile.accessLevel = action.payload.accessLevel;
      mutableState.userProfile.userOrgUnitPath = action.payload.userOrgUnitPath;
      mutableState.userProfile.userJWT = action.payload.userJWT;
      mutableState.status = _extension_store_interfaces_extension_store_interfaces__WEBPACK_IMPORTED_MODULE_0__.StateStatus.SUCCESS;
    },
    setEmail: (mutableState, action) => {
      mutableState.userProfile.email = action.payload;
    },
    setId: (mutableState, action) => {
      mutableState.userProfile.id = action.payload;
    },
    setDomain: (mutableState, action) => {
      mutableState.userProfile.domain = action.payload;
    },
    setUserAccessLevel: (mutableState, action) => {
      mutableState.userProfile.accessLevel = action.payload;
    },
    setUserJWT: (mutableState, action) => {
      mutableState.userProfile.userJWT = action.payload;
    }
  }
});
const {
  setEmail,
  setId,
  setDomain,
  setUserAccessLevel,
  setUserJWT,
  setProfileDetails
} = UserProfileState.actions;
const getUserProfile = state => state.userProfile;

/***/ }),

/***/ 7218:
/*!*********************************************************!*\
  !*** ./apps/gopher-for-chrome/gopher-buddy/src/main.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser */ 4497);
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app/app.module */ 3787);


_angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__.platformBrowser().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_0__.AppModule).catch(err => console.error(err));

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = __webpack_modules__;
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/chunk loaded */
/******/ 	(() => {
/******/ 		var deferred = [];
/******/ 		__webpack_require__.O = (result, chunkIds, fn, priority) => {
/******/ 			if(chunkIds) {
/******/ 				priority = priority || 0;
/******/ 				for(var i = deferred.length; i > 0 && deferred[i - 1][2] > priority; i--) deferred[i] = deferred[i - 1];
/******/ 				deferred[i] = [chunkIds, fn, priority];
/******/ 				return;
/******/ 			}
/******/ 			var notFulfilled = Infinity;
/******/ 			for (var i = 0; i < deferred.length; i++) {
/******/ 				var [chunkIds, fn, priority] = deferred[i];
/******/ 				var fulfilled = true;
/******/ 				for (var j = 0; j < chunkIds.length; j++) {
/******/ 					if ((priority & 1 === 0 || notFulfilled >= priority) && Object.keys(__webpack_require__.O).every((key) => (__webpack_require__.O[key](chunkIds[j])))) {
/******/ 						chunkIds.splice(j--, 1);
/******/ 					} else {
/******/ 						fulfilled = false;
/******/ 						if(priority < notFulfilled) notFulfilled = priority;
/******/ 					}
/******/ 				}
/******/ 				if(fulfilled) {
/******/ 					deferred.splice(i--, 1)
/******/ 					var r = fn();
/******/ 					if (r !== undefined) result = r;
/******/ 				}
/******/ 			}
/******/ 			return result;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/jsonp chunk loading */
/******/ 	(() => {
/******/ 		// no baseURI
/******/ 		
/******/ 		// object to store loaded and loading chunks
/******/ 		// undefined = chunk not loaded, null = chunk preloaded/prefetched
/******/ 		// [resolve, reject, Promise] = chunk loading, 0 = chunk loaded
/******/ 		var installedChunks = {
/******/ 			"main": 0
/******/ 		};
/******/ 		
/******/ 		// no chunk on demand loading
/******/ 		
/******/ 		// no prefetching
/******/ 		
/******/ 		// no preloaded
/******/ 		
/******/ 		// no HMR
/******/ 		
/******/ 		// no HMR manifest
/******/ 		
/******/ 		__webpack_require__.O.j = (chunkId) => (installedChunks[chunkId] === 0);
/******/ 		
/******/ 		// install a JSONP callback for chunk loading
/******/ 		var webpackJsonpCallback = (parentChunkLoadingFunction, data) => {
/******/ 			var [chunkIds, moreModules, runtime] = data;
/******/ 			// add "moreModules" to the modules object,
/******/ 			// then flag all "chunkIds" as loaded and fire callback
/******/ 			var moduleId, chunkId, i = 0;
/******/ 			if(chunkIds.some((id) => (installedChunks[id] !== 0))) {
/******/ 				for(moduleId in moreModules) {
/******/ 					if(__webpack_require__.o(moreModules, moduleId)) {
/******/ 						__webpack_require__.m[moduleId] = moreModules[moduleId];
/******/ 					}
/******/ 				}
/******/ 				if(runtime) var result = runtime(__webpack_require__);
/******/ 			}
/******/ 			if(parentChunkLoadingFunction) parentChunkLoadingFunction(data);
/******/ 			for(;i < chunkIds.length; i++) {
/******/ 				chunkId = chunkIds[i];
/******/ 				if(__webpack_require__.o(installedChunks, chunkId) && installedChunks[chunkId]) {
/******/ 					installedChunks[chunkId][0]();
/******/ 				}
/******/ 				installedChunks[chunkId] = 0;
/******/ 			}
/******/ 			return __webpack_require__.O(result);
/******/ 		}
/******/ 		
/******/ 		var chunkLoadingGlobal = self["webpackChunkgopher_buddy_extension"] = self["webpackChunkgopher_buddy_extension"] || [];
/******/ 		chunkLoadingGlobal.forEach(webpackJsonpCallback.bind(null, 0));
/******/ 		chunkLoadingGlobal.push = webpackJsonpCallback.bind(null, chunkLoadingGlobal.push.bind(chunkLoadingGlobal));
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module depends on other loaded chunks and execution need to be delayed
/******/ 	var __webpack_exports__ = __webpack_require__.O(undefined, ["vendor"], () => (__webpack_require__(7218)))
/******/ 	__webpack_exports__ = __webpack_require__.O(__webpack_exports__);
/******/ 	
/******/ })()
;
//# sourceMappingURL=main.96f478bdacb1b5fc.js.map