/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
var __webpack_exports__ = {};

;// CONCATENATED MODULE: ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
  try {
    var info = gen[key](arg);
    var value = info.value;
  } catch (error) {
    reject(error);
    return;
  }
  if (info.done) {
    resolve(value);
  } else {
    Promise.resolve(value).then(_next, _throw);
  }
}
function asyncToGenerator_asyncToGenerator(fn) {
  return function () {
    var self = this,
      args = arguments;
    return new Promise(function (resolve, reject) {
      var gen = fn.apply(self, args);
      function _next(value) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
      }
      function _throw(err) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
      }
      _next(undefined);
    });
  };
}
;// CONCATENATED MODULE: ./node_modules/rxjs/dist/esm/internal/util/isFunction.js
function isFunction(value) {
  return typeof value === 'function';
}
//# sourceMappingURL=isFunction.js.map
;// CONCATENATED MODULE: ./node_modules/rxjs/dist/esm/internal/util/createErrorClass.js
function createErrorClass(createImpl) {
  const _super = instance => {
    Error.call(instance);
    instance.stack = new Error().stack;
  };
  const ctorFunc = createImpl(_super);
  ctorFunc.prototype = Object.create(Error.prototype);
  ctorFunc.prototype.constructor = ctorFunc;
  return ctorFunc;
}
//# sourceMappingURL=createErrorClass.js.map
;// CONCATENATED MODULE: ./node_modules/rxjs/dist/esm/internal/util/UnsubscriptionError.js

const UnsubscriptionError = createErrorClass(_super => function UnsubscriptionErrorImpl(errors) {
  _super(this);
  this.message = errors ? `${errors.length} errors occurred during unsubscription:
${errors.map((err, i) => `${i + 1}) ${err.toString()}`).join('\n  ')}` : '';
  this.name = 'UnsubscriptionError';
  this.errors = errors;
});
//# sourceMappingURL=UnsubscriptionError.js.map
;// CONCATENATED MODULE: ./node_modules/rxjs/dist/esm/internal/util/arrRemove.js
function arrRemove(arr, item) {
  if (arr) {
    const index = arr.indexOf(item);
    0 <= index && arr.splice(index, 1);
  }
}
//# sourceMappingURL=arrRemove.js.map
;// CONCATENATED MODULE: ./node_modules/rxjs/dist/esm/internal/Subscription.js



class Subscription {
  constructor(initialTeardown) {
    this.initialTeardown = initialTeardown;
    this.closed = false;
    this._parentage = null;
    this._finalizers = null;
  }
  unsubscribe() {
    let errors;
    if (!this.closed) {
      this.closed = true;
      const {
        _parentage
      } = this;
      if (_parentage) {
        this._parentage = null;
        if (Array.isArray(_parentage)) {
          for (const parent of _parentage) {
            parent.remove(this);
          }
        } else {
          _parentage.remove(this);
        }
      }
      const {
        initialTeardown: initialFinalizer
      } = this;
      if (isFunction(initialFinalizer)) {
        try {
          initialFinalizer();
        } catch (e) {
          errors = e instanceof UnsubscriptionError ? e.errors : [e];
        }
      }
      const {
        _finalizers
      } = this;
      if (_finalizers) {
        this._finalizers = null;
        for (const finalizer of _finalizers) {
          try {
            execFinalizer(finalizer);
          } catch (err) {
            errors = errors !== null && errors !== void 0 ? errors : [];
            if (err instanceof UnsubscriptionError) {
              errors = [...errors, ...err.errors];
            } else {
              errors.push(err);
            }
          }
        }
      }
      if (errors) {
        throw new UnsubscriptionError(errors);
      }
    }
  }
  add(teardown) {
    var _a;
    if (teardown && teardown !== this) {
      if (this.closed) {
        execFinalizer(teardown);
      } else {
        if (teardown instanceof Subscription) {
          if (teardown.closed || teardown._hasParent(this)) {
            return;
          }
          teardown._addParent(this);
        }
        (this._finalizers = (_a = this._finalizers) !== null && _a !== void 0 ? _a : []).push(teardown);
      }
    }
  }
  _hasParent(parent) {
    const {
      _parentage
    } = this;
    return _parentage === parent || Array.isArray(_parentage) && _parentage.includes(parent);
  }
  _addParent(parent) {
    const {
      _parentage
    } = this;
    this._parentage = Array.isArray(_parentage) ? (_parentage.push(parent), _parentage) : _parentage ? [_parentage, parent] : parent;
  }
  _removeParent(parent) {
    const {
      _parentage
    } = this;
    if (_parentage === parent) {
      this._parentage = null;
    } else if (Array.isArray(_parentage)) {
      arrRemove(_parentage, parent);
    }
  }
  remove(teardown) {
    const {
      _finalizers
    } = this;
    _finalizers && arrRemove(_finalizers, teardown);
    if (teardown instanceof Subscription) {
      teardown._removeParent(this);
    }
  }
}
Subscription.EMPTY = (() => {
  const empty = new Subscription();
  empty.closed = true;
  return empty;
})();
const EMPTY_SUBSCRIPTION = Subscription.EMPTY;
function isSubscription(value) {
  return value instanceof Subscription || value && 'closed' in value && isFunction(value.remove) && isFunction(value.add) && isFunction(value.unsubscribe);
}
function execFinalizer(finalizer) {
  if (isFunction(finalizer)) {
    finalizer();
  } else {
    finalizer.unsubscribe();
  }
}
//# sourceMappingURL=Subscription.js.map
;// CONCATENATED MODULE: ./node_modules/rxjs/dist/esm/internal/config.js
const config = {
  onUnhandledError: null,
  onStoppedNotification: null,
  Promise: undefined,
  useDeprecatedSynchronousErrorHandling: false,
  useDeprecatedNextContext: false
};
//# sourceMappingURL=config.js.map
;// CONCATENATED MODULE: ./node_modules/rxjs/dist/esm/internal/scheduler/timeoutProvider.js
const timeoutProvider = {
  setTimeout(handler, timeout, ...args) {
    const {
      delegate
    } = timeoutProvider;
    if (delegate === null || delegate === void 0 ? void 0 : delegate.setTimeout) {
      return delegate.setTimeout(handler, timeout, ...args);
    }
    return setTimeout(handler, timeout, ...args);
  },
  clearTimeout(handle) {
    const {
      delegate
    } = timeoutProvider;
    return ((delegate === null || delegate === void 0 ? void 0 : delegate.clearTimeout) || clearTimeout)(handle);
  },
  delegate: undefined
};
//# sourceMappingURL=timeoutProvider.js.map
;// CONCATENATED MODULE: ./node_modules/rxjs/dist/esm/internal/util/reportUnhandledError.js


function reportUnhandledError(err) {
  timeoutProvider.setTimeout(() => {
    const {
      onUnhandledError
    } = config;
    if (onUnhandledError) {
      onUnhandledError(err);
    } else {
      throw err;
    }
  });
}
//# sourceMappingURL=reportUnhandledError.js.map
;// CONCATENATED MODULE: ./node_modules/rxjs/dist/esm/internal/util/noop.js
function noop() {}
//# sourceMappingURL=noop.js.map
;// CONCATENATED MODULE: ./node_modules/rxjs/dist/esm/internal/NotificationFactories.js
const COMPLETE_NOTIFICATION = (() => createNotification('C', undefined, undefined))();
function errorNotification(error) {
  return createNotification('E', undefined, error);
}
function nextNotification(value) {
  return createNotification('N', value, undefined);
}
function createNotification(kind, value, error) {
  return {
    kind,
    value,
    error
  };
}
//# sourceMappingURL=NotificationFactories.js.map
;// CONCATENATED MODULE: ./node_modules/rxjs/dist/esm/internal/util/errorContext.js

let context = null;
function errorContext(cb) {
  if (config.useDeprecatedSynchronousErrorHandling) {
    const isRoot = !context;
    if (isRoot) {
      context = {
        errorThrown: false,
        error: null
      };
    }
    cb();
    if (isRoot) {
      const {
        errorThrown,
        error
      } = context;
      context = null;
      if (errorThrown) {
        throw error;
      }
    }
  } else {
    cb();
  }
}
function captureError(err) {
  if (config.useDeprecatedSynchronousErrorHandling && context) {
    context.errorThrown = true;
    context.error = err;
  }
}
//# sourceMappingURL=errorContext.js.map
;// CONCATENATED MODULE: ./node_modules/rxjs/dist/esm/internal/Subscriber.js








class Subscriber extends Subscription {
  constructor(destination) {
    super();
    this.isStopped = false;
    if (destination) {
      this.destination = destination;
      if (isSubscription(destination)) {
        destination.add(this);
      }
    } else {
      this.destination = EMPTY_OBSERVER;
    }
  }
  static create(next, error, complete) {
    return new SafeSubscriber(next, error, complete);
  }
  next(value) {
    if (this.isStopped) {
      handleStoppedNotification(nextNotification(value), this);
    } else {
      this._next(value);
    }
  }
  error(err) {
    if (this.isStopped) {
      handleStoppedNotification(errorNotification(err), this);
    } else {
      this.isStopped = true;
      this._error(err);
    }
  }
  complete() {
    if (this.isStopped) {
      handleStoppedNotification(COMPLETE_NOTIFICATION, this);
    } else {
      this.isStopped = true;
      this._complete();
    }
  }
  unsubscribe() {
    if (!this.closed) {
      this.isStopped = true;
      super.unsubscribe();
      this.destination = null;
    }
  }
  _next(value) {
    this.destination.next(value);
  }
  _error(err) {
    try {
      this.destination.error(err);
    } finally {
      this.unsubscribe();
    }
  }
  _complete() {
    try {
      this.destination.complete();
    } finally {
      this.unsubscribe();
    }
  }
}
const _bind = Function.prototype.bind;
function bind(fn, thisArg) {
  return _bind.call(fn, thisArg);
}
class ConsumerObserver {
  constructor(partialObserver) {
    this.partialObserver = partialObserver;
  }
  next(value) {
    const {
      partialObserver
    } = this;
    if (partialObserver.next) {
      try {
        partialObserver.next(value);
      } catch (error) {
        handleUnhandledError(error);
      }
    }
  }
  error(err) {
    const {
      partialObserver
    } = this;
    if (partialObserver.error) {
      try {
        partialObserver.error(err);
      } catch (error) {
        handleUnhandledError(error);
      }
    } else {
      handleUnhandledError(err);
    }
  }
  complete() {
    const {
      partialObserver
    } = this;
    if (partialObserver.complete) {
      try {
        partialObserver.complete();
      } catch (error) {
        handleUnhandledError(error);
      }
    }
  }
}
class SafeSubscriber extends Subscriber {
  constructor(observerOrNext, error, complete) {
    super();
    let partialObserver;
    if (isFunction(observerOrNext) || !observerOrNext) {
      partialObserver = {
        next: observerOrNext !== null && observerOrNext !== void 0 ? observerOrNext : undefined,
        error: error !== null && error !== void 0 ? error : undefined,
        complete: complete !== null && complete !== void 0 ? complete : undefined
      };
    } else {
      let context;
      if (this && config.useDeprecatedNextContext) {
        context = Object.create(observerOrNext);
        context.unsubscribe = () => this.unsubscribe();
        partialObserver = {
          next: observerOrNext.next && bind(observerOrNext.next, context),
          error: observerOrNext.error && bind(observerOrNext.error, context),
          complete: observerOrNext.complete && bind(observerOrNext.complete, context)
        };
      } else {
        partialObserver = observerOrNext;
      }
    }
    this.destination = new ConsumerObserver(partialObserver);
  }
}
function handleUnhandledError(error) {
  if (config.useDeprecatedSynchronousErrorHandling) {
    captureError(error);
  } else {
    reportUnhandledError(error);
  }
}
function defaultErrorHandler(err) {
  throw err;
}
function handleStoppedNotification(notification, subscriber) {
  const {
    onStoppedNotification
  } = config;
  onStoppedNotification && timeoutProvider.setTimeout(() => onStoppedNotification(notification, subscriber));
}
const EMPTY_OBSERVER = {
  closed: true,
  next: noop,
  error: defaultErrorHandler,
  complete: noop
};
//# sourceMappingURL=Subscriber.js.map
;// CONCATENATED MODULE: ./node_modules/rxjs/dist/esm/internal/symbol/observable.js
const observable = (() => typeof Symbol === 'function' && Symbol.observable || '@@observable')();
//# sourceMappingURL=observable.js.map
;// CONCATENATED MODULE: ./node_modules/rxjs/dist/esm/internal/util/identity.js
function identity(x) {
  return x;
}
//# sourceMappingURL=identity.js.map
;// CONCATENATED MODULE: ./node_modules/rxjs/dist/esm/internal/util/pipe.js

function pipe(...fns) {
  return pipeFromArray(fns);
}
function pipeFromArray(fns) {
  if (fns.length === 0) {
    return identity;
  }
  if (fns.length === 1) {
    return fns[0];
  }
  return function piped(input) {
    return fns.reduce((prev, fn) => fn(prev), input);
  };
}
//# sourceMappingURL=pipe.js.map
;// CONCATENATED MODULE: ./node_modules/rxjs/dist/esm/internal/Observable.js







let Observable = /*#__PURE__*/(() => {
  class Observable {
    constructor(subscribe) {
      if (subscribe) {
        this._subscribe = subscribe;
      }
    }
    lift(operator) {
      const observable = new Observable();
      observable.source = this;
      observable.operator = operator;
      return observable;
    }
    subscribe(observerOrNext, error, complete) {
      const subscriber = isSubscriber(observerOrNext) ? observerOrNext : new SafeSubscriber(observerOrNext, error, complete);
      errorContext(() => {
        const {
          operator,
          source
        } = this;
        subscriber.add(operator ? operator.call(subscriber, source) : source ? this._subscribe(subscriber) : this._trySubscribe(subscriber));
      });
      return subscriber;
    }
    _trySubscribe(sink) {
      try {
        return this._subscribe(sink);
      } catch (err) {
        sink.error(err);
      }
    }
    forEach(next, promiseCtor) {
      promiseCtor = getPromiseCtor(promiseCtor);
      return new promiseCtor((resolve, reject) => {
        const subscriber = new SafeSubscriber({
          next: value => {
            try {
              next(value);
            } catch (err) {
              reject(err);
              subscriber.unsubscribe();
            }
          },
          error: reject,
          complete: resolve
        });
        this.subscribe(subscriber);
      });
    }
    _subscribe(subscriber) {
      var _a;
      return (_a = this.source) === null || _a === void 0 ? void 0 : _a.subscribe(subscriber);
    }
    [observable]() {
      return this;
    }
    pipe(...operations) {
      return pipeFromArray(operations)(this);
    }
    toPromise(promiseCtor) {
      promiseCtor = getPromiseCtor(promiseCtor);
      return new promiseCtor((resolve, reject) => {
        let value;
        this.subscribe(x => value = x, err => reject(err), () => resolve(value));
      });
    }
  }
  Observable.create = subscribe => {
    return new Observable(subscribe);
  };
  return Observable;
})();
function getPromiseCtor(promiseCtor) {
  var _a;
  return (_a = promiseCtor !== null && promiseCtor !== void 0 ? promiseCtor : config.Promise) !== null && _a !== void 0 ? _a : Promise;
}
function isObserver(value) {
  return value && isFunction(value.next) && isFunction(value.error) && isFunction(value.complete);
}
function isSubscriber(value) {
  return value && value instanceof Subscriber || isObserver(value) && isSubscription(value);
}
//# sourceMappingURL=Observable.js.map
;// CONCATENATED MODULE: ./node_modules/rxjs/dist/esm/internal/scheduler/Action.js

class Action extends Subscription {
  constructor(scheduler, work) {
    super();
  }
  schedule(state, delay = 0) {
    return this;
  }
}
//# sourceMappingURL=Action.js.map
;// CONCATENATED MODULE: ./node_modules/rxjs/dist/esm/internal/scheduler/intervalProvider.js
const intervalProvider = {
  setInterval(handler, timeout, ...args) {
    const {
      delegate
    } = intervalProvider;
    if (delegate === null || delegate === void 0 ? void 0 : delegate.setInterval) {
      return delegate.setInterval(handler, timeout, ...args);
    }
    return setInterval(handler, timeout, ...args);
  },
  clearInterval(handle) {
    const {
      delegate
    } = intervalProvider;
    return ((delegate === null || delegate === void 0 ? void 0 : delegate.clearInterval) || clearInterval)(handle);
  },
  delegate: undefined
};
//# sourceMappingURL=intervalProvider.js.map
;// CONCATENATED MODULE: ./node_modules/rxjs/dist/esm/internal/scheduler/AsyncAction.js



class AsyncAction extends Action {
  constructor(scheduler, work) {
    super(scheduler, work);
    this.scheduler = scheduler;
    this.work = work;
    this.pending = false;
  }
  schedule(state, delay = 0) {
    var _a;
    if (this.closed) {
      return this;
    }
    this.state = state;
    const id = this.id;
    const scheduler = this.scheduler;
    if (id != null) {
      this.id = this.recycleAsyncId(scheduler, id, delay);
    }
    this.pending = true;
    this.delay = delay;
    this.id = (_a = this.id) !== null && _a !== void 0 ? _a : this.requestAsyncId(scheduler, this.id, delay);
    return this;
  }
  requestAsyncId(scheduler, _id, delay = 0) {
    return intervalProvider.setInterval(scheduler.flush.bind(scheduler, this), delay);
  }
  recycleAsyncId(_scheduler, id, delay = 0) {
    if (delay != null && this.delay === delay && this.pending === false) {
      return id;
    }
    if (id != null) {
      intervalProvider.clearInterval(id);
    }
    return undefined;
  }
  execute(state, delay) {
    if (this.closed) {
      return new Error('executing a cancelled action');
    }
    this.pending = false;
    const error = this._execute(state, delay);
    if (error) {
      return error;
    } else if (this.pending === false && this.id != null) {
      this.id = this.recycleAsyncId(this.scheduler, this.id, null);
    }
  }
  _execute(state, _delay) {
    let errored = false;
    let errorValue;
    try {
      this.work(state);
    } catch (e) {
      errored = true;
      errorValue = e ? e : new Error('Scheduled action threw falsy error');
    }
    if (errored) {
      this.unsubscribe();
      return errorValue;
    }
  }
  unsubscribe() {
    if (!this.closed) {
      const {
        id,
        scheduler
      } = this;
      const {
        actions
      } = scheduler;
      this.work = this.state = this.scheduler = null;
      this.pending = false;
      arrRemove(actions, this);
      if (id != null) {
        this.id = this.recycleAsyncId(scheduler, id, null);
      }
      this.delay = null;
      super.unsubscribe();
    }
  }
}
//# sourceMappingURL=AsyncAction.js.map
;// CONCATENATED MODULE: ./node_modules/rxjs/dist/esm/internal/scheduler/dateTimestampProvider.js
const dateTimestampProvider = {
  now() {
    return (dateTimestampProvider.delegate || Date).now();
  },
  delegate: undefined
};
//# sourceMappingURL=dateTimestampProvider.js.map
;// CONCATENATED MODULE: ./node_modules/rxjs/dist/esm/internal/Scheduler.js

class Scheduler {
  constructor(schedulerActionCtor, now = Scheduler.now) {
    this.schedulerActionCtor = schedulerActionCtor;
    this.now = now;
  }
  schedule(work, delay = 0, state) {
    return new this.schedulerActionCtor(this, work).schedule(state, delay);
  }
}
Scheduler.now = dateTimestampProvider.now;
//# sourceMappingURL=Scheduler.js.map
;// CONCATENATED MODULE: ./node_modules/rxjs/dist/esm/internal/scheduler/AsyncScheduler.js

class AsyncScheduler extends Scheduler {
  constructor(SchedulerAction, now = Scheduler.now) {
    super(SchedulerAction, now);
    this.actions = [];
    this._active = false;
  }
  flush(action) {
    const {
      actions
    } = this;
    if (this._active) {
      actions.push(action);
      return;
    }
    let error;
    this._active = true;
    do {
      if (error = action.execute(action.state, action.delay)) {
        break;
      }
    } while (action = actions.shift());
    this._active = false;
    if (error) {
      while (action = actions.shift()) {
        action.unsubscribe();
      }
      throw error;
    }
  }
}
//# sourceMappingURL=AsyncScheduler.js.map
;// CONCATENATED MODULE: ./node_modules/rxjs/dist/esm/internal/scheduler/async.js


const asyncScheduler = new AsyncScheduler(AsyncAction);
const async_async = asyncScheduler;
//# sourceMappingURL=async.js.map
;// CONCATENATED MODULE: ./node_modules/rxjs/dist/esm/internal/util/isScheduler.js

function isScheduler(value) {
  return value && isFunction(value.schedule);
}
//# sourceMappingURL=isScheduler.js.map
;// CONCATENATED MODULE: ./node_modules/rxjs/dist/esm/internal/util/isDate.js
function isValidDate(value) {
  return value instanceof Date && !isNaN(value);
}
//# sourceMappingURL=isDate.js.map
;// CONCATENATED MODULE: ./node_modules/rxjs/dist/esm/internal/observable/timer.js




function timer(dueTime = 0, intervalOrScheduler, scheduler = async_async) {
  let intervalDuration = -1;
  if (intervalOrScheduler != null) {
    if (isScheduler(intervalOrScheduler)) {
      scheduler = intervalOrScheduler;
    } else {
      intervalDuration = intervalOrScheduler;
    }
  }
  return new Observable(subscriber => {
    let due = isValidDate(dueTime) ? +dueTime - scheduler.now() : dueTime;
    if (due < 0) {
      due = 0;
    }
    let n = 0;
    return scheduler.schedule(function () {
      if (!subscriber.closed) {
        subscriber.next(n++);
        if (0 <= intervalDuration) {
          this.schedule(undefined, intervalDuration);
        } else {
          subscriber.complete();
        }
      }
    }, due);
  });
}
//# sourceMappingURL=timer.js.map
;// CONCATENATED MODULE: ./libs/common/frontend/browser-extension-api/src/lib/extension-api-interface/extension-api.interfaces.ts
var AccountStatus = /*#__PURE__*/(() => {
  (function (AccountStatus) {
    AccountStatus["SYNC"] = "SYNC";
    AccountStatus["ANY"] = "ANY";
  })(AccountStatus || (AccountStatus = {}));
  return AccountStatus;
})();
;// CONCATENATED MODULE: ./libs/common/frontend/browser-extension-api/src/lib/extension-api-interface/extension-api.strategy-interface.ts
class IExtensionApiStrategy {}
;// CONCATENATED MODULE: ./libs/common/frontend/browser-extension-api/src/lib/strategies/chrome.extension-api.strategy.ts

/// <reference types="chrome"/>


class ChromeExtensionApiStrategy extends IExtensionApiStrategy {
  constructor() {
    super(...arguments);
    this.setIconBadge = /*#__PURE__*/function () {
      var _ref = asyncToGenerator_asyncToGenerator(function* ({
        backgroundColor,
        text,
        textColor
      }) {
        yield chrome.action.setBadgeBackgroundColor({
          color: backgroundColor
        });
        yield chrome.action.setBadgeTextColor({
          color: textColor
        });
        yield chrome.action.setBadgeText({
          text
        });
      });
      return function (_x) {
        return _ref.apply(this, arguments);
      };
    }();
    this.getExtensionId = () => chrome.runtime.id;
    this.reloadExtension = /*#__PURE__*/asyncToGenerator_asyncToGenerator(function* () {
      return chrome.runtime.reload();
    });
    this.clearStorage = () => chrome.browsingData.removeCache({});
    this.sendMessage = /*#__PURE__*/function () {
      var _ref3 = asyncToGenerator_asyncToGenerator(function* (message) {
        return chrome.runtime.sendMessage(message);
      });
      return function (_x2) {
        return _ref3.apply(this, arguments);
      };
    }();
    this.addMessageListener = (messageToWatch, handlerFunction) => {
      chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
        if (message === messageToWatch) {
          handlerFunction().then(response => sendResponse(response)).catch(() => sendResponse(undefined));
        }
        return true; // Required to keep the channel open for sendResponse
      });
    };
    this.showNotification = (notificationId, options) => chrome.notifications.create(notificationId, options);
    this.clearNotification = notificationId => chrome.notifications.clear(notificationId);
    this.setNotificationListener = listener => chrome.notifications.onButtonClicked.addListener(listener);
    this.createTab = /*#__PURE__*/function () {
      var _ref4 = asyncToGenerator_asyncToGenerator(function* (urlOrOptions) {
        if (typeof urlOrOptions === 'string') return chrome.tabs.create({
          url: urlOrOptions
        });
        return chrome.tabs.create(urlOrOptions);
      });
      return function (_x3) {
        return _ref4.apply(this, arguments);
      };
    }();
    this.getAlarm = /*#__PURE__*/function () {
      var _ref5 = asyncToGenerator_asyncToGenerator(function* (triggerId) {
        return chrome.alarms.get(triggerId);
      });
      return function (_x4) {
        return _ref5.apply(this, arguments);
      };
    }();
    this.createAlarm = /*#__PURE__*/function () {
      var _ref6 = asyncToGenerator_asyncToGenerator(function* (triggerId, options) {
        return chrome.alarms.create(triggerId, options);
      });
      return function (_x5, _x6) {
        return _ref6.apply(this, arguments);
      };
    }();
    this.clearAlarm = /*#__PURE__*/function () {
      var _ref7 = asyncToGenerator_asyncToGenerator(function* (triggerId) {
        return chrome.alarms.clear(triggerId);
      });
      return function (_x7) {
        return _ref7.apply(this, arguments);
      };
    }();
    this.clearAllAlarms = /*#__PURE__*/asyncToGenerator_asyncToGenerator(function* () {
      return chrome.alarms.clearAll();
    });
    this.getAllAlarms = /*#__PURE__*/asyncToGenerator_asyncToGenerator(function* () {
      return chrome.alarms.getAll();
    });
    this.addAlarmListener = callback => {
      chrome.alarms.onAlarm.addListener(callback);
    };
    this.onInstalled = callback => {
      chrome.runtime.onInstalled.addListener(callback);
    };
    this.onStartup = callback => {
      chrome.runtime.onStartup.addListener(callback);
    };
    // Note: queryState should return a promise, but the types dont reflect it yet. So we wrap it in a promise.
    this.getIdleState = /*#__PURE__*/function () {
      var _ref10 = asyncToGenerator_asyncToGenerator(function* (detectionIntervalInSeconds) {
        return new Promise(resolve => {
          chrome.idle.queryState(detectionIntervalInSeconds, state => resolve(state));
        });
      });
      return function (_x8) {
        return _ref10.apply(this, arguments);
      };
    }();
    this.setIdleStateDetectionInterval = intervalInSeconds => chrome.idle.setDetectionInterval(intervalInSeconds);
    this.addIdleStateChangeListener = listener => {
      chrome.idle.onStateChanged.addListener(listener);
    };
    this.setLocalStorage = /*#__PURE__*/function () {
      var _ref11 = asyncToGenerator_asyncToGenerator(function* (items) {
        return chrome.storage.local.set(items);
      });
      return function (_x9) {
        return _ref11.apply(this, arguments);
      };
    }();
    this.getLocalStorage = /*#__PURE__*/function () {
      var _ref12 = asyncToGenerator_asyncToGenerator(function* (keys) {
        return chrome.storage.local.get(keys);
      });
      return function (_x10) {
        return _ref12.apply(this, arguments);
      };
    }();
    this.removeLocalStorage = /*#__PURE__*/function () {
      var _ref13 = asyncToGenerator_asyncToGenerator(function* (keys) {
        return chrome.storage.local.remove(keys);
      });
      return function (_x11) {
        return _ref13.apply(this, arguments);
      };
    }();
    this.clearLocalStorage = /*#__PURE__*/asyncToGenerator_asyncToGenerator(function* () {
      return chrome.storage.local.clear();
    });
    this.getUserProfile = /*#__PURE__*/asyncToGenerator_asyncToGenerator(function* (details = {
      accountStatus: AccountStatus.SYNC
    }) {
      return chrome.identity.getProfileUserInfo(details);
    });
    this.setUserSignInListener = listener => {
      chrome.identity.onSignInChanged.addListener(listener);
    };
    this.getManifest = () => chrome.runtime.getManifest();
    this.getDevice = /*#__PURE__*/asyncToGenerator_asyncToGenerator(function* () {
      const deviceIdPromise = new Promise(resolve => {
        chrome.enterprise.deviceAttributes.getDirectoryDeviceId(deviceId => resolve(deviceId));
      });
      const serialNumberPromise = new Promise((resolve, reject) => {
        if (!('enterprise' in chrome)) {
          reject(new Error('Device Not Managed'));
        }
        chrome.enterprise.deviceAttributes.getDeviceSerialNumber(serialNumber => resolve(serialNumber));
      });
      const assetIdPromise = new Promise((resolve, reject) => {
        if (!('enterprise' in chrome)) {
          reject(new Error('Device Not Managed'));
        }
        chrome.enterprise.deviceAttributes.getDeviceAssetId(assetId => resolve(assetId));
      });
      const deviceDetails = {
        id: yield deviceIdPromise,
        serialNumber: yield serialNumberPromise,
        assetId: yield assetIdPromise
      };
      if (deviceDetails.id === null || deviceDetails.serialNumber === null) {
        throw new Error('Device Not Managed');
      }
      return deviceDetails;
    });
    this.getNetworkDetails = /*#__PURE__*/asyncToGenerator_asyncToGenerator(function* () {
      return new Promise((resolve, reject) => {
        chrome.enterprise.networkingAttributes.getNetworkDetails(networkDetails => {
          if (chrome.runtime.lastError) {
            reject(new Error('Device Not Managed'));
          }
          resolve(networkDetails);
        });
      });
    });
  }
}
;// CONCATENATED MODULE: ./libs/common/frontend/browser-extension-api/src/lib/strategies/chrome-local.extension-api.strategy.ts

/// <reference types="chrome"/>

class ChromeLocalExtensionApiStrategy extends ChromeExtensionApiStrategy {
  constructor(localOverrides) {
    var _this;
    super();
    _this = this;
    this.localOverrides = localOverrides;
    this.clearStorage = () => new Promise(resolve => {
      console.log('FAKING LOCAL: Clearing storage');
      setTimeout(() => {
        resolve();
      }, 1500);
    });
    this.getDevice = /*#__PURE__*/asyncToGenerator_asyncToGenerator(function* () {
      return new Promise((resolve, reject) => {
        setTimeout(() => {
          if (!_this.localOverrides.device?.id || !_this.localOverrides.device?.serialNumber) {
            reject(new Error('Device Not Managed'));
            return;
          }
          resolve({
            id: _this.localOverrides.device?.id ?? 'local-device-id',
            serialNumber: _this.localOverrides.device?.serialNumber ?? 'local-serial-number',
            assetId: _this.localOverrides.device?.assetId ?? 'local-asset-id'
          });
        }, 1000);
      });
    });
    this.getNetworkDetails = /*#__PURE__*/asyncToGenerator_asyncToGenerator(function* () {
      return new Promise((resolve, reject) => {
        setTimeout(() => {
          if (!_this.localOverrides.network?.ipv4 || !_this.localOverrides.network?.ipv6 || !_this.localOverrides.network?.macAddress) {
            reject(new Error('Device Not Managed'));
            return;
          }
          resolve({
            ipv4: _this.localOverrides.network?.ipv4 ?? 'local-ipv4',
            ipv6: _this.localOverrides.network?.ipv6 ?? 'local-ipv6',
            macAddress: _this.localOverrides.network?.macAddress ?? 'local-mac-address'
          });
        }, 1000);
      });
    });
  }
}
;// CONCATENATED MODULE: ./libs/common/frontend/browser-extension-api/src/lib/extension-api-interface/extension-api.factory.ts


var ExtensionApiStrategy = /*#__PURE__*/(() => {
  (function (ExtensionApiStrategy) {
    ExtensionApiStrategy["CHROME"] = "CHROME";
    ExtensionApiStrategy["CHROME_LOCAL"] = "CHROME_LOCAL";
    ExtensionApiStrategy["NOT_SET"] = "NOT_SET";
  })(ExtensionApiStrategy || (ExtensionApiStrategy = {}));
  return ExtensionApiStrategy;
})();
const ApiIntances = {};
let plocalOverrides = {};
let pApiStrategy = ExtensionApiStrategy.NOT_SET;
const setLocalOverrides = localOverrides => {
  plocalOverrides = localOverrides;
};
const setApiStrategy = apiStrategy => {
  pApiStrategy = apiStrategy;
};
const ExtensionApiFactory = () => {
  switch (pApiStrategy) {
    case 'CHROME':
      {
        let instance = ApiIntances[pApiStrategy];
        if (!instance) {
          instance = new ChromeExtensionApiStrategy();
        }
        return instance;
      }
    case 'CHROME_LOCAL':
      {
        let instance = ApiIntances[pApiStrategy];
        if (!instance) {
          instance = new ChromeLocalExtensionApiStrategy(plocalOverrides);
        }
        return instance;
      }
    default:
      throw new Error(`invalid strategy type: ${pApiStrategy}`);
  }
};
;// CONCATENATED MODULE: ./libs/common/frontend/browser-extension-api/src/index.ts




;// CONCATENATED MODULE: ./node_modules/@reduxjs/toolkit/node_modules/immer/dist/immer.mjs
// src/utils/env.ts
var NOTHING = Symbol.for("immer-nothing");
var DRAFTABLE = Symbol.for("immer-draftable");
var DRAFT_STATE = Symbol.for("immer-state");

// src/utils/errors.ts
var errors =  false ? 0 : [];
function die(error, ...args) {
  if (false) {}
  throw new Error(`[Immer] minified error nr: ${error}. Full error at: https://bit.ly/3cXEKWf`);
}

// src/utils/common.ts
var getPrototypeOf = Object.getPrototypeOf;
function isDraft(value) {
  return !!value && !!value[DRAFT_STATE];
}
function isDraftable(value) {
  if (!value) return false;
  return immer_isPlainObject(value) || Array.isArray(value) || !!value[DRAFTABLE] || !!value.constructor?.[DRAFTABLE] || isMap(value) || isSet(value);
}
var objectCtorString = Object.prototype.constructor.toString();
function immer_isPlainObject(value) {
  if (!value || typeof value !== "object") return false;
  const proto = getPrototypeOf(value);
  if (proto === null) {
    return true;
  }
  const Ctor = Object.hasOwnProperty.call(proto, "constructor") && proto.constructor;
  if (Ctor === Object) return true;
  return typeof Ctor == "function" && Function.toString.call(Ctor) === objectCtorString;
}
function original(value) {
  if (!isDraft(value)) die(15, value);
  return value[DRAFT_STATE].base_;
}
function each(obj, iter) {
  if (getArchtype(obj) === 0 /* Object */) {
    Reflect.ownKeys(obj).forEach(key => {
      iter(key, obj[key], obj);
    });
  } else {
    obj.forEach((entry, index) => iter(index, entry, obj));
  }
}
function getArchtype(thing) {
  const state = thing[DRAFT_STATE];
  return state ? state.type_ : Array.isArray(thing) ? 1 /* Array */ : isMap(thing) ? 2 /* Map */ : isSet(thing) ? 3 /* Set */ : 0 /* Object */;
}
function has(thing, prop) {
  return getArchtype(thing) === 2 /* Map */ ? thing.has(prop) : Object.prototype.hasOwnProperty.call(thing, prop);
}
function get(thing, prop) {
  return getArchtype(thing) === 2 /* Map */ ? thing.get(prop) : thing[prop];
}
function set(thing, propOrOldValue, value) {
  const t = getArchtype(thing);
  if (t === 2 /* Map */) thing.set(propOrOldValue, value);else if (t === 3 /* Set */) {
    thing.add(value);
  } else thing[propOrOldValue] = value;
}
function is(x, y) {
  if (x === y) {
    return x !== 0 || 1 / x === 1 / y;
  } else {
    return x !== x && y !== y;
  }
}
function isMap(target) {
  return target instanceof Map;
}
function isSet(target) {
  return target instanceof Set;
}
function latest(state) {
  return state.copy_ || state.base_;
}
function shallowCopy(base, strict) {
  if (isMap(base)) {
    return new Map(base);
  }
  if (isSet(base)) {
    return new Set(base);
  }
  if (Array.isArray(base)) return Array.prototype.slice.call(base);
  const isPlain = immer_isPlainObject(base);
  if (strict === true || strict === "class_only" && !isPlain) {
    const descriptors = Object.getOwnPropertyDescriptors(base);
    delete descriptors[DRAFT_STATE];
    let keys = Reflect.ownKeys(descriptors);
    for (let i = 0; i < keys.length; i++) {
      const key = keys[i];
      const desc = descriptors[key];
      if (desc.writable === false) {
        desc.writable = true;
        desc.configurable = true;
      }
      if (desc.get || desc.set) descriptors[key] = {
        configurable: true,
        writable: true,
        // could live with !!desc.set as well here...
        enumerable: desc.enumerable,
        value: base[key]
      };
    }
    return Object.create(getPrototypeOf(base), descriptors);
  } else {
    const proto = getPrototypeOf(base);
    if (proto !== null && isPlain) {
      return {
        ...base
      };
    }
    const obj = Object.create(proto);
    return Object.assign(obj, base);
  }
}
function freeze(obj, deep = false) {
  if (isFrozen(obj) || isDraft(obj) || !isDraftable(obj)) return obj;
  if (getArchtype(obj) > 1) {
    obj.set = obj.add = obj.clear = obj.delete = dontMutateFrozenCollections;
  }
  Object.freeze(obj);
  if (deep) Object.entries(obj).forEach(([key, value]) => freeze(value, true));
  return obj;
}
function dontMutateFrozenCollections() {
  die(2);
}
function isFrozen(obj) {
  return Object.isFrozen(obj);
}

// src/utils/plugins.ts
var plugins = {};
function getPlugin(pluginKey) {
  const plugin = plugins[pluginKey];
  if (!plugin) {
    die(0, pluginKey);
  }
  return plugin;
}
function loadPlugin(pluginKey, implementation) {
  if (!plugins[pluginKey]) plugins[pluginKey] = implementation;
}

// src/core/scope.ts
var currentScope;
function getCurrentScope() {
  return currentScope;
}
function createScope(parent_, immer_) {
  return {
    drafts_: [],
    parent_,
    immer_,
    // Whenever the modified draft contains a draft from another scope, we
    // need to prevent auto-freezing so the unowned draft can be finalized.
    canAutoFreeze_: true,
    unfinalizedDrafts_: 0
  };
}
function usePatchesInScope(scope, patchListener) {
  if (patchListener) {
    getPlugin("Patches");
    scope.patches_ = [];
    scope.inversePatches_ = [];
    scope.patchListener_ = patchListener;
  }
}
function revokeScope(scope) {
  leaveScope(scope);
  scope.drafts_.forEach(revokeDraft);
  scope.drafts_ = null;
}
function leaveScope(scope) {
  if (scope === currentScope) {
    currentScope = scope.parent_;
  }
}
function enterScope(immer2) {
  return currentScope = createScope(currentScope, immer2);
}
function revokeDraft(draft) {
  const state = draft[DRAFT_STATE];
  if (state.type_ === 0 /* Object */ || state.type_ === 1 /* Array */) state.revoke_();else state.revoked_ = true;
}

// src/core/finalize.ts
function processResult(result, scope) {
  scope.unfinalizedDrafts_ = scope.drafts_.length;
  const baseDraft = scope.drafts_[0];
  const isReplaced = result !== void 0 && result !== baseDraft;
  if (isReplaced) {
    if (baseDraft[DRAFT_STATE].modified_) {
      revokeScope(scope);
      die(4);
    }
    if (isDraftable(result)) {
      result = finalize(scope, result);
      if (!scope.parent_) maybeFreeze(scope, result);
    }
    if (scope.patches_) {
      getPlugin("Patches").generateReplacementPatches_(baseDraft[DRAFT_STATE].base_, result, scope.patches_, scope.inversePatches_);
    }
  } else {
    result = finalize(scope, baseDraft, []);
  }
  revokeScope(scope);
  if (scope.patches_) {
    scope.patchListener_(scope.patches_, scope.inversePatches_);
  }
  return result !== NOTHING ? result : void 0;
}
function finalize(rootScope, value, path) {
  if (isFrozen(value)) return value;
  const state = value[DRAFT_STATE];
  if (!state) {
    each(value, (key, childValue) => finalizeProperty(rootScope, state, value, key, childValue, path));
    return value;
  }
  if (state.scope_ !== rootScope) return value;
  if (!state.modified_) {
    maybeFreeze(rootScope, state.base_, true);
    return state.base_;
  }
  if (!state.finalized_) {
    state.finalized_ = true;
    state.scope_.unfinalizedDrafts_--;
    const result = state.copy_;
    let resultEach = result;
    let isSet2 = false;
    if (state.type_ === 3 /* Set */) {
      resultEach = new Set(result);
      result.clear();
      isSet2 = true;
    }
    each(resultEach, (key, childValue) => finalizeProperty(rootScope, state, result, key, childValue, path, isSet2));
    maybeFreeze(rootScope, result, false);
    if (path && rootScope.patches_) {
      getPlugin("Patches").generatePatches_(state, path, rootScope.patches_, rootScope.inversePatches_);
    }
  }
  return state.copy_;
}
function finalizeProperty(rootScope, parentState, targetObject, prop, childValue, rootPath, targetIsSet) {
  if (false) {}
  if (isDraft(childValue)) {
    const path = rootPath && parentState && parentState.type_ !== 3 /* Set */ &&
    // Set objects are atomic since they have no keys.
    !has(parentState.assigned_, prop) ? rootPath.concat(prop) : void 0;
    const res = finalize(rootScope, childValue, path);
    set(targetObject, prop, res);
    if (isDraft(res)) {
      rootScope.canAutoFreeze_ = false;
    } else return;
  } else if (targetIsSet) {
    targetObject.add(childValue);
  }
  if (isDraftable(childValue) && !isFrozen(childValue)) {
    if (!rootScope.immer_.autoFreeze_ && rootScope.unfinalizedDrafts_ < 1) {
      return;
    }
    finalize(rootScope, childValue);
    if ((!parentState || !parentState.scope_.parent_) && typeof prop !== "symbol" && Object.prototype.propertyIsEnumerable.call(targetObject, prop)) maybeFreeze(rootScope, childValue);
  }
}
function maybeFreeze(scope, value, deep = false) {
  if (!scope.parent_ && scope.immer_.autoFreeze_ && scope.canAutoFreeze_) {
    freeze(value, deep);
  }
}

// src/core/proxy.ts
function createProxyProxy(base, parent) {
  const isArray = Array.isArray(base);
  const state = {
    type_: isArray ? 1 /* Array */ : 0 /* Object */,

    // Track which produce call this is associated with.
    scope_: parent ? parent.scope_ : getCurrentScope(),
    // True for both shallow and deep changes.
    modified_: false,
    // Used during finalization.
    finalized_: false,
    // Track which properties have been assigned (true) or deleted (false).
    assigned_: {},
    // The parent draft state.
    parent_: parent,
    // The base state.
    base_: base,
    // The base proxy.
    draft_: null,
    // set below
    // The base copy with any updated values.
    copy_: null,
    // Called by the `produce` function.
    revoke_: null,
    isManual_: false
  };
  let target = state;
  let traps = objectTraps;
  if (isArray) {
    target = [state];
    traps = arrayTraps;
  }
  const {
    revoke,
    proxy
  } = Proxy.revocable(target, traps);
  state.draft_ = proxy;
  state.revoke_ = revoke;
  return proxy;
}
var objectTraps = {
  get(state, prop) {
    if (prop === DRAFT_STATE) return state;
    const source = latest(state);
    if (!has(source, prop)) {
      return readPropFromProto(state, source, prop);
    }
    const value = source[prop];
    if (state.finalized_ || !isDraftable(value)) {
      return value;
    }
    if (value === peek(state.base_, prop)) {
      prepareCopy(state);
      return state.copy_[prop] = createProxy(value, state);
    }
    return value;
  },
  has(state, prop) {
    return prop in latest(state);
  },
  ownKeys(state) {
    return Reflect.ownKeys(latest(state));
  },
  set(state, prop, value) {
    const desc = getDescriptorFromProto(latest(state), prop);
    if (desc?.set) {
      desc.set.call(state.draft_, value);
      return true;
    }
    if (!state.modified_) {
      const current2 = peek(latest(state), prop);
      const currentState = current2?.[DRAFT_STATE];
      if (currentState && currentState.base_ === value) {
        state.copy_[prop] = value;
        state.assigned_[prop] = false;
        return true;
      }
      if (is(value, current2) && (value !== void 0 || has(state.base_, prop))) return true;
      prepareCopy(state);
      markChanged(state);
    }
    if (state.copy_[prop] === value && (
    // special case: handle new props with value 'undefined'
    value !== void 0 || prop in state.copy_) ||
    // special case: NaN
    Number.isNaN(value) && Number.isNaN(state.copy_[prop])) return true;
    state.copy_[prop] = value;
    state.assigned_[prop] = true;
    return true;
  },
  deleteProperty(state, prop) {
    if (peek(state.base_, prop) !== void 0 || prop in state.base_) {
      state.assigned_[prop] = false;
      prepareCopy(state);
      markChanged(state);
    } else {
      delete state.assigned_[prop];
    }
    if (state.copy_) {
      delete state.copy_[prop];
    }
    return true;
  },
  // Note: We never coerce `desc.value` into an Immer draft, because we can't make
  // the same guarantee in ES5 mode.
  getOwnPropertyDescriptor(state, prop) {
    const owner = latest(state);
    const desc = Reflect.getOwnPropertyDescriptor(owner, prop);
    if (!desc) return desc;
    return {
      writable: true,
      configurable: state.type_ !== 1 /* Array */ || prop !== "length",
      enumerable: desc.enumerable,
      value: owner[prop]
    };
  },
  defineProperty() {
    die(11);
  },
  getPrototypeOf(state) {
    return getPrototypeOf(state.base_);
  },
  setPrototypeOf() {
    die(12);
  }
};
var arrayTraps = {};
each(objectTraps, (key, fn) => {
  arrayTraps[key] = function () {
    arguments[0] = arguments[0][0];
    return fn.apply(this, arguments);
  };
});
arrayTraps.deleteProperty = function (state, prop) {
  if (false) {}
  return arrayTraps.set.call(this, state, prop, void 0);
};
arrayTraps.set = function (state, prop, value) {
  if (false) {}
  return objectTraps.set.call(this, state[0], prop, value, state[0]);
};
function peek(draft, prop) {
  const state = draft[DRAFT_STATE];
  const source = state ? latest(state) : draft;
  return source[prop];
}
function readPropFromProto(state, source, prop) {
  const desc = getDescriptorFromProto(source, prop);
  return desc ? `value` in desc ? desc.value :
  // This is a very special case, if the prop is a getter defined by the
  // prototype, we should invoke it with the draft as context!
  desc.get?.call(state.draft_) : void 0;
}
function getDescriptorFromProto(source, prop) {
  if (!(prop in source)) return void 0;
  let proto = getPrototypeOf(source);
  while (proto) {
    const desc = Object.getOwnPropertyDescriptor(proto, prop);
    if (desc) return desc;
    proto = getPrototypeOf(proto);
  }
  return void 0;
}
function markChanged(state) {
  if (!state.modified_) {
    state.modified_ = true;
    if (state.parent_) {
      markChanged(state.parent_);
    }
  }
}
function prepareCopy(state) {
  if (!state.copy_) {
    state.copy_ = shallowCopy(state.base_, state.scope_.immer_.useStrictShallowCopy_);
  }
}

// src/core/immerClass.ts
var Immer2 = class {
  constructor(config) {
    this.autoFreeze_ = true;
    this.useStrictShallowCopy_ = false;
    /**
     * The `produce` function takes a value and a "recipe function" (whose
     * return value often depends on the base state). The recipe function is
     * free to mutate its first argument however it wants. All mutations are
     * only ever applied to a __copy__ of the base state.
     *
     * Pass only a function to create a "curried producer" which relieves you
     * from passing the recipe function every time.
     *
     * Only plain objects and arrays are made mutable. All other objects are
     * considered uncopyable.
     *
     * Note: This function is __bound__ to its `Immer` instance.
     *
     * @param {any} base - the initial state
     * @param {Function} recipe - function that receives a proxy of the base state as first argument and which can be freely modified
     * @param {Function} patchListener - optional function that will be called with all the patches produced here
     * @returns {any} a new state, or the initial state if nothing was modified
     */
    this.produce = (base, recipe, patchListener) => {
      if (typeof base === "function" && typeof recipe !== "function") {
        const defaultBase = recipe;
        recipe = base;
        const self = this;
        return function curriedProduce(base2 = defaultBase, ...args) {
          return self.produce(base2, draft => recipe.call(this, draft, ...args));
        };
      }
      if (typeof recipe !== "function") die(6);
      if (patchListener !== void 0 && typeof patchListener !== "function") die(7);
      let result;
      if (isDraftable(base)) {
        const scope = enterScope(this);
        const proxy = createProxy(base, void 0);
        let hasError = true;
        try {
          result = recipe(proxy);
          hasError = false;
        } finally {
          if (hasError) revokeScope(scope);else leaveScope(scope);
        }
        usePatchesInScope(scope, patchListener);
        return processResult(result, scope);
      } else if (!base || typeof base !== "object") {
        result = recipe(base);
        if (result === void 0) result = base;
        if (result === NOTHING) result = void 0;
        if (this.autoFreeze_) freeze(result, true);
        if (patchListener) {
          const p = [];
          const ip = [];
          getPlugin("Patches").generateReplacementPatches_(base, result, p, ip);
          patchListener(p, ip);
        }
        return result;
      } else die(1, base);
    };
    this.produceWithPatches = (base, recipe) => {
      if (typeof base === "function") {
        return (state, ...args) => this.produceWithPatches(state, draft => base(draft, ...args));
      }
      let patches, inversePatches;
      const result = this.produce(base, recipe, (p, ip) => {
        patches = p;
        inversePatches = ip;
      });
      return [result, patches, inversePatches];
    };
    if (typeof config?.autoFreeze === "boolean") this.setAutoFreeze(config.autoFreeze);
    if (typeof config?.useStrictShallowCopy === "boolean") this.setUseStrictShallowCopy(config.useStrictShallowCopy);
  }
  createDraft(base) {
    if (!isDraftable(base)) die(8);
    if (isDraft(base)) base = current(base);
    const scope = enterScope(this);
    const proxy = createProxy(base, void 0);
    proxy[DRAFT_STATE].isManual_ = true;
    leaveScope(scope);
    return proxy;
  }
  finishDraft(draft, patchListener) {
    const state = draft && draft[DRAFT_STATE];
    if (!state || !state.isManual_) die(9);
    const {
      scope_: scope
    } = state;
    usePatchesInScope(scope, patchListener);
    return processResult(void 0, scope);
  }
  /**
   * Pass true to automatically freeze all copies created by Immer.
   *
   * By default, auto-freezing is enabled.
   */
  setAutoFreeze(value) {
    this.autoFreeze_ = value;
  }
  /**
   * Pass true to enable strict shallow copy.
   *
   * By default, immer does not copy the object descriptors such as getter, setter and non-enumrable properties.
   */
  setUseStrictShallowCopy(value) {
    this.useStrictShallowCopy_ = value;
  }
  applyPatches(base, patches) {
    let i;
    for (i = patches.length - 1; i >= 0; i--) {
      const patch = patches[i];
      if (patch.path.length === 0 && patch.op === "replace") {
        base = patch.value;
        break;
      }
    }
    if (i > -1) {
      patches = patches.slice(i + 1);
    }
    const applyPatchesImpl = getPlugin("Patches").applyPatches_;
    if (isDraft(base)) {
      return applyPatchesImpl(base, patches);
    }
    return this.produce(base, draft => applyPatchesImpl(draft, patches));
  }
};
function createProxy(value, parent) {
  const draft = isMap(value) ? getPlugin("MapSet").proxyMap_(value, parent) : isSet(value) ? getPlugin("MapSet").proxySet_(value, parent) : createProxyProxy(value, parent);
  const scope = parent ? parent.scope_ : getCurrentScope();
  scope.drafts_.push(draft);
  return draft;
}

// src/core/current.ts
function current(value) {
  if (!isDraft(value)) die(10, value);
  return currentImpl(value);
}
function currentImpl(value) {
  if (!isDraftable(value) || isFrozen(value)) return value;
  const state = value[DRAFT_STATE];
  let copy;
  if (state) {
    if (!state.modified_) return state.base_;
    state.finalized_ = true;
    copy = shallowCopy(value, state.scope_.immer_.useStrictShallowCopy_);
  } else {
    copy = shallowCopy(value, true);
  }
  each(copy, (key, childValue) => {
    set(copy, key, currentImpl(childValue));
  });
  if (state) {
    state.finalized_ = false;
  }
  return copy;
}

// src/plugins/patches.ts
function enablePatches() {
  const errorOffset = 16;
  if (false) {}
  const REPLACE = "replace";
  const ADD = "add";
  const REMOVE = "remove";
  function generatePatches_(state, basePath, patches, inversePatches) {
    switch (state.type_) {
      case 0 /* Object */:
      case 2 /* Map */:
        return generatePatchesFromAssigned(state, basePath, patches, inversePatches);
      case 1 /* Array */:
        return generateArrayPatches(state, basePath, patches, inversePatches);
      case 3 /* Set */:
        return generateSetPatches(state, basePath, patches, inversePatches);
    }
  }
  function generateArrayPatches(state, basePath, patches, inversePatches) {
    let {
      base_,
      assigned_
    } = state;
    let copy_ = state.copy_;
    if (copy_.length < base_.length) {
      ;
      [base_, copy_] = [copy_, base_];
      [patches, inversePatches] = [inversePatches, patches];
    }
    for (let i = 0; i < base_.length; i++) {
      if (assigned_[i] && copy_[i] !== base_[i]) {
        const path = basePath.concat([i]);
        patches.push({
          op: REPLACE,
          path,
          // Need to maybe clone it, as it can in fact be the original value
          // due to the base/copy inversion at the start of this function
          value: clonePatchValueIfNeeded(copy_[i])
        });
        inversePatches.push({
          op: REPLACE,
          path,
          value: clonePatchValueIfNeeded(base_[i])
        });
      }
    }
    for (let i = base_.length; i < copy_.length; i++) {
      const path = basePath.concat([i]);
      patches.push({
        op: ADD,
        path,
        // Need to maybe clone it, as it can in fact be the original value
        // due to the base/copy inversion at the start of this function
        value: clonePatchValueIfNeeded(copy_[i])
      });
    }
    for (let i = copy_.length - 1; base_.length <= i; --i) {
      const path = basePath.concat([i]);
      inversePatches.push({
        op: REMOVE,
        path
      });
    }
  }
  function generatePatchesFromAssigned(state, basePath, patches, inversePatches) {
    const {
      base_,
      copy_
    } = state;
    each(state.assigned_, (key, assignedValue) => {
      const origValue = get(base_, key);
      const value = get(copy_, key);
      const op = !assignedValue ? REMOVE : has(base_, key) ? REPLACE : ADD;
      if (origValue === value && op === REPLACE) return;
      const path = basePath.concat(key);
      patches.push(op === REMOVE ? {
        op,
        path
      } : {
        op,
        path,
        value
      });
      inversePatches.push(op === ADD ? {
        op: REMOVE,
        path
      } : op === REMOVE ? {
        op: ADD,
        path,
        value: clonePatchValueIfNeeded(origValue)
      } : {
        op: REPLACE,
        path,
        value: clonePatchValueIfNeeded(origValue)
      });
    });
  }
  function generateSetPatches(state, basePath, patches, inversePatches) {
    let {
      base_,
      copy_
    } = state;
    let i = 0;
    base_.forEach(value => {
      if (!copy_.has(value)) {
        const path = basePath.concat([i]);
        patches.push({
          op: REMOVE,
          path,
          value
        });
        inversePatches.unshift({
          op: ADD,
          path,
          value
        });
      }
      i++;
    });
    i = 0;
    copy_.forEach(value => {
      if (!base_.has(value)) {
        const path = basePath.concat([i]);
        patches.push({
          op: ADD,
          path,
          value
        });
        inversePatches.unshift({
          op: REMOVE,
          path,
          value
        });
      }
      i++;
    });
  }
  function generateReplacementPatches_(baseValue, replacement, patches, inversePatches) {
    patches.push({
      op: REPLACE,
      path: [],
      value: replacement === NOTHING ? void 0 : replacement
    });
    inversePatches.push({
      op: REPLACE,
      path: [],
      value: baseValue
    });
  }
  function applyPatches_(draft, patches) {
    patches.forEach(patch => {
      const {
        path,
        op
      } = patch;
      let base = draft;
      for (let i = 0; i < path.length - 1; i++) {
        const parentType = getArchtype(base);
        let p = path[i];
        if (typeof p !== "string" && typeof p !== "number") {
          p = "" + p;
        }
        if ((parentType === 0 /* Object */ || parentType === 1 /* Array */) && (p === "__proto__" || p === "constructor")) die(errorOffset + 3);
        if (typeof base === "function" && p === "prototype") die(errorOffset + 3);
        base = get(base, p);
        if (typeof base !== "object") die(errorOffset + 2, path.join("/"));
      }
      const type = getArchtype(base);
      const value = deepClonePatchValue(patch.value);
      const key = path[path.length - 1];
      switch (op) {
        case REPLACE:
          switch (type) {
            case 2 /* Map */:
              return base.set(key, value);
            case 3 /* Set */:
              die(errorOffset);
            default:
              return base[key] = value;
          }
        case ADD:
          switch (type) {
            case 1 /* Array */:
              return key === "-" ? base.push(value) : base.splice(key, 0, value);
            case 2 /* Map */:
              return base.set(key, value);
            case 3 /* Set */:
              return base.add(value);
            default:
              return base[key] = value;
          }
        case REMOVE:
          switch (type) {
            case 1 /* Array */:
              return base.splice(key, 1);
            case 2 /* Map */:
              return base.delete(key);
            case 3 /* Set */:
              return base.delete(patch.value);
            default:
              return delete base[key];
          }
        default:
          die(errorOffset + 1, op);
      }
    });
    return draft;
  }
  function deepClonePatchValue(obj) {
    if (!isDraftable(obj)) return obj;
    if (Array.isArray(obj)) return obj.map(deepClonePatchValue);
    if (isMap(obj)) return new Map(Array.from(obj.entries()).map(([k, v]) => [k, deepClonePatchValue(v)]));
    if (isSet(obj)) return new Set(Array.from(obj).map(deepClonePatchValue));
    const cloned = Object.create(getPrototypeOf(obj));
    for (const key in obj) cloned[key] = deepClonePatchValue(obj[key]);
    if (has(obj, DRAFTABLE)) cloned[DRAFTABLE] = obj[DRAFTABLE];
    return cloned;
  }
  function clonePatchValueIfNeeded(obj) {
    if (isDraft(obj)) {
      return deepClonePatchValue(obj);
    } else return obj;
  }
  loadPlugin("Patches", {
    applyPatches_,
    generatePatches_,
    generateReplacementPatches_
  });
}

// src/plugins/mapset.ts
function enableMapSet() {
  class DraftMap extends Map {
    constructor(target, parent) {
      super();
      this[DRAFT_STATE] = {
        type_: 2 /* Map */,
        parent_: parent,
        scope_: parent ? parent.scope_ : getCurrentScope(),
        modified_: false,
        finalized_: false,
        copy_: void 0,
        assigned_: void 0,
        base_: target,
        draft_: this,
        isManual_: false,
        revoked_: false
      };
    }
    get size() {
      return latest(this[DRAFT_STATE]).size;
    }
    has(key) {
      return latest(this[DRAFT_STATE]).has(key);
    }
    set(key, value) {
      const state = this[DRAFT_STATE];
      assertUnrevoked(state);
      if (!latest(state).has(key) || latest(state).get(key) !== value) {
        prepareMapCopy(state);
        markChanged(state);
        state.assigned_.set(key, true);
        state.copy_.set(key, value);
        state.assigned_.set(key, true);
      }
      return this;
    }
    delete(key) {
      if (!this.has(key)) {
        return false;
      }
      const state = this[DRAFT_STATE];
      assertUnrevoked(state);
      prepareMapCopy(state);
      markChanged(state);
      if (state.base_.has(key)) {
        state.assigned_.set(key, false);
      } else {
        state.assigned_.delete(key);
      }
      state.copy_.delete(key);
      return true;
    }
    clear() {
      const state = this[DRAFT_STATE];
      assertUnrevoked(state);
      if (latest(state).size) {
        prepareMapCopy(state);
        markChanged(state);
        state.assigned_ = /* @__PURE__ */new Map();
        each(state.base_, key => {
          state.assigned_.set(key, false);
        });
        state.copy_.clear();
      }
    }
    forEach(cb, thisArg) {
      const state = this[DRAFT_STATE];
      latest(state).forEach((_value, key, _map) => {
        cb.call(thisArg, this.get(key), key, this);
      });
    }
    get(key) {
      const state = this[DRAFT_STATE];
      assertUnrevoked(state);
      const value = latest(state).get(key);
      if (state.finalized_ || !isDraftable(value)) {
        return value;
      }
      if (value !== state.base_.get(key)) {
        return value;
      }
      const draft = createProxy(value, state);
      prepareMapCopy(state);
      state.copy_.set(key, draft);
      return draft;
    }
    keys() {
      return latest(this[DRAFT_STATE]).keys();
    }
    values() {
      const iterator = this.keys();
      return {
        [Symbol.iterator]: () => this.values(),
        next: () => {
          const r = iterator.next();
          if (r.done) return r;
          const value = this.get(r.value);
          return {
            done: false,
            value
          };
        }
      };
    }
    entries() {
      const iterator = this.keys();
      return {
        [Symbol.iterator]: () => this.entries(),
        next: () => {
          const r = iterator.next();
          if (r.done) return r;
          const value = this.get(r.value);
          return {
            done: false,
            value: [r.value, value]
          };
        }
      };
    }
    [(DRAFT_STATE, Symbol.iterator)]() {
      return this.entries();
    }
  }
  function proxyMap_(target, parent) {
    return new DraftMap(target, parent);
  }
  function prepareMapCopy(state) {
    if (!state.copy_) {
      state.assigned_ = /* @__PURE__ */new Map();
      state.copy_ = new Map(state.base_);
    }
  }
  class DraftSet extends Set {
    constructor(target, parent) {
      super();
      this[DRAFT_STATE] = {
        type_: 3 /* Set */,
        parent_: parent,
        scope_: parent ? parent.scope_ : getCurrentScope(),
        modified_: false,
        finalized_: false,
        copy_: void 0,
        base_: target,
        draft_: this,
        drafts_: /* @__PURE__ */new Map(),
        revoked_: false,
        isManual_: false
      };
    }
    get size() {
      return latest(this[DRAFT_STATE]).size;
    }
    has(value) {
      const state = this[DRAFT_STATE];
      assertUnrevoked(state);
      if (!state.copy_) {
        return state.base_.has(value);
      }
      if (state.copy_.has(value)) return true;
      if (state.drafts_.has(value) && state.copy_.has(state.drafts_.get(value))) return true;
      return false;
    }
    add(value) {
      const state = this[DRAFT_STATE];
      assertUnrevoked(state);
      if (!this.has(value)) {
        prepareSetCopy(state);
        markChanged(state);
        state.copy_.add(value);
      }
      return this;
    }
    delete(value) {
      if (!this.has(value)) {
        return false;
      }
      const state = this[DRAFT_STATE];
      assertUnrevoked(state);
      prepareSetCopy(state);
      markChanged(state);
      return state.copy_.delete(value) || (state.drafts_.has(value) ? state.copy_.delete(state.drafts_.get(value)) : ( /* istanbul ignore next */
      false));
    }
    clear() {
      const state = this[DRAFT_STATE];
      assertUnrevoked(state);
      if (latest(state).size) {
        prepareSetCopy(state);
        markChanged(state);
        state.copy_.clear();
      }
    }
    values() {
      const state = this[DRAFT_STATE];
      assertUnrevoked(state);
      prepareSetCopy(state);
      return state.copy_.values();
    }
    entries() {
      const state = this[DRAFT_STATE];
      assertUnrevoked(state);
      prepareSetCopy(state);
      return state.copy_.entries();
    }
    keys() {
      return this.values();
    }
    [(DRAFT_STATE, Symbol.iterator)]() {
      return this.values();
    }
    forEach(cb, thisArg) {
      const iterator = this.values();
      let result = iterator.next();
      while (!result.done) {
        cb.call(thisArg, result.value, result.value, this);
        result = iterator.next();
      }
    }
  }
  function proxySet_(target, parent) {
    return new DraftSet(target, parent);
  }
  function prepareSetCopy(state) {
    if (!state.copy_) {
      state.copy_ = /* @__PURE__ */new Set();
      state.base_.forEach(value => {
        if (isDraftable(value)) {
          const draft = createProxy(value, state);
          state.drafts_.set(value, draft);
          state.copy_.add(draft);
        } else {
          state.copy_.add(value);
        }
      });
    }
  }
  function assertUnrevoked(state) {
    if (state.revoked_) die(3, JSON.stringify(latest(state)));
  }
  loadPlugin("MapSet", {
    proxyMap_,
    proxySet_
  });
}

// src/immer.ts
var immer = new Immer2();
var produce = immer.produce;
var produceWithPatches = immer.produceWithPatches.bind(immer);
var setAutoFreeze = immer.setAutoFreeze.bind(immer);
var setUseStrictShallowCopy = immer.setUseStrictShallowCopy.bind(immer);
var applyPatches = immer.applyPatches.bind(immer);
var createDraft = immer.createDraft.bind(immer);
var finishDraft = immer.finishDraft.bind(immer);
function castDraft(value) {
  return value;
}
function castImmutable(value) {
  return value;
}

//# sourceMappingURL=immer.mjs.map
;// CONCATENATED MODULE: ./node_modules/reselect/dist/reselect.mjs
// src/devModeChecks/identityFunctionCheck.ts
var runIdentityFunctionCheck = (resultFunc, inputSelectorsResults, outputSelectorResult) => {
  if (inputSelectorsResults.length === 1 && inputSelectorsResults[0] === outputSelectorResult) {
    let isInputSameAsOutput = false;
    try {
      const emptyObject = {};
      if (resultFunc(emptyObject) === emptyObject) isInputSameAsOutput = true;
    } catch {}
    if (isInputSameAsOutput) {
      let stack = void 0;
      try {
        throw new Error();
      } catch (e) {
        ;
        ({
          stack
        } = e);
      }
      console.warn("The result function returned its own inputs without modification. e.g\n`createSelector([state => state.todos], todos => todos)`\nThis could lead to inefficient memoization and unnecessary re-renders.\nEnsure transformation logic is in the result function, and extraction logic is in the input selectors.", {
        stack
      });
    }
  }
};

// src/devModeChecks/inputStabilityCheck.ts
var runInputStabilityCheck = (inputSelectorResultsObject, options, inputSelectorArgs) => {
  const {
    memoize,
    memoizeOptions
  } = options;
  const {
    inputSelectorResults,
    inputSelectorResultsCopy
  } = inputSelectorResultsObject;
  const createAnEmptyObject = memoize(() => ({}), ...memoizeOptions);
  const areInputSelectorResultsEqual = createAnEmptyObject.apply(null, inputSelectorResults) === createAnEmptyObject.apply(null, inputSelectorResultsCopy);
  if (!areInputSelectorResultsEqual) {
    let stack = void 0;
    try {
      throw new Error();
    } catch (e) {
      ;
      ({
        stack
      } = e);
    }
    console.warn("An input selector returned a different result when passed same arguments.\nThis means your output selector will likely run more frequently than intended.\nAvoid returning a new reference inside your input selector, e.g.\n`createSelector([state => state.todos.map(todo => todo.id)], todoIds => todoIds.length)`", {
      arguments: inputSelectorArgs,
      firstInputs: inputSelectorResults,
      secondInputs: inputSelectorResultsCopy,
      stack
    });
  }
};

// src/devModeChecks/setGlobalDevModeChecks.ts
var globalDevModeChecks = {
  inputStabilityCheck: "once",
  identityFunctionCheck: "once"
};
var setGlobalDevModeChecks = devModeChecks => {
  Object.assign(globalDevModeChecks, devModeChecks);
};

// src/utils.ts
var NOT_FOUND = /* @__PURE__ */(/* unused pure expression or super */ null && (Symbol("NOT_FOUND")));
function assertIsFunction(func, errorMessage = `expected a function, instead received ${typeof func}`) {
  if (typeof func !== "function") {
    throw new TypeError(errorMessage);
  }
}
function assertIsObject(object, errorMessage = `expected an object, instead received ${typeof object}`) {
  if (typeof object !== "object") {
    throw new TypeError(errorMessage);
  }
}
function assertIsArrayOfFunctions(array, errorMessage = `expected all items to be functions, instead received the following types: `) {
  if (!array.every(item => typeof item === "function")) {
    const itemTypes = array.map(item => typeof item === "function" ? `function ${item.name || "unnamed"}()` : typeof item).join(", ");
    throw new TypeError(`${errorMessage}[${itemTypes}]`);
  }
}
var ensureIsArray = item => {
  return Array.isArray(item) ? item : [item];
};
function getDependencies(createSelectorArgs) {
  const dependencies = Array.isArray(createSelectorArgs[0]) ? createSelectorArgs[0] : createSelectorArgs;
  assertIsArrayOfFunctions(dependencies, `createSelector expects all input-selectors to be functions, but received the following types: `);
  return dependencies;
}
function collectInputSelectorResults(dependencies, inputSelectorArgs) {
  const inputSelectorResults = [];
  const {
    length
  } = dependencies;
  for (let i = 0; i < length; i++) {
    inputSelectorResults.push(dependencies[i].apply(null, inputSelectorArgs));
  }
  return inputSelectorResults;
}
var getDevModeChecksExecutionInfo = (firstRun, devModeChecks) => {
  const {
    identityFunctionCheck,
    inputStabilityCheck
  } = {
    ...globalDevModeChecks,
    ...devModeChecks
  };
  return {
    identityFunctionCheck: {
      shouldRun: identityFunctionCheck === "always" || identityFunctionCheck === "once" && firstRun,
      run: runIdentityFunctionCheck
    },
    inputStabilityCheck: {
      shouldRun: inputStabilityCheck === "always" || inputStabilityCheck === "once" && firstRun,
      run: runInputStabilityCheck
    }
  };
};

// src/autotrackMemoize/autotracking.ts
var $REVISION = 0;
var CURRENT_TRACKER = null;
var Cell = class {
  revision = $REVISION;
  _value;
  _lastValue;
  _isEqual = tripleEq;
  constructor(initialValue, isEqual = tripleEq) {
    this._value = this._lastValue = initialValue;
    this._isEqual = isEqual;
  }
  // Whenever a storage value is read, it'll add itself to the current tracker if
  // one exists, entangling its state with that cache.
  get value() {
    CURRENT_TRACKER?.add(this);
    return this._value;
  }
  // Whenever a storage value is updated, we bump the global revision clock,
  // assign the revision for this storage to the new value, _and_ we schedule a
  // rerender. This is important, and it's what makes autotracking  _pull_
  // based. We don't actively tell the caches which depend on the storage that
  // anything has happened. Instead, we recompute the caches when needed.
  set value(newValue) {
    if (this.value === newValue) return;
    this._value = newValue;
    this.revision = ++$REVISION;
  }
};
function tripleEq(a, b) {
  return a === b;
}
var TrackingCache = class {
  _cachedValue;
  _cachedRevision = -1;
  _deps = [];
  hits = 0;
  fn;
  constructor(fn) {
    this.fn = fn;
  }
  clear() {
    this._cachedValue = void 0;
    this._cachedRevision = -1;
    this._deps = [];
    this.hits = 0;
  }
  get value() {
    if (this.revision > this._cachedRevision) {
      const {
        fn
      } = this;
      const currentTracker = /* @__PURE__ */new Set();
      const prevTracker = CURRENT_TRACKER;
      CURRENT_TRACKER = currentTracker;
      this._cachedValue = fn();
      CURRENT_TRACKER = prevTracker;
      this.hits++;
      this._deps = Array.from(currentTracker);
      this._cachedRevision = this.revision;
    }
    CURRENT_TRACKER?.add(this);
    return this._cachedValue;
  }
  get revision() {
    return Math.max(...this._deps.map(d => d.revision), 0);
  }
};
function getValue(cell) {
  if (!(cell instanceof Cell)) {
    console.warn("Not a valid cell! ", cell);
  }
  return cell.value;
}
function setValue(storage, value) {
  if (!(storage instanceof Cell)) {
    throw new TypeError("setValue must be passed a tracked store created with `createStorage`.");
  }
  storage.value = storage._lastValue = value;
}
function createCell(initialValue, isEqual = tripleEq) {
  return new Cell(initialValue, isEqual);
}
function createCache(fn) {
  assertIsFunction(fn, "the first parameter to `createCache` must be a function");
  return new TrackingCache(fn);
}

// src/autotrackMemoize/tracking.ts
var neverEq = (a, b) => false;
function createTag() {
  return createCell(null, neverEq);
}
function dirtyTag(tag, value) {
  setValue(tag, value);
}
var consumeCollection = node => {
  let tag = node.collectionTag;
  if (tag === null) {
    tag = node.collectionTag = createTag();
  }
  getValue(tag);
};
var dirtyCollection = node => {
  const tag = node.collectionTag;
  if (tag !== null) {
    dirtyTag(tag, null);
  }
};

// src/autotrackMemoize/proxy.ts
var REDUX_PROXY_LABEL = Symbol();
var nextId = 0;
var proto = Object.getPrototypeOf({});
var ObjectTreeNode = class {
  constructor(value) {
    this.value = value;
    this.value = value;
    this.tag.value = value;
  }
  proxy = new Proxy(this, objectProxyHandler);
  tag = createTag();
  tags = {};
  children = {};
  collectionTag = null;
  id = nextId++;
};
var objectProxyHandler = {
  get(node, key) {
    function calculateResult() {
      const {
        value
      } = node;
      const childValue = Reflect.get(value, key);
      if (typeof key === "symbol") {
        return childValue;
      }
      if (key in proto) {
        return childValue;
      }
      if (typeof childValue === "object" && childValue !== null) {
        let childNode = node.children[key];
        if (childNode === void 0) {
          childNode = node.children[key] = createNode(childValue);
        }
        if (childNode.tag) {
          getValue(childNode.tag);
        }
        return childNode.proxy;
      } else {
        let tag = node.tags[key];
        if (tag === void 0) {
          tag = node.tags[key] = createTag();
          tag.value = childValue;
        }
        getValue(tag);
        return childValue;
      }
    }
    const res = calculateResult();
    return res;
  },
  ownKeys(node) {
    consumeCollection(node);
    return Reflect.ownKeys(node.value);
  },
  getOwnPropertyDescriptor(node, prop) {
    return Reflect.getOwnPropertyDescriptor(node.value, prop);
  },
  has(node, prop) {
    return Reflect.has(node.value, prop);
  }
};
var ArrayTreeNode = class {
  constructor(value) {
    this.value = value;
    this.value = value;
    this.tag.value = value;
  }
  proxy = new Proxy([this], arrayProxyHandler);
  tag = createTag();
  tags = {};
  children = {};
  collectionTag = null;
  id = nextId++;
};
var arrayProxyHandler = {
  get([node], key) {
    if (key === "length") {
      consumeCollection(node);
    }
    return objectProxyHandler.get(node, key);
  },
  ownKeys([node]) {
    return objectProxyHandler.ownKeys(node);
  },
  getOwnPropertyDescriptor([node], prop) {
    return objectProxyHandler.getOwnPropertyDescriptor(node, prop);
  },
  has([node], prop) {
    return objectProxyHandler.has(node, prop);
  }
};
function createNode(value) {
  if (Array.isArray(value)) {
    return new ArrayTreeNode(value);
  }
  return new ObjectTreeNode(value);
}
function updateNode(node, newValue) {
  const {
    value,
    tags,
    children
  } = node;
  node.value = newValue;
  if (Array.isArray(value) && Array.isArray(newValue) && value.length !== newValue.length) {
    dirtyCollection(node);
  } else {
    if (value !== newValue) {
      let oldKeysSize = 0;
      let newKeysSize = 0;
      let anyKeysAdded = false;
      for (const _key in value) {
        oldKeysSize++;
      }
      for (const key in newValue) {
        newKeysSize++;
        if (!(key in value)) {
          anyKeysAdded = true;
          break;
        }
      }
      const isDifferent = anyKeysAdded || oldKeysSize !== newKeysSize;
      if (isDifferent) {
        dirtyCollection(node);
      }
    }
  }
  for (const key in tags) {
    const childValue = value[key];
    const newChildValue = newValue[key];
    if (childValue !== newChildValue) {
      dirtyCollection(node);
      dirtyTag(tags[key], newChildValue);
    }
    if (typeof newChildValue === "object" && newChildValue !== null) {
      delete tags[key];
    }
  }
  for (const key in children) {
    const childNode = children[key];
    const newChildValue = newValue[key];
    const childValue = childNode.value;
    if (childValue === newChildValue) {
      continue;
    } else if (typeof newChildValue === "object" && newChildValue !== null) {
      updateNode(childNode, newChildValue);
    } else {
      deleteNode(childNode);
      delete children[key];
    }
  }
}
function deleteNode(node) {
  if (node.tag) {
    dirtyTag(node.tag, null);
  }
  dirtyCollection(node);
  for (const key in node.tags) {
    dirtyTag(node.tags[key], null);
  }
  for (const key in node.children) {
    deleteNode(node.children[key]);
  }
}

// src/lruMemoize.ts
function createSingletonCache(equals) {
  let entry;
  return {
    get(key) {
      if (entry && equals(entry.key, key)) {
        return entry.value;
      }
      return NOT_FOUND;
    },
    put(key, value) {
      entry = {
        key,
        value
      };
    },
    getEntries() {
      return entry ? [entry] : [];
    },
    clear() {
      entry = void 0;
    }
  };
}
function createLruCache(maxSize, equals) {
  let entries = [];
  function get(key) {
    const cacheIndex = entries.findIndex(entry => equals(key, entry.key));
    if (cacheIndex > -1) {
      const entry = entries[cacheIndex];
      if (cacheIndex > 0) {
        entries.splice(cacheIndex, 1);
        entries.unshift(entry);
      }
      return entry.value;
    }
    return NOT_FOUND;
  }
  function put(key, value) {
    if (get(key) === NOT_FOUND) {
      entries.unshift({
        key,
        value
      });
      if (entries.length > maxSize) {
        entries.pop();
      }
    }
  }
  function getEntries() {
    return entries;
  }
  function clear() {
    entries = [];
  }
  return {
    get,
    put,
    getEntries,
    clear
  };
}
var referenceEqualityCheck = (a, b) => a === b;
function createCacheKeyComparator(equalityCheck) {
  return function areArgumentsShallowlyEqual(prev, next) {
    if (prev === null || next === null || prev.length !== next.length) {
      return false;
    }
    const {
      length
    } = prev;
    for (let i = 0; i < length; i++) {
      if (!equalityCheck(prev[i], next[i])) {
        return false;
      }
    }
    return true;
  };
}
function lruMemoize(func, equalityCheckOrOptions) {
  const providedOptions = typeof equalityCheckOrOptions === "object" ? equalityCheckOrOptions : {
    equalityCheck: equalityCheckOrOptions
  };
  const {
    equalityCheck = referenceEqualityCheck,
    maxSize = 1,
    resultEqualityCheck
  } = providedOptions;
  const comparator = createCacheKeyComparator(equalityCheck);
  let resultsCount = 0;
  const cache = maxSize <= 1 ? createSingletonCache(comparator) : createLruCache(maxSize, comparator);
  function memoized() {
    let value = cache.get(arguments);
    if (value === NOT_FOUND) {
      value = func.apply(null, arguments);
      resultsCount++;
      if (resultEqualityCheck) {
        const entries = cache.getEntries();
        const matchingEntry = entries.find(entry => resultEqualityCheck(entry.value, value));
        if (matchingEntry) {
          value = matchingEntry.value;
          resultsCount !== 0 && resultsCount--;
        }
      }
      cache.put(arguments, value);
    }
    return value;
  }
  memoized.clearCache = () => {
    cache.clear();
    memoized.resetResultsCount();
  };
  memoized.resultsCount = () => resultsCount;
  memoized.resetResultsCount = () => {
    resultsCount = 0;
  };
  return memoized;
}

// src/autotrackMemoize/autotrackMemoize.ts
function autotrackMemoize(func) {
  const node = createNode([]);
  let lastArgs = null;
  const shallowEqual = createCacheKeyComparator(referenceEqualityCheck);
  const cache = createCache(() => {
    const res = func.apply(null, node.proxy);
    return res;
  });
  function memoized() {
    if (!shallowEqual(lastArgs, arguments)) {
      updateNode(node, arguments);
      lastArgs = arguments;
    }
    return cache.value;
  }
  memoized.clearCache = () => {
    return cache.clear();
  };
  return memoized;
}

// src/weakMapMemoize.ts
var StrongRef = class {
  constructor(value) {
    this.value = value;
  }
  deref() {
    return this.value;
  }
};
var Ref = typeof WeakRef !== "undefined" ? WeakRef : StrongRef;
var UNTERMINATED = 0;
var TERMINATED = 1;
function createCacheNode() {
  return {
    s: UNTERMINATED,
    v: void 0,
    o: null,
    p: null
  };
}
function weakMapMemoize(func, options = {}) {
  let fnNode = createCacheNode();
  const {
    resultEqualityCheck
  } = options;
  let lastResult;
  let resultsCount = 0;
  function memoized() {
    let cacheNode = fnNode;
    const {
      length
    } = arguments;
    for (let i = 0, l = length; i < l; i++) {
      const arg = arguments[i];
      if (typeof arg === "function" || typeof arg === "object" && arg !== null) {
        let objectCache = cacheNode.o;
        if (objectCache === null) {
          cacheNode.o = objectCache = /* @__PURE__ */new WeakMap();
        }
        const objectNode = objectCache.get(arg);
        if (objectNode === void 0) {
          cacheNode = createCacheNode();
          objectCache.set(arg, cacheNode);
        } else {
          cacheNode = objectNode;
        }
      } else {
        let primitiveCache = cacheNode.p;
        if (primitiveCache === null) {
          cacheNode.p = primitiveCache = /* @__PURE__ */new Map();
        }
        const primitiveNode = primitiveCache.get(arg);
        if (primitiveNode === void 0) {
          cacheNode = createCacheNode();
          primitiveCache.set(arg, cacheNode);
        } else {
          cacheNode = primitiveNode;
        }
      }
    }
    const terminatedNode = cacheNode;
    let result;
    if (cacheNode.s === TERMINATED) {
      result = cacheNode.v;
    } else {
      result = func.apply(null, arguments);
      resultsCount++;
      if (resultEqualityCheck) {
        const lastResultValue = lastResult?.deref?.() ?? lastResult;
        if (lastResultValue != null && resultEqualityCheck(lastResultValue, result)) {
          result = lastResultValue;
          resultsCount !== 0 && resultsCount--;
        }
        const needsWeakRef = typeof result === "object" && result !== null || typeof result === "function";
        lastResult = needsWeakRef ? new Ref(result) : result;
      }
    }
    terminatedNode.s = TERMINATED;
    terminatedNode.v = result;
    return result;
  }
  memoized.clearCache = () => {
    fnNode = createCacheNode();
    memoized.resetResultsCount();
  };
  memoized.resultsCount = () => resultsCount;
  memoized.resetResultsCount = () => {
    resultsCount = 0;
  };
  return memoized;
}

// src/createSelectorCreator.ts
function createSelectorCreator(memoizeOrOptions, ...memoizeOptionsFromArgs) {
  const createSelectorCreatorOptions = typeof memoizeOrOptions === "function" ? {
    memoize: memoizeOrOptions,
    memoizeOptions: memoizeOptionsFromArgs
  } : memoizeOrOptions;
  const createSelector2 = (...createSelectorArgs) => {
    let recomputations = 0;
    let dependencyRecomputations = 0;
    let lastResult;
    let directlyPassedOptions = {};
    let resultFunc = createSelectorArgs.pop();
    if (typeof resultFunc === "object") {
      directlyPassedOptions = resultFunc;
      resultFunc = createSelectorArgs.pop();
    }
    assertIsFunction(resultFunc, `createSelector expects an output function after the inputs, but received: [${typeof resultFunc}]`);
    const combinedOptions = {
      ...createSelectorCreatorOptions,
      ...directlyPassedOptions
    };
    const {
      memoize,
      memoizeOptions = [],
      argsMemoize = weakMapMemoize,
      argsMemoizeOptions = [],
      devModeChecks = {}
    } = combinedOptions;
    const finalMemoizeOptions = ensureIsArray(memoizeOptions);
    const finalArgsMemoizeOptions = ensureIsArray(argsMemoizeOptions);
    const dependencies = getDependencies(createSelectorArgs);
    const memoizedResultFunc = memoize(function recomputationWrapper() {
      recomputations++;
      return resultFunc.apply(null, arguments);
    }, ...finalMemoizeOptions);
    let firstRun = true;
    const selector = argsMemoize(function dependenciesChecker() {
      dependencyRecomputations++;
      const inputSelectorResults = collectInputSelectorResults(dependencies, arguments);
      lastResult = memoizedResultFunc.apply(null, inputSelectorResults);
      if (false) {}
      return lastResult;
    }, ...finalArgsMemoizeOptions);
    return Object.assign(selector, {
      resultFunc,
      memoizedResultFunc,
      dependencies,
      dependencyRecomputations: () => dependencyRecomputations,
      resetDependencyRecomputations: () => {
        dependencyRecomputations = 0;
      },
      lastResult: () => lastResult,
      recomputations: () => recomputations,
      resetRecomputations: () => {
        recomputations = 0;
      },
      memoize,
      argsMemoize
    });
  };
  Object.assign(createSelector2, {
    withTypes: () => createSelector2
  });
  return createSelector2;
}
var createSelector = /* @__PURE__ */createSelectorCreator(weakMapMemoize);

// src/createStructuredSelector.ts
var createStructuredSelector = Object.assign((inputSelectorsObject, selectorCreator = createSelector) => {
  assertIsObject(inputSelectorsObject, `createStructuredSelector expects first argument to be an object where each property is a selector, instead received a ${typeof inputSelectorsObject}`);
  const inputSelectorKeys = Object.keys(inputSelectorsObject);
  const dependencies = inputSelectorKeys.map(key => inputSelectorsObject[key]);
  const structuredSelector = selectorCreator(dependencies, (...inputSelectorResults) => {
    return inputSelectorResults.reduce((composition, value, index) => {
      composition[inputSelectorKeys[index]] = value;
      return composition;
    }, {});
  });
  return structuredSelector;
}, {
  withTypes: () => createStructuredSelector
});

//# sourceMappingURL=reselect.mjs.map
;// CONCATENATED MODULE: ./node_modules/redux/dist/redux.mjs
// src/utils/formatProdErrorMessage.ts
function formatProdErrorMessage(code) {
  return `Minified Redux error #${code}; visit https://redux.js.org/Errors?code=${code} for the full message or use the non-minified dev environment for full errors. `;
}

// src/utils/symbol-observable.ts
var $$observable = /* @__PURE__ */(() => typeof Symbol === "function" && Symbol.observable || "@@observable")();
var symbol_observable_default = $$observable;

// src/utils/actionTypes.ts
var randomString = () => Math.random().toString(36).substring(7).split("").join(".");
var ActionTypes = {
  INIT: `@@redux/INIT${/* @__PURE__ */randomString()}`,
  REPLACE: `@@redux/REPLACE${/* @__PURE__ */randomString()}`,
  PROBE_UNKNOWN_ACTION: () => `@@redux/PROBE_UNKNOWN_ACTION${randomString()}`
};
var actionTypes_default = ActionTypes;

// src/utils/isPlainObject.ts
function redux_isPlainObject(obj) {
  if (typeof obj !== "object" || obj === null) return false;
  let proto = obj;
  while (Object.getPrototypeOf(proto) !== null) {
    proto = Object.getPrototypeOf(proto);
  }
  return Object.getPrototypeOf(obj) === proto || Object.getPrototypeOf(obj) === null;
}

// src/utils/kindOf.ts
function miniKindOf(val) {
  if (val === void 0) return "undefined";
  if (val === null) return "null";
  const type = typeof val;
  switch (type) {
    case "boolean":
    case "string":
    case "number":
    case "symbol":
    case "function":
      {
        return type;
      }
  }
  if (Array.isArray(val)) return "array";
  if (isDate(val)) return "date";
  if (isError(val)) return "error";
  const constructorName = ctorName(val);
  switch (constructorName) {
    case "Symbol":
    case "Promise":
    case "WeakMap":
    case "WeakSet":
    case "Map":
    case "Set":
      return constructorName;
  }
  return Object.prototype.toString.call(val).slice(8, -1).toLowerCase().replace(/\s/g, "");
}
function ctorName(val) {
  return typeof val.constructor === "function" ? val.constructor.name : null;
}
function isError(val) {
  return val instanceof Error || typeof val.message === "string" && val.constructor && typeof val.constructor.stackTraceLimit === "number";
}
function isDate(val) {
  if (val instanceof Date) return true;
  return typeof val.toDateString === "function" && typeof val.getDate === "function" && typeof val.setDate === "function";
}
function kindOf(val) {
  let typeOfVal = typeof val;
  if (false) {}
  return typeOfVal;
}

// src/createStore.ts
function createStore(reducer, preloadedState, enhancer) {
  if (typeof reducer !== "function") {
    throw new Error( true ? formatProdErrorMessage(2) : 0);
  }
  if (typeof preloadedState === "function" && typeof enhancer === "function" || typeof enhancer === "function" && typeof arguments[3] === "function") {
    throw new Error( true ? formatProdErrorMessage(0) : 0);
  }
  if (typeof preloadedState === "function" && typeof enhancer === "undefined") {
    enhancer = preloadedState;
    preloadedState = void 0;
  }
  if (typeof enhancer !== "undefined") {
    if (typeof enhancer !== "function") {
      throw new Error( true ? formatProdErrorMessage(1) : 0);
    }
    return enhancer(createStore)(reducer, preloadedState);
  }
  let currentReducer = reducer;
  let currentState = preloadedState;
  let currentListeners = /* @__PURE__ */new Map();
  let nextListeners = currentListeners;
  let listenerIdCounter = 0;
  let isDispatching = false;
  function ensureCanMutateNextListeners() {
    if (nextListeners === currentListeners) {
      nextListeners = /* @__PURE__ */new Map();
      currentListeners.forEach((listener, key) => {
        nextListeners.set(key, listener);
      });
    }
  }
  function getState() {
    if (isDispatching) {
      throw new Error( true ? formatProdErrorMessage(3) : 0);
    }
    return currentState;
  }
  function subscribe(listener) {
    if (typeof listener !== "function") {
      throw new Error( true ? formatProdErrorMessage(4) : 0);
    }
    if (isDispatching) {
      throw new Error( true ? formatProdErrorMessage(5) : 0);
    }
    let isSubscribed = true;
    ensureCanMutateNextListeners();
    const listenerId = listenerIdCounter++;
    nextListeners.set(listenerId, listener);
    return function unsubscribe() {
      if (!isSubscribed) {
        return;
      }
      if (isDispatching) {
        throw new Error( true ? formatProdErrorMessage(6) : 0);
      }
      isSubscribed = false;
      ensureCanMutateNextListeners();
      nextListeners.delete(listenerId);
      currentListeners = null;
    };
  }
  function dispatch(action) {
    if (!redux_isPlainObject(action)) {
      throw new Error( true ? formatProdErrorMessage(7) : 0);
    }
    if (typeof action.type === "undefined") {
      throw new Error( true ? formatProdErrorMessage(8) : 0);
    }
    if (typeof action.type !== "string") {
      throw new Error( true ? formatProdErrorMessage(17) : 0);
    }
    if (isDispatching) {
      throw new Error( true ? formatProdErrorMessage(9) : 0);
    }
    try {
      isDispatching = true;
      currentState = currentReducer(currentState, action);
    } finally {
      isDispatching = false;
    }
    const listeners = currentListeners = nextListeners;
    listeners.forEach(listener => {
      listener();
    });
    return action;
  }
  function replaceReducer(nextReducer) {
    if (typeof nextReducer !== "function") {
      throw new Error( true ? formatProdErrorMessage(10) : 0);
    }
    currentReducer = nextReducer;
    dispatch({
      type: actionTypes_default.REPLACE
    });
  }
  function observable() {
    const outerSubscribe = subscribe;
    return {
      /**
       * The minimal observable subscription method.
       * @param observer Any object that can be used as an observer.
       * The observer object should have a `next` method.
       * @returns An object with an `unsubscribe` method that can
       * be used to unsubscribe the observable from the store, and prevent further
       * emission of values from the observable.
       */
      subscribe(observer) {
        if (typeof observer !== "object" || observer === null) {
          throw new Error( true ? formatProdErrorMessage(11) : 0);
        }
        function observeState() {
          const observerAsObserver = observer;
          if (observerAsObserver.next) {
            observerAsObserver.next(getState());
          }
        }
        observeState();
        const unsubscribe = outerSubscribe(observeState);
        return {
          unsubscribe
        };
      },
      [symbol_observable_default]() {
        return this;
      }
    };
  }
  dispatch({
    type: actionTypes_default.INIT
  });
  const store = {
    dispatch,
    subscribe,
    getState,
    replaceReducer,
    [symbol_observable_default]: observable
  };
  return store;
}
function legacy_createStore(reducer, preloadedState, enhancer) {
  return createStore(reducer, preloadedState, enhancer);
}

// src/utils/warning.ts
function warning(message) {
  if (typeof console !== "undefined" && typeof console.error === "function") {
    console.error(message);
  }
  try {
    throw new Error(message);
  } catch (e) {}
}

// src/combineReducers.ts
function getUnexpectedStateShapeWarningMessage(inputState, reducers, action, unexpectedKeyCache) {
  const reducerKeys = Object.keys(reducers);
  const argumentName = action && action.type === actionTypes_default.INIT ? "preloadedState argument passed to createStore" : "previous state received by the reducer";
  if (reducerKeys.length === 0) {
    return "Store does not have a valid reducer. Make sure the argument passed to combineReducers is an object whose values are reducers.";
  }
  if (!redux_isPlainObject(inputState)) {
    return `The ${argumentName} has unexpected type of "${kindOf(inputState)}". Expected argument to be an object with the following keys: "${reducerKeys.join('", "')}"`;
  }
  const unexpectedKeys = Object.keys(inputState).filter(key => !reducers.hasOwnProperty(key) && !unexpectedKeyCache[key]);
  unexpectedKeys.forEach(key => {
    unexpectedKeyCache[key] = true;
  });
  if (action && action.type === actionTypes_default.REPLACE) return;
  if (unexpectedKeys.length > 0) {
    return `Unexpected ${unexpectedKeys.length > 1 ? "keys" : "key"} "${unexpectedKeys.join('", "')}" found in ${argumentName}. Expected to find one of the known reducer keys instead: "${reducerKeys.join('", "')}". Unexpected keys will be ignored.`;
  }
}
function assertReducerShape(reducers) {
  Object.keys(reducers).forEach(key => {
    const reducer = reducers[key];
    const initialState = reducer(void 0, {
      type: actionTypes_default.INIT
    });
    if (typeof initialState === "undefined") {
      throw new Error( true ? formatProdErrorMessage(12) : 0);
    }
    if (typeof reducer(void 0, {
      type: actionTypes_default.PROBE_UNKNOWN_ACTION()
    }) === "undefined") {
      throw new Error( true ? formatProdErrorMessage(13) : 0);
    }
  });
}
function combineReducers(reducers) {
  const reducerKeys = Object.keys(reducers);
  const finalReducers = {};
  for (let i = 0; i < reducerKeys.length; i++) {
    const key = reducerKeys[i];
    if (false) {}
    if (typeof reducers[key] === "function") {
      finalReducers[key] = reducers[key];
    }
  }
  const finalReducerKeys = Object.keys(finalReducers);
  let unexpectedKeyCache;
  if (false) {}
  let shapeAssertionError;
  try {
    assertReducerShape(finalReducers);
  } catch (e) {
    shapeAssertionError = e;
  }
  return function combination(state = {}, action) {
    if (shapeAssertionError) {
      throw shapeAssertionError;
    }
    if (false) {}
    let hasChanged = false;
    const nextState = {};
    for (let i = 0; i < finalReducerKeys.length; i++) {
      const key = finalReducerKeys[i];
      const reducer = finalReducers[key];
      const previousStateForKey = state[key];
      const nextStateForKey = reducer(previousStateForKey, action);
      if (typeof nextStateForKey === "undefined") {
        const actionType = action && action.type;
        throw new Error( true ? formatProdErrorMessage(14) : 0);
      }
      nextState[key] = nextStateForKey;
      hasChanged = hasChanged || nextStateForKey !== previousStateForKey;
    }
    hasChanged = hasChanged || finalReducerKeys.length !== Object.keys(state).length;
    return hasChanged ? nextState : state;
  };
}

// src/bindActionCreators.ts
function bindActionCreator(actionCreator, dispatch) {
  return function (...args) {
    return dispatch(actionCreator.apply(this, args));
  };
}
function bindActionCreators(actionCreators, dispatch) {
  if (typeof actionCreators === "function") {
    return bindActionCreator(actionCreators, dispatch);
  }
  if (typeof actionCreators !== "object" || actionCreators === null) {
    throw new Error( true ? formatProdErrorMessage(16) : 0);
  }
  const boundActionCreators = {};
  for (const key in actionCreators) {
    const actionCreator = actionCreators[key];
    if (typeof actionCreator === "function") {
      boundActionCreators[key] = bindActionCreator(actionCreator, dispatch);
    }
  }
  return boundActionCreators;
}

// src/compose.ts
function compose(...funcs) {
  if (funcs.length === 0) {
    return arg => arg;
  }
  if (funcs.length === 1) {
    return funcs[0];
  }
  return funcs.reduce((a, b) => (...args) => a(b(...args)));
}

// src/applyMiddleware.ts
function applyMiddleware(...middlewares) {
  return createStore2 => (reducer, preloadedState) => {
    const store = createStore2(reducer, preloadedState);
    let dispatch = () => {
      throw new Error( true ? formatProdErrorMessage(15) : 0);
    };
    const middlewareAPI = {
      getState: store.getState,
      dispatch: (action, ...args) => dispatch(action, ...args)
    };
    const chain = middlewares.map(middleware => middleware(middlewareAPI));
    dispatch = compose(...chain)(store.dispatch);
    return {
      ...store,
      dispatch
    };
  };
}

// src/utils/isAction.ts
function redux_isAction(action) {
  return redux_isPlainObject(action) && "type" in action && typeof action.type === "string";
}

//# sourceMappingURL=redux.mjs.map
;// CONCATENATED MODULE: ./node_modules/redux-thunk/dist/redux-thunk.mjs
// src/index.ts
function createThunkMiddleware(extraArgument) {
  const middleware = ({
    dispatch,
    getState
  }) => next => action => {
    if (typeof action === "function") {
      return action(dispatch, getState, extraArgument);
    }
    return next(action);
  };
  return middleware;
}
var redux_thunk_thunk = createThunkMiddleware();
var withExtraArgument = createThunkMiddleware;

;// CONCATENATED MODULE: ./node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs

// src/index.ts




// src/createDraftSafeSelector.ts


var createDraftSafeSelectorCreator = (...args) => {
  const createSelector2 = createSelectorCreator(...args);
  const createDraftSafeSelector2 = Object.assign((...args2) => {
    const selector = createSelector2(...args2);
    const wrappedSelector = (value, ...rest) => selector(isDraft(value) ? current(value) : value, ...rest);
    Object.assign(wrappedSelector, selector);
    return wrappedSelector;
  }, {
    withTypes: () => createDraftSafeSelector2
  });
  return createDraftSafeSelector2;
};
var createDraftSafeSelector = /* @__PURE__ */createDraftSafeSelectorCreator(weakMapMemoize);

// src/configureStore.ts


// src/devtoolsExtension.ts

var composeWithDevTools = typeof window !== "undefined" && window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ ? window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ : function () {
  if (arguments.length === 0) return void 0;
  if (typeof arguments[0] === "object") return compose;
  return compose.apply(null, arguments);
};
var devToolsEnhancer = typeof window !== "undefined" && window.__REDUX_DEVTOOLS_EXTENSION__ ? window.__REDUX_DEVTOOLS_EXTENSION__ : function () {
  return function (noop3) {
    return noop3;
  };
};

// src/getDefaultMiddleware.ts


// src/createAction.ts


// src/tsHelpers.ts
var hasMatchFunction = v => {
  return v && typeof v.match === "function";
};

// src/createAction.ts
function createAction(type, prepareAction) {
  function actionCreator(...args) {
    if (prepareAction) {
      let prepared = prepareAction(...args);
      if (!prepared) {
        throw new Error( true ? redux_toolkit_modern_formatProdErrorMessage(0) : 0);
      }
      return {
        type,
        payload: prepared.payload,
        ...("meta" in prepared && {
          meta: prepared.meta
        }),
        ...("error" in prepared && {
          error: prepared.error
        })
      };
    }
    return {
      type,
      payload: args[0]
    };
  }
  actionCreator.toString = () => `${type}`;
  actionCreator.type = type;
  actionCreator.match = action => redux_isAction(action) && action.type === type;
  return actionCreator;
}
function isActionCreator(action) {
  return typeof action === "function" && "type" in action &&
  // hasMatchFunction only wants Matchers but I don't see the point in rewriting it
  hasMatchFunction(action);
}
function isFSA(action) {
  return isAction(action) && Object.keys(action).every(isValidKey);
}
function isValidKey(key) {
  return ["type", "payload", "error", "meta"].indexOf(key) > -1;
}

// src/actionCreatorInvariantMiddleware.ts
function getMessage(type) {
  const splitType = type ? `${type}`.split("/") : [];
  const actionName = splitType[splitType.length - 1] || "actionCreator";
  return `Detected an action creator with type "${type || "unknown"}" being dispatched. 
Make sure you're calling the action creator before dispatching, i.e. \`dispatch(${actionName}())\` instead of \`dispatch(${actionName})\`. This is necessary even if the action has no payload.`;
}
function createActionCreatorInvariantMiddleware(options = {}) {
  if (true) {
    return () => next => action => next(action);
  }
  const {
    isActionCreator: isActionCreator2 = isActionCreator
  } = options;
  return () => next => action => {
    if (isActionCreator2(action)) {
      console.warn(getMessage(action.type));
    }
    return next(action);
  };
}

// src/utils.ts

function getTimeMeasureUtils(maxDelay, fnName) {
  let elapsed = 0;
  return {
    measureTime(fn) {
      const started = Date.now();
      try {
        return fn();
      } finally {
        const finished = Date.now();
        elapsed += finished - started;
      }
    },
    warnIfExceeded() {
      if (elapsed > maxDelay) {
        console.warn(`${fnName} took ${elapsed}ms, which is more than the warning threshold of ${maxDelay}ms. 
If your state or actions are very large, you may want to disable the middleware as it might cause too much of a slowdown in development mode. See https://redux-toolkit.js.org/api/getDefaultMiddleware for instructions.
It is disabled in production builds, so you don't need to worry about that.`);
      }
    }
  };
}
var Tuple = class _Tuple extends Array {
  constructor(...items) {
    super(...items);
    Object.setPrototypeOf(this, _Tuple.prototype);
  }
  static get [Symbol.species]() {
    return _Tuple;
  }
  concat(...arr) {
    return super.concat.apply(this, arr);
  }
  prepend(...arr) {
    if (arr.length === 1 && Array.isArray(arr[0])) {
      return new _Tuple(...arr[0].concat(this));
    }
    return new _Tuple(...arr.concat(this));
  }
};
function freezeDraftable(val) {
  return isDraftable(val) ? produce(val, () => {}) : val;
}
function getOrInsertComputed(map, key, compute) {
  if (map.has(key)) return map.get(key);
  return map.set(key, compute(key)).get(key);
}

// src/immutableStateInvariantMiddleware.ts
function isImmutableDefault(value) {
  return typeof value !== "object" || value == null || Object.isFrozen(value);
}
function trackForMutations(isImmutable, ignorePaths, obj) {
  const trackedProperties = trackProperties(isImmutable, ignorePaths, obj);
  return {
    detectMutations() {
      return detectMutations(isImmutable, ignorePaths, trackedProperties, obj);
    }
  };
}
function trackProperties(isImmutable, ignorePaths = [], obj, path = "", checkedObjects = /* @__PURE__ */new Set()) {
  const tracked = {
    value: obj
  };
  if (!isImmutable(obj) && !checkedObjects.has(obj)) {
    checkedObjects.add(obj);
    tracked.children = {};
    for (const key in obj) {
      const childPath = path ? path + "." + key : key;
      if (ignorePaths.length && ignorePaths.indexOf(childPath) !== -1) {
        continue;
      }
      tracked.children[key] = trackProperties(isImmutable, ignorePaths, obj[key], childPath);
    }
  }
  return tracked;
}
function detectMutations(isImmutable, ignoredPaths = [], trackedProperty, obj, sameParentRef = false, path = "") {
  const prevObj = trackedProperty ? trackedProperty.value : void 0;
  const sameRef = prevObj === obj;
  if (sameParentRef && !sameRef && !Number.isNaN(obj)) {
    return {
      wasMutated: true,
      path
    };
  }
  if (isImmutable(prevObj) || isImmutable(obj)) {
    return {
      wasMutated: false
    };
  }
  const keysToDetect = {};
  for (let key in trackedProperty.children) {
    keysToDetect[key] = true;
  }
  for (let key in obj) {
    keysToDetect[key] = true;
  }
  const hasIgnoredPaths = ignoredPaths.length > 0;
  for (let key in keysToDetect) {
    const nestedPath = path ? path + "." + key : key;
    if (hasIgnoredPaths) {
      const hasMatches = ignoredPaths.some(ignored => {
        if (ignored instanceof RegExp) {
          return ignored.test(nestedPath);
        }
        return nestedPath === ignored;
      });
      if (hasMatches) {
        continue;
      }
    }
    const result = detectMutations(isImmutable, ignoredPaths, trackedProperty.children[key], obj[key], sameRef, nestedPath);
    if (result.wasMutated) {
      return result;
    }
  }
  return {
    wasMutated: false
  };
}
function createImmutableStateInvariantMiddleware(options = {}) {
  if (true) {
    return () => next => action => next(action);
  } else { var stringify, getSerialize; }
}

// src/serializableStateInvariantMiddleware.ts

function isPlain(val) {
  const type = typeof val;
  return val == null || type === "string" || type === "boolean" || type === "number" || Array.isArray(val) || isPlainObject(val);
}
function findNonSerializableValue(value, path = "", isSerializable = isPlain, getEntries, ignoredPaths = [], cache) {
  let foundNestedSerializable;
  if (!isSerializable(value)) {
    return {
      keyPath: path || "<root>",
      value
    };
  }
  if (typeof value !== "object" || value === null) {
    return false;
  }
  if (cache?.has(value)) return false;
  const entries = getEntries != null ? getEntries(value) : Object.entries(value);
  const hasIgnoredPaths = ignoredPaths.length > 0;
  for (const [key, nestedValue] of entries) {
    const nestedPath = path ? path + "." + key : key;
    if (hasIgnoredPaths) {
      const hasMatches = ignoredPaths.some(ignored => {
        if (ignored instanceof RegExp) {
          return ignored.test(nestedPath);
        }
        return nestedPath === ignored;
      });
      if (hasMatches) {
        continue;
      }
    }
    if (!isSerializable(nestedValue)) {
      return {
        keyPath: nestedPath,
        value: nestedValue
      };
    }
    if (typeof nestedValue === "object") {
      foundNestedSerializable = findNonSerializableValue(nestedValue, nestedPath, isSerializable, getEntries, ignoredPaths, cache);
      if (foundNestedSerializable) {
        return foundNestedSerializable;
      }
    }
  }
  if (cache && isNestedFrozen(value)) cache.add(value);
  return false;
}
function isNestedFrozen(value) {
  if (!Object.isFrozen(value)) return false;
  for (const nestedValue of Object.values(value)) {
    if (typeof nestedValue !== "object" || nestedValue === null) continue;
    if (!isNestedFrozen(nestedValue)) return false;
  }
  return true;
}
function createSerializableStateInvariantMiddleware(options = {}) {
  if (true) {
    return () => next => action => next(action);
  } else {}
}

// src/getDefaultMiddleware.ts
function isBoolean(x) {
  return typeof x === "boolean";
}
var buildGetDefaultMiddleware = () => function getDefaultMiddleware(options) {
  const {
    thunk = true,
    immutableCheck = true,
    serializableCheck = true,
    actionCreatorCheck = true
  } = options ?? {};
  let middlewareArray = new Tuple();
  if (thunk) {
    if (isBoolean(thunk)) {
      middlewareArray.push(redux_thunk_thunk);
    } else {
      middlewareArray.push(withExtraArgument(thunk.extraArgument));
    }
  }
  if (false) {}
  return middlewareArray;
};

// src/autoBatchEnhancer.ts
var SHOULD_AUTOBATCH = "RTK_autoBatch";
var prepareAutoBatched = () => payload => ({
  payload,
  meta: {
    [SHOULD_AUTOBATCH]: true
  }
});
var createQueueWithTimer = timeout => {
  return notify => {
    setTimeout(notify, timeout);
  };
};
var autoBatchEnhancer = (options = {
  type: "raf"
}) => next => (...args) => {
  const store = next(...args);
  let notifying = true;
  let shouldNotifyAtEndOfTick = false;
  let notificationQueued = false;
  const listeners = /* @__PURE__ */new Set();
  const queueCallback = options.type === "tick" ? queueMicrotask : options.type === "raf" ?
  // requestAnimationFrame won't exist in SSR environments. Fall back to a vague approximation just to keep from erroring.
  typeof window !== "undefined" && window.requestAnimationFrame ? window.requestAnimationFrame : createQueueWithTimer(10) : options.type === "callback" ? options.queueNotification : createQueueWithTimer(options.timeout);
  const notifyListeners = () => {
    notificationQueued = false;
    if (shouldNotifyAtEndOfTick) {
      shouldNotifyAtEndOfTick = false;
      listeners.forEach(l => l());
    }
  };
  return Object.assign({}, store, {
    // Override the base `store.subscribe` method to keep original listeners
    // from running if we're delaying notifications
    subscribe(listener2) {
      const wrappedListener = () => notifying && listener2();
      const unsubscribe = store.subscribe(wrappedListener);
      listeners.add(listener2);
      return () => {
        unsubscribe();
        listeners.delete(listener2);
      };
    },
    // Override the base `store.dispatch` method so that we can check actions
    // for the `shouldAutoBatch` flag and determine if batching is active
    dispatch(action) {
      try {
        notifying = !action?.meta?.[SHOULD_AUTOBATCH];
        shouldNotifyAtEndOfTick = !notifying;
        if (shouldNotifyAtEndOfTick) {
          if (!notificationQueued) {
            notificationQueued = true;
            queueCallback(notifyListeners);
          }
        }
        return store.dispatch(action);
      } finally {
        notifying = true;
      }
    }
  });
};

// src/getDefaultEnhancers.ts
var buildGetDefaultEnhancers = middlewareEnhancer => function getDefaultEnhancers(options) {
  const {
    autoBatch = true
  } = options ?? {};
  let enhancerArray = new Tuple(middlewareEnhancer);
  if (autoBatch) {
    enhancerArray.push(autoBatchEnhancer(typeof autoBatch === "object" ? autoBatch : void 0));
  }
  return enhancerArray;
};

// src/configureStore.ts
function configureStore(options) {
  const getDefaultMiddleware = buildGetDefaultMiddleware();
  const {
    reducer = void 0,
    middleware,
    devTools = true,
    preloadedState = void 0,
    enhancers = void 0
  } = options || {};
  let rootReducer;
  if (typeof reducer === "function") {
    rootReducer = reducer;
  } else if (redux_isPlainObject(reducer)) {
    rootReducer = combineReducers(reducer);
  } else {
    throw new Error( true ? redux_toolkit_modern_formatProdErrorMessage(1) : 0);
  }
  if (false) {}
  let finalMiddleware;
  if (typeof middleware === "function") {
    finalMiddleware = middleware(getDefaultMiddleware);
    if (false) {}
  } else {
    finalMiddleware = getDefaultMiddleware();
  }
  if (false) {}
  let finalCompose = compose;
  if (devTools) {
    finalCompose = composeWithDevTools({
      // Enable capture of stack traces for dispatched Redux actions
      trace: "production" !== "production",
      ...(typeof devTools === "object" && devTools)
    });
  }
  const middlewareEnhancer = applyMiddleware(...finalMiddleware);
  const getDefaultEnhancers = buildGetDefaultEnhancers(middlewareEnhancer);
  if (false) {}
  let storeEnhancers = typeof enhancers === "function" ? enhancers(getDefaultEnhancers) : getDefaultEnhancers();
  if (false) {}
  if (false) {}
  if (false) {}
  const composedEnhancer = finalCompose(...storeEnhancers);
  return createStore(rootReducer, preloadedState, composedEnhancer);
}

// src/createReducer.ts


// src/mapBuilders.ts
function executeReducerBuilderCallback(builderCallback) {
  const actionsMap = {};
  const actionMatchers = [];
  let defaultCaseReducer;
  const builder = {
    addCase(typeOrActionCreator, reducer) {
      if (false) {}
      const type = typeof typeOrActionCreator === "string" ? typeOrActionCreator : typeOrActionCreator.type;
      if (!type) {
        throw new Error( true ? redux_toolkit_modern_formatProdErrorMessage(28) : 0);
      }
      if (type in actionsMap) {
        throw new Error( true ? redux_toolkit_modern_formatProdErrorMessage(29) : 0);
      }
      actionsMap[type] = reducer;
      return builder;
    },
    addMatcher(matcher, reducer) {
      if (false) {}
      actionMatchers.push({
        matcher,
        reducer
      });
      return builder;
    },
    addDefaultCase(reducer) {
      if (false) {}
      defaultCaseReducer = reducer;
      return builder;
    }
  };
  builderCallback(builder);
  return [actionsMap, actionMatchers, defaultCaseReducer];
}

// src/createReducer.ts
function isStateFunction(x) {
  return typeof x === "function";
}
function createReducer(initialState, mapOrBuilderCallback) {
  if (false) {}
  let [actionsMap, finalActionMatchers, finalDefaultCaseReducer] = executeReducerBuilderCallback(mapOrBuilderCallback);
  let getInitialState;
  if (isStateFunction(initialState)) {
    getInitialState = () => freezeDraftable(initialState());
  } else {
    const frozenInitialState = freezeDraftable(initialState);
    getInitialState = () => frozenInitialState;
  }
  function reducer(state = getInitialState(), action) {
    let caseReducers = [actionsMap[action.type], ...finalActionMatchers.filter(({
      matcher
    }) => matcher(action)).map(({
      reducer: reducer2
    }) => reducer2)];
    if (caseReducers.filter(cr => !!cr).length === 0) {
      caseReducers = [finalDefaultCaseReducer];
    }
    return caseReducers.reduce((previousState, caseReducer) => {
      if (caseReducer) {
        if (isDraft(previousState)) {
          const draft = previousState;
          const result = caseReducer(draft, action);
          if (result === void 0) {
            return previousState;
          }
          return result;
        } else if (!isDraftable(previousState)) {
          const result = caseReducer(previousState, action);
          if (result === void 0) {
            if (previousState === null) {
              return previousState;
            }
            throw Error("A case reducer on a non-draftable value must not return undefined");
          }
          return result;
        } else {
          return produce(previousState, draft => {
            return caseReducer(draft, action);
          });
        }
      }
      return previousState;
    }, state);
  }
  reducer.getInitialState = getInitialState;
  return reducer;
}

// src/matchers.ts
var matches = (matcher, action) => {
  if (hasMatchFunction(matcher)) {
    return matcher.match(action);
  } else {
    return matcher(action);
  }
};
function isAnyOf(...matchers) {
  return action => {
    return matchers.some(matcher => matches(matcher, action));
  };
}
function isAllOf(...matchers) {
  return action => {
    return matchers.every(matcher => matches(matcher, action));
  };
}
function hasExpectedRequestMetadata(action, validStatus) {
  if (!action || !action.meta) return false;
  const hasValidRequestId = typeof action.meta.requestId === "string";
  const hasValidRequestStatus = validStatus.indexOf(action.meta.requestStatus) > -1;
  return hasValidRequestId && hasValidRequestStatus;
}
function isAsyncThunkArray(a) {
  return typeof a[0] === "function" && "pending" in a[0] && "fulfilled" in a[0] && "rejected" in a[0];
}
function isPending(...asyncThunks) {
  if (asyncThunks.length === 0) {
    return action => hasExpectedRequestMetadata(action, ["pending"]);
  }
  if (!isAsyncThunkArray(asyncThunks)) {
    return isPending()(asyncThunks[0]);
  }
  return isAnyOf(...asyncThunks.map(asyncThunk => asyncThunk.pending));
}
function isRejected(...asyncThunks) {
  if (asyncThunks.length === 0) {
    return action => hasExpectedRequestMetadata(action, ["rejected"]);
  }
  if (!isAsyncThunkArray(asyncThunks)) {
    return isRejected()(asyncThunks[0]);
  }
  return isAnyOf(...asyncThunks.map(asyncThunk => asyncThunk.rejected));
}
function isRejectedWithValue(...asyncThunks) {
  const hasFlag = action => {
    return action && action.meta && action.meta.rejectedWithValue;
  };
  if (asyncThunks.length === 0) {
    return isAllOf(isRejected(...asyncThunks), hasFlag);
  }
  if (!isAsyncThunkArray(asyncThunks)) {
    return isRejectedWithValue()(asyncThunks[0]);
  }
  return isAllOf(isRejected(...asyncThunks), hasFlag);
}
function isFulfilled(...asyncThunks) {
  if (asyncThunks.length === 0) {
    return action => hasExpectedRequestMetadata(action, ["fulfilled"]);
  }
  if (!isAsyncThunkArray(asyncThunks)) {
    return isFulfilled()(asyncThunks[0]);
  }
  return isAnyOf(...asyncThunks.map(asyncThunk => asyncThunk.fulfilled));
}
function isAsyncThunkAction(...asyncThunks) {
  if (asyncThunks.length === 0) {
    return action => hasExpectedRequestMetadata(action, ["pending", "fulfilled", "rejected"]);
  }
  if (!isAsyncThunkArray(asyncThunks)) {
    return isAsyncThunkAction()(asyncThunks[0]);
  }
  return isAnyOf(...asyncThunks.flatMap(asyncThunk => [asyncThunk.pending, asyncThunk.rejected, asyncThunk.fulfilled]));
}

// src/nanoid.ts
var urlAlphabet = "ModuleSymbhasOwnPr-0123456789ABCDEFGHNRVfgctiUvz_KqYTJkLxpZXIjQW";
var nanoid = (size = 21) => {
  let id = "";
  let i = size;
  while (i--) {
    id += urlAlphabet[Math.random() * 64 | 0];
  }
  return id;
};

// src/createAsyncThunk.ts
var commonProperties = ["name", "message", "stack", "code"];
var RejectWithValue = class {
  constructor(payload, meta) {
    this.payload = payload;
    this.meta = meta;
  }
  /*
  type-only property to distinguish between RejectWithValue and FulfillWithMeta
  does not exist at runtime
  */
  _type;
};
var FulfillWithMeta = class {
  constructor(payload, meta) {
    this.payload = payload;
    this.meta = meta;
  }
  /*
  type-only property to distinguish between RejectWithValue and FulfillWithMeta
  does not exist at runtime
  */
  _type;
};
var miniSerializeError = value => {
  if (typeof value === "object" && value !== null) {
    const simpleError = {};
    for (const property of commonProperties) {
      if (typeof value[property] === "string") {
        simpleError[property] = value[property];
      }
    }
    return simpleError;
  }
  return {
    message: String(value)
  };
};
var createAsyncThunk = /* @__PURE__ */(() => {
  function createAsyncThunk2(typePrefix, payloadCreator, options) {
    const fulfilled = createAction(typePrefix + "/fulfilled", (payload, requestId, arg, meta) => ({
      payload,
      meta: {
        ...(meta || {}),
        arg,
        requestId,
        requestStatus: "fulfilled"
      }
    }));
    const pending = createAction(typePrefix + "/pending", (requestId, arg, meta) => ({
      payload: void 0,
      meta: {
        ...(meta || {}),
        arg,
        requestId,
        requestStatus: "pending"
      }
    }));
    const rejected = createAction(typePrefix + "/rejected", (error, requestId, arg, payload, meta) => ({
      payload,
      error: (options && options.serializeError || miniSerializeError)(error || "Rejected"),
      meta: {
        ...(meta || {}),
        arg,
        requestId,
        rejectedWithValue: !!payload,
        requestStatus: "rejected",
        aborted: error?.name === "AbortError",
        condition: error?.name === "ConditionError"
      }
    }));
    function actionCreator(arg) {
      return (dispatch, getState, extra) => {
        const requestId = options?.idGenerator ? options.idGenerator(arg) : nanoid();
        const abortController = new AbortController();
        let abortHandler;
        let abortReason;
        function abort(reason) {
          abortReason = reason;
          abortController.abort();
        }
        const promise = asyncToGenerator_asyncToGenerator(function* () {
          let finalAction;
          try {
            let conditionResult = options?.condition?.(arg, {
              getState,
              extra
            });
            if (isThenable(conditionResult)) {
              conditionResult = yield conditionResult;
            }
            if (conditionResult === false || abortController.signal.aborted) {
              throw {
                name: "ConditionError",
                message: "Aborted due to condition callback returning false."
              };
            }
            const abortedPromise = new Promise((_, reject) => {
              abortHandler = () => {
                reject({
                  name: "AbortError",
                  message: abortReason || "Aborted"
                });
              };
              abortController.signal.addEventListener("abort", abortHandler);
            });
            dispatch(pending(requestId, arg, options?.getPendingMeta?.({
              requestId,
              arg
            }, {
              getState,
              extra
            })));
            finalAction = yield Promise.race([abortedPromise, Promise.resolve(payloadCreator(arg, {
              dispatch,
              getState,
              extra,
              requestId,
              signal: abortController.signal,
              abort,
              rejectWithValue: (value, meta) => {
                return new RejectWithValue(value, meta);
              },
              fulfillWithValue: (value, meta) => {
                return new FulfillWithMeta(value, meta);
              }
            })).then(result => {
              if (result instanceof RejectWithValue) {
                throw result;
              }
              if (result instanceof FulfillWithMeta) {
                return fulfilled(result.payload, requestId, arg, result.meta);
              }
              return fulfilled(result, requestId, arg);
            })]);
          } catch (err) {
            finalAction = err instanceof RejectWithValue ? rejected(null, requestId, arg, err.payload, err.meta) : rejected(err, requestId, arg);
          } finally {
            if (abortHandler) {
              abortController.signal.removeEventListener("abort", abortHandler);
            }
          }
          const skipDispatch = options && !options.dispatchConditionRejection && rejected.match(finalAction) && finalAction.meta.condition;
          if (!skipDispatch) {
            dispatch(finalAction);
          }
          return finalAction;
        })();
        return Object.assign(promise, {
          abort,
          requestId,
          arg,
          unwrap() {
            return promise.then(unwrapResult);
          }
        });
      };
    }
    return Object.assign(actionCreator, {
      pending,
      rejected,
      fulfilled,
      settled: isAnyOf(rejected, fulfilled),
      typePrefix
    });
  }
  createAsyncThunk2.withTypes = () => createAsyncThunk2;
  return createAsyncThunk2;
})();
function unwrapResult(action) {
  if (action.meta && action.meta.rejectedWithValue) {
    throw action.payload;
  }
  if (action.error) {
    throw action.error;
  }
  return action.payload;
}
function isThenable(value) {
  return value !== null && typeof value === "object" && typeof value.then === "function";
}

// src/createSlice.ts
var asyncThunkSymbol = /* @__PURE__ */Symbol.for("rtk-slice-createasyncthunk");
var asyncThunkCreator = {
  [asyncThunkSymbol]: createAsyncThunk
};
var ReducerType = /* @__PURE__ */(ReducerType2 => {
  ReducerType2["reducer"] = "reducer";
  ReducerType2["reducerWithPrepare"] = "reducerWithPrepare";
  ReducerType2["asyncThunk"] = "asyncThunk";
  return ReducerType2;
})(ReducerType || {});
function getType(slice, actionKey) {
  return `${slice}/${actionKey}`;
}
function buildCreateSlice({
  creators
} = {}) {
  const cAT = creators?.asyncThunk?.[asyncThunkSymbol];
  return function createSlice2(options) {
    const {
      name,
      reducerPath = name
    } = options;
    if (!name) {
      throw new Error( true ? redux_toolkit_modern_formatProdErrorMessage(11) : 0);
    }
    if (typeof process !== "undefined" && "production" === "development") {}
    const reducers = (typeof options.reducers === "function" ? options.reducers(buildReducerCreators()) : options.reducers) || {};
    const reducerNames = Object.keys(reducers);
    const context = {
      sliceCaseReducersByName: {},
      sliceCaseReducersByType: {},
      actionCreators: {},
      sliceMatchers: []
    };
    const contextMethods = {
      addCase(typeOrActionCreator, reducer2) {
        const type = typeof typeOrActionCreator === "string" ? typeOrActionCreator : typeOrActionCreator.type;
        if (!type) {
          throw new Error( true ? redux_toolkit_modern_formatProdErrorMessage(12) : 0);
        }
        if (type in context.sliceCaseReducersByType) {
          throw new Error( true ? redux_toolkit_modern_formatProdErrorMessage(13) : 0);
        }
        context.sliceCaseReducersByType[type] = reducer2;
        return contextMethods;
      },
      addMatcher(matcher, reducer2) {
        context.sliceMatchers.push({
          matcher,
          reducer: reducer2
        });
        return contextMethods;
      },
      exposeAction(name2, actionCreator) {
        context.actionCreators[name2] = actionCreator;
        return contextMethods;
      },
      exposeCaseReducer(name2, reducer2) {
        context.sliceCaseReducersByName[name2] = reducer2;
        return contextMethods;
      }
    };
    reducerNames.forEach(reducerName => {
      const reducerDefinition = reducers[reducerName];
      const reducerDetails = {
        reducerName,
        type: getType(name, reducerName),
        createNotation: typeof options.reducers === "function"
      };
      if (isAsyncThunkSliceReducerDefinition(reducerDefinition)) {
        handleThunkCaseReducerDefinition(reducerDetails, reducerDefinition, contextMethods, cAT);
      } else {
        handleNormalReducerDefinition(reducerDetails, reducerDefinition, contextMethods);
      }
    });
    function buildReducer() {
      if (false) {}
      const [extraReducers = {}, actionMatchers = [], defaultCaseReducer = void 0] = typeof options.extraReducers === "function" ? executeReducerBuilderCallback(options.extraReducers) : [options.extraReducers];
      const finalCaseReducers = {
        ...extraReducers,
        ...context.sliceCaseReducersByType
      };
      return createReducer(options.initialState, builder => {
        for (let key in finalCaseReducers) {
          builder.addCase(key, finalCaseReducers[key]);
        }
        for (let sM of context.sliceMatchers) {
          builder.addMatcher(sM.matcher, sM.reducer);
        }
        for (let m of actionMatchers) {
          builder.addMatcher(m.matcher, m.reducer);
        }
        if (defaultCaseReducer) {
          builder.addDefaultCase(defaultCaseReducer);
        }
      });
    }
    const selectSelf = state => state;
    const injectedSelectorCache = /* @__PURE__ */new Map();
    let _reducer;
    function reducer(state, action) {
      if (!_reducer) _reducer = buildReducer();
      return _reducer(state, action);
    }
    function getInitialState() {
      if (!_reducer) _reducer = buildReducer();
      return _reducer.getInitialState();
    }
    function makeSelectorProps(reducerPath2, injected = false) {
      function selectSlice(state) {
        let sliceState = state[reducerPath2];
        if (typeof sliceState === "undefined") {
          if (injected) {
            sliceState = getInitialState();
          } else if (false) {}
        }
        return sliceState;
      }
      function getSelectors(selectState = selectSelf) {
        const selectorCache = getOrInsertComputed(injectedSelectorCache, injected, () => /* @__PURE__ */new WeakMap());
        return getOrInsertComputed(selectorCache, selectState, () => {
          const map = {};
          for (const [name2, selector] of Object.entries(options.selectors ?? {})) {
            map[name2] = wrapSelector(selector, selectState, getInitialState, injected);
          }
          return map;
        });
      }
      return {
        reducerPath: reducerPath2,
        getSelectors,
        get selectors() {
          return getSelectors(selectSlice);
        },
        selectSlice
      };
    }
    const slice = {
      name,
      reducer,
      actions: context.actionCreators,
      caseReducers: context.sliceCaseReducersByName,
      getInitialState,
      ...makeSelectorProps(reducerPath),
      injectInto(injectable, {
        reducerPath: pathOpt,
        ...config
      } = {}) {
        const newReducerPath = pathOpt ?? reducerPath;
        injectable.inject({
          reducerPath: newReducerPath,
          reducer
        }, config);
        return {
          ...slice,
          ...makeSelectorProps(newReducerPath, true)
        };
      }
    };
    return slice;
  };
}
function wrapSelector(selector, selectState, getInitialState, injected) {
  function wrapper(rootState, ...args) {
    let sliceState = selectState(rootState);
    if (typeof sliceState === "undefined") {
      if (injected) {
        sliceState = getInitialState();
      } else if (false) {}
    }
    return selector(sliceState, ...args);
  }
  wrapper.unwrapped = selector;
  return wrapper;
}
var createSlice = /* @__PURE__ */buildCreateSlice();
function buildReducerCreators() {
  function asyncThunk(payloadCreator, config) {
    return {
      _reducerDefinitionType: "asyncThunk" /* asyncThunk */,
      payloadCreator,
      ...config
    };
  }
  asyncThunk.withTypes = () => asyncThunk;
  return {
    reducer(caseReducer) {
      return Object.assign({
        // hack so the wrapping function has the same name as the original
        // we need to create a wrapper so the `reducerDefinitionType` is not assigned to the original
        [caseReducer.name](...args) {
          return caseReducer(...args);
        }
      }[caseReducer.name], {
        _reducerDefinitionType: "reducer" /* reducer */
      });
    },
    preparedReducer(prepare, reducer) {
      return {
        _reducerDefinitionType: "reducerWithPrepare" /* reducerWithPrepare */,
        prepare,
        reducer
      };
    },
    asyncThunk
  };
}
function handleNormalReducerDefinition({
  type,
  reducerName,
  createNotation
}, maybeReducerWithPrepare, context) {
  let caseReducer;
  let prepareCallback;
  if ("reducer" in maybeReducerWithPrepare) {
    if (createNotation && !isCaseReducerWithPrepareDefinition(maybeReducerWithPrepare)) {
      throw new Error( true ? redux_toolkit_modern_formatProdErrorMessage(17) : 0);
    }
    caseReducer = maybeReducerWithPrepare.reducer;
    prepareCallback = maybeReducerWithPrepare.prepare;
  } else {
    caseReducer = maybeReducerWithPrepare;
  }
  context.addCase(type, caseReducer).exposeCaseReducer(reducerName, caseReducer).exposeAction(reducerName, prepareCallback ? createAction(type, prepareCallback) : createAction(type));
}
function isAsyncThunkSliceReducerDefinition(reducerDefinition) {
  return reducerDefinition._reducerDefinitionType === "asyncThunk" /* asyncThunk */;
}
function isCaseReducerWithPrepareDefinition(reducerDefinition) {
  return reducerDefinition._reducerDefinitionType === "reducerWithPrepare" /* reducerWithPrepare */;
}
function handleThunkCaseReducerDefinition({
  type,
  reducerName
}, reducerDefinition, context, cAT) {
  if (!cAT) {
    throw new Error( true ? redux_toolkit_modern_formatProdErrorMessage(18) : 0);
  }
  const {
    payloadCreator,
    fulfilled,
    pending,
    rejected,
    settled,
    options
  } = reducerDefinition;
  const thunk = cAT(type, payloadCreator, options);
  context.exposeAction(reducerName, thunk);
  if (fulfilled) {
    context.addCase(thunk.fulfilled, fulfilled);
  }
  if (pending) {
    context.addCase(thunk.pending, pending);
  }
  if (rejected) {
    context.addCase(thunk.rejected, rejected);
  }
  if (settled) {
    context.addMatcher(thunk.settled, settled);
  }
  context.exposeCaseReducer(reducerName, {
    fulfilled: fulfilled || redux_toolkit_modern_noop,
    pending: pending || redux_toolkit_modern_noop,
    rejected: rejected || redux_toolkit_modern_noop,
    settled: settled || redux_toolkit_modern_noop
  });
}
function redux_toolkit_modern_noop() {}

// src/entities/entity_state.ts
function getInitialEntityState() {
  return {
    ids: [],
    entities: {}
  };
}
function createInitialStateFactory(stateAdapter) {
  function getInitialState(additionalState = {}, entities) {
    const state = Object.assign(getInitialEntityState(), additionalState);
    return entities ? stateAdapter.setAll(state, entities) : state;
  }
  return {
    getInitialState
  };
}

// src/entities/state_selectors.ts
function createSelectorsFactory() {
  function getSelectors(selectState, options = {}) {
    const {
      createSelector: createSelector2 = createDraftSafeSelector
    } = options;
    const selectIds = state => state.ids;
    const selectEntities = state => state.entities;
    const selectAll = createSelector2(selectIds, selectEntities, (ids, entities) => ids.map(id => entities[id]));
    const selectId = (_, id) => id;
    const selectById = (entities, id) => entities[id];
    const selectTotal = createSelector2(selectIds, ids => ids.length);
    if (!selectState) {
      return {
        selectIds,
        selectEntities,
        selectAll,
        selectTotal,
        selectById: createSelector2(selectEntities, selectId, selectById)
      };
    }
    const selectGlobalizedEntities = createSelector2(selectState, selectEntities);
    return {
      selectIds: createSelector2(selectState, selectIds),
      selectEntities: selectGlobalizedEntities,
      selectAll: createSelector2(selectState, selectAll),
      selectTotal: createSelector2(selectState, selectTotal),
      selectById: createSelector2(selectGlobalizedEntities, selectId, selectById)
    };
  }
  return {
    getSelectors
  };
}

// src/entities/state_adapter.ts

var isDraftTyped = isDraft;
function createSingleArgumentStateOperator(mutator) {
  const operator = createStateOperator((_, state) => mutator(state));
  return function operation(state) {
    return operator(state, void 0);
  };
}
function createStateOperator(mutator) {
  return function operation(state, arg) {
    function isPayloadActionArgument(arg2) {
      return isFSA(arg2);
    }
    const runMutator = draft => {
      if (isPayloadActionArgument(arg)) {
        mutator(arg.payload, draft);
      } else {
        mutator(arg, draft);
      }
    };
    if (isDraftTyped(state)) {
      runMutator(state);
      return state;
    }
    return createNextState3(state, runMutator);
  };
}

// src/entities/utils.ts

function selectIdValue(entity, selectId) {
  const key = selectId(entity);
  if (false) {}
  return key;
}
function ensureEntitiesArray(entities) {
  if (!Array.isArray(entities)) {
    entities = Object.values(entities);
  }
  return entities;
}
function getCurrent(value) {
  return isDraft4(value) ? current2(value) : value;
}
function splitAddedUpdatedEntities(newEntities, selectId, state) {
  newEntities = ensureEntitiesArray(newEntities);
  const existingIdsArray = getCurrent(state.ids);
  const existingIds = new Set(existingIdsArray);
  const added = [];
  const updated = [];
  for (const entity of newEntities) {
    const id = selectIdValue(entity, selectId);
    if (existingIds.has(id)) {
      updated.push({
        id,
        changes: entity
      });
    } else {
      added.push(entity);
    }
  }
  return [added, updated, existingIdsArray];
}

// src/entities/unsorted_state_adapter.ts
function createUnsortedStateAdapter(selectId) {
  function addOneMutably(entity, state) {
    const key = selectIdValue(entity, selectId);
    if (key in state.entities) {
      return;
    }
    state.ids.push(key);
    state.entities[key] = entity;
  }
  function addManyMutably(newEntities, state) {
    newEntities = ensureEntitiesArray(newEntities);
    for (const entity of newEntities) {
      addOneMutably(entity, state);
    }
  }
  function setOneMutably(entity, state) {
    const key = selectIdValue(entity, selectId);
    if (!(key in state.entities)) {
      state.ids.push(key);
    }
    ;
    state.entities[key] = entity;
  }
  function setManyMutably(newEntities, state) {
    newEntities = ensureEntitiesArray(newEntities);
    for (const entity of newEntities) {
      setOneMutably(entity, state);
    }
  }
  function setAllMutably(newEntities, state) {
    newEntities = ensureEntitiesArray(newEntities);
    state.ids = [];
    state.entities = {};
    addManyMutably(newEntities, state);
  }
  function removeOneMutably(key, state) {
    return removeManyMutably([key], state);
  }
  function removeManyMutably(keys, state) {
    let didMutate = false;
    keys.forEach(key => {
      if (key in state.entities) {
        delete state.entities[key];
        didMutate = true;
      }
    });
    if (didMutate) {
      state.ids = state.ids.filter(id => id in state.entities);
    }
  }
  function removeAllMutably(state) {
    Object.assign(state, {
      ids: [],
      entities: {}
    });
  }
  function takeNewKey(keys, update, state) {
    const original3 = state.entities[update.id];
    if (original3 === void 0) {
      return false;
    }
    const updated = Object.assign({}, original3, update.changes);
    const newKey = selectIdValue(updated, selectId);
    const hasNewKey = newKey !== update.id;
    if (hasNewKey) {
      keys[update.id] = newKey;
      delete state.entities[update.id];
    }
    ;
    state.entities[newKey] = updated;
    return hasNewKey;
  }
  function updateOneMutably(update, state) {
    return updateManyMutably([update], state);
  }
  function updateManyMutably(updates, state) {
    const newKeys = {};
    const updatesPerEntity = {};
    updates.forEach(update => {
      if (update.id in state.entities) {
        updatesPerEntity[update.id] = {
          id: update.id,
          // Spreads ignore falsy values, so this works even if there isn't
          // an existing update already at this key
          changes: {
            ...updatesPerEntity[update.id]?.changes,
            ...update.changes
          }
        };
      }
    });
    updates = Object.values(updatesPerEntity);
    const didMutateEntities = updates.length > 0;
    if (didMutateEntities) {
      const didMutateIds = updates.filter(update => takeNewKey(newKeys, update, state)).length > 0;
      if (didMutateIds) {
        state.ids = Object.values(state.entities).map(e => selectIdValue(e, selectId));
      }
    }
  }
  function upsertOneMutably(entity, state) {
    return upsertManyMutably([entity], state);
  }
  function upsertManyMutably(newEntities, state) {
    const [added, updated] = splitAddedUpdatedEntities(newEntities, selectId, state);
    updateManyMutably(updated, state);
    addManyMutably(added, state);
  }
  return {
    removeAll: createSingleArgumentStateOperator(removeAllMutably),
    addOne: createStateOperator(addOneMutably),
    addMany: createStateOperator(addManyMutably),
    setOne: createStateOperator(setOneMutably),
    setMany: createStateOperator(setManyMutably),
    setAll: createStateOperator(setAllMutably),
    updateOne: createStateOperator(updateOneMutably),
    updateMany: createStateOperator(updateManyMutably),
    upsertOne: createStateOperator(upsertOneMutably),
    upsertMany: createStateOperator(upsertManyMutably),
    removeOne: createStateOperator(removeOneMutably),
    removeMany: createStateOperator(removeManyMutably)
  };
}

// src/entities/sorted_state_adapter.ts
function findInsertIndex(sortedItems, item, comparisonFunction) {
  let lowIndex = 0;
  let highIndex = sortedItems.length;
  while (lowIndex < highIndex) {
    let middleIndex = lowIndex + highIndex >>> 1;
    const currentItem = sortedItems[middleIndex];
    const res = comparisonFunction(item, currentItem);
    if (res >= 0) {
      lowIndex = middleIndex + 1;
    } else {
      highIndex = middleIndex;
    }
  }
  return lowIndex;
}
function insert(sortedItems, item, comparisonFunction) {
  const insertAtIndex = findInsertIndex(sortedItems, item, comparisonFunction);
  sortedItems.splice(insertAtIndex, 0, item);
  return sortedItems;
}
function createSortedStateAdapter(selectId, comparer) {
  const {
    removeOne,
    removeMany,
    removeAll
  } = createUnsortedStateAdapter(selectId);
  function addOneMutably(entity, state) {
    return addManyMutably([entity], state);
  }
  function addManyMutably(newEntities, state, existingIds) {
    newEntities = ensureEntitiesArray(newEntities);
    const existingKeys = new Set(existingIds ?? getCurrent(state.ids));
    const models = newEntities.filter(model => !existingKeys.has(selectIdValue(model, selectId)));
    if (models.length !== 0) {
      mergeFunction(state, models);
    }
  }
  function setOneMutably(entity, state) {
    return setManyMutably([entity], state);
  }
  function setManyMutably(newEntities, state) {
    newEntities = ensureEntitiesArray(newEntities);
    if (newEntities.length !== 0) {
      for (const item of newEntities) {
        delete state.entities[selectId(item)];
      }
      mergeFunction(state, newEntities);
    }
  }
  function setAllMutably(newEntities, state) {
    newEntities = ensureEntitiesArray(newEntities);
    state.entities = {};
    state.ids = [];
    addManyMutably(newEntities, state, []);
  }
  function updateOneMutably(update, state) {
    return updateManyMutably([update], state);
  }
  function updateManyMutably(updates, state) {
    let appliedUpdates = false;
    let replacedIds = false;
    for (let update of updates) {
      const entity = state.entities[update.id];
      if (!entity) {
        continue;
      }
      appliedUpdates = true;
      Object.assign(entity, update.changes);
      const newId = selectId(entity);
      if (update.id !== newId) {
        replacedIds = true;
        delete state.entities[update.id];
        const oldIndex = state.ids.indexOf(update.id);
        state.ids[oldIndex] = newId;
        state.entities[newId] = entity;
      }
    }
    if (appliedUpdates) {
      mergeFunction(state, [], appliedUpdates, replacedIds);
    }
  }
  function upsertOneMutably(entity, state) {
    return upsertManyMutably([entity], state);
  }
  function upsertManyMutably(newEntities, state) {
    const [added, updated, existingIdsArray] = splitAddedUpdatedEntities(newEntities, selectId, state);
    if (updated.length) {
      updateManyMutably(updated, state);
    }
    if (added.length) {
      addManyMutably(added, state, existingIdsArray);
    }
  }
  function areArraysEqual(a, b) {
    if (a.length !== b.length) {
      return false;
    }
    for (let i = 0; i < a.length; i++) {
      if (a[i] === b[i]) {
        continue;
      }
      return false;
    }
    return true;
  }
  const mergeFunction = (state, addedItems, appliedUpdates, replacedIds) => {
    const currentEntities = getCurrent(state.entities);
    const currentIds = getCurrent(state.ids);
    const stateEntities = state.entities;
    let ids = currentIds;
    if (replacedIds) {
      ids = new Set(currentIds);
    }
    let sortedEntities = [];
    for (const id of ids) {
      const entity = currentEntities[id];
      if (entity) {
        sortedEntities.push(entity);
      }
    }
    const wasPreviouslyEmpty = sortedEntities.length === 0;
    for (const item of addedItems) {
      stateEntities[selectId(item)] = item;
      if (!wasPreviouslyEmpty) {
        insert(sortedEntities, item, comparer);
      }
    }
    if (wasPreviouslyEmpty) {
      sortedEntities = addedItems.slice().sort(comparer);
    } else if (appliedUpdates) {
      sortedEntities.sort(comparer);
    }
    const newSortedIds = sortedEntities.map(selectId);
    if (!areArraysEqual(currentIds, newSortedIds)) {
      state.ids = newSortedIds;
    }
  };
  return {
    removeOne,
    removeMany,
    removeAll,
    addOne: createStateOperator(addOneMutably),
    updateOne: createStateOperator(updateOneMutably),
    upsertOne: createStateOperator(upsertOneMutably),
    setOne: createStateOperator(setOneMutably),
    setMany: createStateOperator(setManyMutably),
    setAll: createStateOperator(setAllMutably),
    addMany: createStateOperator(addManyMutably),
    updateMany: createStateOperator(updateManyMutably),
    upsertMany: createStateOperator(upsertManyMutably)
  };
}

// src/entities/create_adapter.ts
function createEntityAdapter(options = {}) {
  const {
    selectId,
    sortComparer
  } = {
    sortComparer: false,
    selectId: instance => instance.id,
    ...options
  };
  const stateAdapter = sortComparer ? createSortedStateAdapter(selectId, sortComparer) : createUnsortedStateAdapter(selectId);
  const stateFactory = createInitialStateFactory(stateAdapter);
  const selectorsFactory = createSelectorsFactory();
  return {
    selectId,
    sortComparer,
    ...stateFactory,
    ...selectorsFactory,
    ...stateAdapter
  };
}

// src/listenerMiddleware/index.ts


// src/listenerMiddleware/exceptions.ts
var task = "task";
var listener = "listener";
var completed = "completed";
var cancelled = "cancelled";
var taskCancelled = `task-${cancelled}`;
var taskCompleted = `task-${completed}`;
var listenerCancelled = `${listener}-${cancelled}`;
var listenerCompleted = `${listener}-${completed}`;
var TaskAbortError = class {
  constructor(code) {
    this.code = code;
    this.message = `${task} ${cancelled} (reason: ${code})`;
  }
  name = "TaskAbortError";
  message;
};

// src/listenerMiddleware/utils.ts
var assertFunction = (func, expected) => {
  if (typeof func !== "function") {
    throw new TypeError( true ? redux_toolkit_modern_formatProdErrorMessage(32) : 0);
  }
};
var noop2 = () => {};
var catchRejection = (promise, onError = noop2) => {
  promise.catch(onError);
  return promise;
};
var addAbortSignalListener = (abortSignal, callback) => {
  abortSignal.addEventListener("abort", callback, {
    once: true
  });
  return () => abortSignal.removeEventListener("abort", callback);
};
var abortControllerWithReason = (abortController, reason) => {
  const signal = abortController.signal;
  if (signal.aborted) {
    return;
  }
  if (!("reason" in signal)) {
    Object.defineProperty(signal, "reason", {
      enumerable: true,
      value: reason,
      configurable: true,
      writable: true
    });
  }
  ;
  abortController.abort(reason);
};

// src/listenerMiddleware/task.ts
var validateActive = signal => {
  if (signal.aborted) {
    const {
      reason
    } = signal;
    throw new TaskAbortError(reason);
  }
};
function raceWithSignal(signal, promise) {
  let cleanup = noop2;
  return new Promise((resolve, reject) => {
    const notifyRejection = () => reject(new TaskAbortError(signal.reason));
    if (signal.aborted) {
      notifyRejection();
      return;
    }
    cleanup = addAbortSignalListener(signal, notifyRejection);
    promise.finally(() => cleanup()).then(resolve, reject);
  }).finally(() => {
    cleanup = noop2;
  });
}
var runTask = /*#__PURE__*/(/* unused pure expression or super */ null && (function () {
  var _ref2 = _asyncToGenerator(function* (task2, cleanUp) {
    try {
      yield Promise.resolve();
      const value = yield task2();
      return {
        status: "ok",
        value
      };
    } catch (error) {
      return {
        status: error instanceof TaskAbortError ? "cancelled" : "rejected",
        error
      };
    } finally {
      cleanUp?.();
    }
  });
  return function runTask(_x, _x2) {
    return _ref2.apply(this, arguments);
  };
}()));
var createPause = signal => {
  return promise => {
    return catchRejection(raceWithSignal(signal, promise).then(output => {
      validateActive(signal);
      return output;
    }));
  };
};
var createDelay = signal => {
  const pause = createPause(signal);
  return timeoutMs => {
    return pause(new Promise(resolve => setTimeout(resolve, timeoutMs)));
  };
};

// src/listenerMiddleware/index.ts
var {
  assign: redux_toolkit_modern_assign
} = Object;
var INTERNAL_NIL_TOKEN = {};
var alm = "listenerMiddleware";
var createFork = (parentAbortSignal, parentBlockingPromises) => {
  const linkControllers = controller => addAbortSignalListener(parentAbortSignal, () => abortControllerWithReason(controller, parentAbortSignal.reason));
  return (taskExecutor, opts) => {
    assertFunction(taskExecutor, "taskExecutor");
    const childAbortController = new AbortController();
    linkControllers(childAbortController);
    const result = runTask( /*#__PURE__*/_asyncToGenerator(function* () {
      validateActive(parentAbortSignal);
      validateActive(childAbortController.signal);
      const result2 = yield taskExecutor({
        pause: createPause(childAbortController.signal),
        delay: createDelay(childAbortController.signal),
        signal: childAbortController.signal
      });
      validateActive(childAbortController.signal);
      return result2;
    }), () => abortControllerWithReason(childAbortController, taskCompleted));
    if (opts?.autoJoin) {
      parentBlockingPromises.push(result.catch(noop2));
    }
    return {
      result: createPause(parentAbortSignal)(result),
      cancel() {
        abortControllerWithReason(childAbortController, taskCancelled);
      }
    };
  };
};
var createTakePattern = (startListening, signal) => {
  const take = /*#__PURE__*/function () {
    var _ref4 = _asyncToGenerator(function* (predicate, timeout) {
      validateActive(signal);
      let unsubscribe = () => {};
      const tuplePromise = new Promise((resolve, reject) => {
        let stopListening = startListening({
          predicate,
          effect: (action, listenerApi) => {
            listenerApi.unsubscribe();
            resolve([action, listenerApi.getState(), listenerApi.getOriginalState()]);
          }
        });
        unsubscribe = () => {
          stopListening();
          reject();
        };
      });
      const promises = [tuplePromise];
      if (timeout != null) {
        promises.push(new Promise(resolve => setTimeout(resolve, timeout, null)));
      }
      try {
        const output = yield raceWithSignal(signal, Promise.race(promises));
        validateActive(signal);
        return output;
      } finally {
        unsubscribe();
      }
    });
    return function take(_x3, _x4) {
      return _ref4.apply(this, arguments);
    };
  }();
  return (predicate, timeout) => catchRejection(take(predicate, timeout));
};
var getListenerEntryPropsFrom = options => {
  let {
    type,
    actionCreator,
    matcher,
    predicate,
    effect
  } = options;
  if (type) {
    predicate = createAction(type).match;
  } else if (actionCreator) {
    type = actionCreator.type;
    predicate = actionCreator.match;
  } else if (matcher) {
    predicate = matcher;
  } else if (predicate) {} else {
    throw new Error( true ? redux_toolkit_modern_formatProdErrorMessage(21) : 0);
  }
  assertFunction(effect, "options.listener");
  return {
    predicate,
    type,
    effect
  };
};
var createListenerEntry = /* @__PURE__ */redux_toolkit_modern_assign(options => {
  const {
    type,
    predicate,
    effect
  } = getListenerEntryPropsFrom(options);
  const entry = {
    id: nanoid(),
    effect,
    type,
    predicate,
    pending: /* @__PURE__ */new Set(),
    unsubscribe: () => {
      throw new Error( true ? redux_toolkit_modern_formatProdErrorMessage(22) : 0);
    }
  };
  return entry;
}, {
  withTypes: () => createListenerEntry
});
var findListenerEntry = (listenerMap, options) => {
  const {
    type,
    effect,
    predicate
  } = getListenerEntryPropsFrom(options);
  return Array.from(listenerMap.values()).find(entry => {
    const matchPredicateOrType = typeof type === "string" ? entry.type === type : entry.predicate === predicate;
    return matchPredicateOrType && entry.effect === effect;
  });
};
var cancelActiveListeners = entry => {
  entry.pending.forEach(controller => {
    abortControllerWithReason(controller, listenerCancelled);
  });
};
var createClearListenerMiddleware = listenerMap => {
  return () => {
    listenerMap.forEach(cancelActiveListeners);
    listenerMap.clear();
  };
};
var safelyNotifyError = (errorHandler, errorToNotify, errorInfo) => {
  try {
    errorHandler(errorToNotify, errorInfo);
  } catch (errorHandlerError) {
    setTimeout(() => {
      throw errorHandlerError;
    }, 0);
  }
};
var addListener = /* @__PURE__ */redux_toolkit_modern_assign( /* @__PURE__ */createAction(`${alm}/add`), {
  withTypes: () => addListener
});
var clearAllListeners = /* @__PURE__ */createAction(`${alm}/removeAll`);
var removeListener = /* @__PURE__ */redux_toolkit_modern_assign( /* @__PURE__ */createAction(`${alm}/remove`), {
  withTypes: () => removeListener
});
var redux_toolkit_modern_defaultErrorHandler = (...args) => {
  console.error(`${alm}/error`, ...args);
};
var createListenerMiddleware = (middlewareOptions = {}) => {
  const listenerMap = /* @__PURE__ */new Map();
  const {
    extra,
    onError = redux_toolkit_modern_defaultErrorHandler
  } = middlewareOptions;
  assertFunction(onError, "onError");
  const insertEntry = entry => {
    entry.unsubscribe = () => listenerMap.delete(entry.id);
    listenerMap.set(entry.id, entry);
    return cancelOptions => {
      entry.unsubscribe();
      if (cancelOptions?.cancelActive) {
        cancelActiveListeners(entry);
      }
    };
  };
  const startListening = options => {
    const entry = findListenerEntry(listenerMap, options) ?? createListenerEntry(options);
    return insertEntry(entry);
  };
  redux_toolkit_modern_assign(startListening, {
    withTypes: () => startListening
  });
  const stopListening = options => {
    const entry = findListenerEntry(listenerMap, options);
    if (entry) {
      entry.unsubscribe();
      if (options.cancelActive) {
        cancelActiveListeners(entry);
      }
    }
    return !!entry;
  };
  redux_toolkit_modern_assign(stopListening, {
    withTypes: () => stopListening
  });
  const notifyListener = /*#__PURE__*/function () {
    var _ref5 = _asyncToGenerator(function* (entry, action, api, getOriginalState) {
      const internalTaskController = new AbortController();
      const take = createTakePattern(startListening, internalTaskController.signal);
      const autoJoinPromises = [];
      try {
        entry.pending.add(internalTaskController);
        yield Promise.resolve(entry.effect(action,
        // Use assign() rather than ... to avoid extra helper functions added to bundle
        redux_toolkit_modern_assign({}, api, {
          getOriginalState,
          condition: (predicate, timeout) => take(predicate, timeout).then(Boolean),
          take,
          delay: createDelay(internalTaskController.signal),
          pause: createPause(internalTaskController.signal),
          extra,
          signal: internalTaskController.signal,
          fork: createFork(internalTaskController.signal, autoJoinPromises),
          unsubscribe: entry.unsubscribe,
          subscribe: () => {
            listenerMap.set(entry.id, entry);
          },
          cancelActiveListeners: () => {
            entry.pending.forEach((controller, _, set) => {
              if (controller !== internalTaskController) {
                abortControllerWithReason(controller, listenerCancelled);
                set.delete(controller);
              }
            });
          },
          cancel: () => {
            abortControllerWithReason(internalTaskController, listenerCancelled);
            entry.pending.delete(internalTaskController);
          },
          throwIfCancelled: () => {
            validateActive(internalTaskController.signal);
          }
        })));
      } catch (listenerError) {
        if (!(listenerError instanceof TaskAbortError)) {
          safelyNotifyError(onError, listenerError, {
            raisedBy: "effect"
          });
        }
      } finally {
        yield Promise.all(autoJoinPromises);
        abortControllerWithReason(internalTaskController, listenerCompleted);
        entry.pending.delete(internalTaskController);
      }
    });
    return function notifyListener(_x5, _x6, _x7, _x8) {
      return _ref5.apply(this, arguments);
    };
  }();
  const clearListenerMiddleware = createClearListenerMiddleware(listenerMap);
  const middleware = api => next => action => {
    if (!isAction3(action)) {
      return next(action);
    }
    if (addListener.match(action)) {
      return startListening(action.payload);
    }
    if (clearAllListeners.match(action)) {
      clearListenerMiddleware();
      return;
    }
    if (removeListener.match(action)) {
      return stopListening(action.payload);
    }
    let originalState = api.getState();
    const getOriginalState = () => {
      if (originalState === INTERNAL_NIL_TOKEN) {
        throw new Error( true ? redux_toolkit_modern_formatProdErrorMessage(23) : 0);
      }
      return originalState;
    };
    let result;
    try {
      result = next(action);
      if (listenerMap.size > 0) {
        const currentState = api.getState();
        const listenerEntries = Array.from(listenerMap.values());
        for (const entry of listenerEntries) {
          let runListener = false;
          try {
            runListener = entry.predicate(action, currentState, originalState);
          } catch (predicateError) {
            runListener = false;
            safelyNotifyError(onError, predicateError, {
              raisedBy: "predicate"
            });
          }
          if (!runListener) {
            continue;
          }
          notifyListener(entry, action, api, getOriginalState);
        }
      }
    } finally {
      originalState = INTERNAL_NIL_TOKEN;
    }
    return result;
  };
  return {
    middleware,
    startListening,
    stopListening,
    clearListeners: clearListenerMiddleware
  };
};

// src/dynamicMiddleware/index.ts

var createMiddlewareEntry = middleware => ({
  middleware,
  applied: /* @__PURE__ */new Map()
});
var matchInstance = instanceId => action => action?.meta?.instanceId === instanceId;
var createDynamicMiddleware = () => {
  const instanceId = nanoid();
  const middlewareMap = /* @__PURE__ */new Map();
  const withMiddleware = Object.assign(createAction("dynamicMiddleware/add", (...middlewares) => ({
    payload: middlewares,
    meta: {
      instanceId
    }
  })), {
    withTypes: () => withMiddleware
  });
  const addMiddleware = Object.assign(function addMiddleware2(...middlewares) {
    middlewares.forEach(middleware2 => {
      getOrInsertComputed(middlewareMap, middleware2, createMiddlewareEntry);
    });
  }, {
    withTypes: () => addMiddleware
  });
  const getFinalMiddleware = api => {
    const appliedMiddleware = Array.from(middlewareMap.values()).map(entry => getOrInsertComputed(entry.applied, api, entry.middleware));
    return compose3(...appliedMiddleware);
  };
  const isWithMiddleware = isAllOf(withMiddleware, matchInstance(instanceId));
  const middleware = api => next => action => {
    if (isWithMiddleware(action)) {
      addMiddleware(...action.payload);
      return api.dispatch;
    }
    return getFinalMiddleware(api)(next)(action);
  };
  return {
    middleware,
    addMiddleware,
    withMiddleware,
    instanceId
  };
};

// src/combineSlices.ts

var isSliceLike = maybeSliceLike => "reducerPath" in maybeSliceLike && typeof maybeSliceLike.reducerPath === "string";
var getReducers = slices => slices.flatMap(sliceOrMap => isSliceLike(sliceOrMap) ? [[sliceOrMap.reducerPath, sliceOrMap.reducer]] : Object.entries(sliceOrMap));
var ORIGINAL_STATE = Symbol.for("rtk-state-proxy-original");
var isStateProxy = value => !!value && !!value[ORIGINAL_STATE];
var stateProxyMap = /* @__PURE__ */new WeakMap();
var createStateProxy = (state, reducerMap) => getOrInsertComputed(stateProxyMap, state, () => new Proxy(state, {
  get: (target, prop, receiver) => {
    if (prop === ORIGINAL_STATE) return target;
    const result = Reflect.get(target, prop, receiver);
    if (typeof result === "undefined") {
      const reducer = reducerMap[prop.toString()];
      if (reducer) {
        const reducerResult = reducer(void 0, {
          type: nanoid()
        });
        if (typeof reducerResult === "undefined") {
          throw new Error( true ? redux_toolkit_modern_formatProdErrorMessage(24) : 0);
        }
        return reducerResult;
      }
    }
    return result;
  }
}));
var redux_toolkit_modern_original = state => {
  if (!isStateProxy(state)) {
    throw new Error( true ? redux_toolkit_modern_formatProdErrorMessage(25) : 0);
  }
  return state[ORIGINAL_STATE];
};
var noopReducer = (state = {}) => state;
function combineSlices(...slices) {
  const reducerMap = Object.fromEntries(getReducers(slices));
  const getReducer = () => Object.keys(reducerMap).length ? combineReducers2(reducerMap) : noopReducer;
  let reducer = getReducer();
  function combinedReducer(state, action) {
    return reducer(state, action);
  }
  combinedReducer.withLazyLoadedSlices = () => combinedReducer;
  const inject = (slice, config = {}) => {
    const {
      reducerPath,
      reducer: reducerToInject
    } = slice;
    const currentReducer = reducerMap[reducerPath];
    if (!config.overrideExisting && currentReducer && currentReducer !== reducerToInject) {
      if (typeof process !== "undefined" && "production" === "development") {}
      return combinedReducer;
    }
    reducerMap[reducerPath] = reducerToInject;
    reducer = getReducer();
    return combinedReducer;
  };
  const selector = Object.assign(function makeSelector(selectorFn, selectState) {
    return function selector2(state, ...args) {
      return selectorFn(createStateProxy(selectState ? selectState(state, ...args) : state, reducerMap), ...args);
    };
  }, {
    original: redux_toolkit_modern_original
  });
  return Object.assign(combinedReducer, {
    inject,
    selector
  });
}

// src/formatProdErrorMessage.ts
function redux_toolkit_modern_formatProdErrorMessage(code) {
  return `Minified Redux Toolkit error #${code}; visit https://redux-toolkit.js.org/Errors?code=${code} for the full message or use the non-minified dev environment for full errors. `;
}

//# sourceMappingURL=redux-toolkit.modern.mjs.map
;// CONCATENATED MODULE: ./apps/gopher-for-chrome/gopher-buddy/src/background-service-worker/services/extension-store/interfaces/extension-store.interfaces.ts
var StateStatus = /*#__PURE__*/(() => {
  (function (StateStatus) {
    StateStatus["IDLE"] = "idle";
    StateStatus["LOADING"] = "loading";
    StateStatus["SUCCESS"] = "success";
    StateStatus["FAILED"] = "failed";
  })(StateStatus || (StateStatus = {}));
  return StateStatus;
})();
var DeviceManagedState = /*#__PURE__*/(() => {
  (function (DeviceManagedState) {
    DeviceManagedState["MANAGED"] = "managed";
    DeviceManagedState["NOT_MANAGED"] = "notManaged";
  })(DeviceManagedState || (DeviceManagedState = {}));
  return DeviceManagedState;
})();
;// CONCATENATED MODULE: ./apps/gopher-for-chrome/gopher-buddy/src/background-service-worker/services/alerts/alarm.state.ts


const initialState = {
  status: StateStatus.IDLE,
  error: null,
  alarmState: {
    lastUpdated: Date.now()
  }
};
const AlarmStatus = createSlice({
  name: 'AppAlarmReducer',
  initialState,
  reducers: {
    setLastUpated: (mutableState, action) => {
      mutableState.alarmState.lastUpdated = action.payload;
    }
  }
});
const {
  setLastUpated
} = AlarmStatus.actions;
const lastUpdated = state => state.alarmState.lastUpdated;
;// CONCATENATED MODULE: ./apps/gopher-for-chrome/gopher-buddy/src/background-service-worker/services/extension-store/global-flags.store.ts


const GlobalAppFlagsState = createSlice({
  name: 'GlobalAppFlagsState',
  initialState: {
    isLoaded: false,
    deviceManagedState: DeviceManagedState.MANAGED
  },
  reducers: {
    setLoaded: mutableState => {
      mutableState.isLoaded = true;
    },
    setdeviceManagedState: (mutableState, action) => {
      mutableState.deviceManagedState = action.payload;
    }
  }
});
const {
  setLoaded,
  setdeviceManagedState
} = GlobalAppFlagsState.actions;
;// CONCATENATED MODULE: ./apps/gopher-for-chrome/gopher-buddy/src/background-service-worker/services/gb-api/interfaces/gopher-buddy-api.interfaces.ts
var HttpMethod = /*#__PURE__*/(() => {
  (function (HttpMethod) {
    HttpMethod["GET"] = "GET";
    HttpMethod["POST"] = "POST";
    HttpMethod["PUT"] = "PUT";
    HttpMethod["DELETE"] = "DELETE";
  })(HttpMethod || (HttpMethod = {}));
  return HttpMethod;
})();
var Projection = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => {
  (function (Projection) {
    Projection["BASIC"] = "basic";
    Projection["FULL"] = "full";
  })(Projection || (Projection = {}));
  return Projection;
})()));
;// CONCATENATED MODULE: ./apps/gopher-for-chrome/gopher-buddy/src/environments/environment.ts
/** ************************************************************************
PRODUCTION ENVIRONMENT
************************************************************************** */

var RuntimeEnvironment = /*#__PURE__*/(() => {
  (function (RuntimeEnvironment) {
    RuntimeEnvironment["LOCAL"] = "local";
    RuntimeEnvironment["PRODUCTION"] = "production";
    RuntimeEnvironment["DEVELOPMENT"] = "development";
  })(RuntimeEnvironment || (RuntimeEnvironment = {}));
  return RuntimeEnvironment;
})();
const environment = {
  showDebug: false,
  environment: RuntimeEnvironment.PRODUCTION,
  apiServer: 'https://gopher-buddy-prod.appspot.com',
  apiToken: 'dsalj009mnv-8sdjhsa8jhd',
  production: true,
  extensionApiStrategy: ExtensionApiStrategy.CHROME,
  defaultTimings: {
    idleDetectionIntervalInSeconds: 300,
    networkStatusCheckIntervalInSeconds: 120,
    checkInIntervalInSeconds: 1800,
    userSessionCheckinRateInSeconds: 60,
    userSessionCreateRateInSeconds: 30 // How often the extension creates a new user session. I figure 2x a idle detection interval is good
  },
  pubsubConfig: {
    topic: 'session-ingest',
    project: 'gopher-buddy-prod',
    apiKey: 'AIzaSyCTgIFn8GImeF-fshihisrLuLqP7eyFtZ8',
    attributes: ['userId', 'deviceId', 'timestamp']
  },
  publicUrls: {
    faqHelp: 'https://amplifiedlabs.zendesk.com/hc/en-us/articles/360051865934-Frequently-Asked-Gopher-Buddy-Questions-for-End-Users'
  },
  // Values used when running the extension in local mode
  localApiOverrides: {
    osVersion: ''
  }
};
;// CONCATENATED MODULE: ./apps/gopher-for-chrome/gopher-buddy/src/background-service-worker/services/utils/utils.service.ts

const UtilsSerice = {
  debugLog: (...messages) => {
    if (environment.showDebug) {
      messages.forEach(message => {
        console.log(`[DEBUG]`, message);
      });
    }
  },
  appendUrlArguments: (url, argumentsObject) => {
    const queryString = Object.keys(argumentsObject).map(key => `${key}=${argumentsObject[key]}`).join('&');
    return `${url}?${queryString}`;
  }
};
/* harmony default export */ const utils_service = (UtilsSerice);
;// CONCATENATED MODULE: ./apps/gopher-for-chrome/gopher-buddy/src/background-service-worker/services/gb-api/gopher-buddy-api.service.ts




const getFetch = fetchOptions => {
  utils_service.debugLog(`GopherBuddyApiService.fetch`, fetchOptions);
  const {
    apiToken,
    apiServer
  } = environment;
  let fullUrl = `${apiServer}${fetchOptions.url}?apiToken=${apiToken}`;
  if (fetchOptions.queryParameters !== undefined) {
    Object.entries(fetchOptions.queryParameters).forEach(([key, value]) => {
      fullUrl += `&${key}=${value}`;
    });
  }
  const headers = {
    'Content-Type': 'application/json'
  };
  return fetch(fullUrl, {
    method: fetchOptions.method,
    headers
  }).then(response => response.json());
};
const GopherBuddyApiService = {
  CheckIn: {
    get: function () {
      var _ref = asyncToGenerator_asyncToGenerator(function* (domain, deviceId, email) {
        return getFetch({
          url: `/check-in`,
          method: HttpMethod.GET,
          queryParameters: {
            domain,
            deviceId,
            email
          }
        });
      });
      return function get(_x, _x2, _x3) {
        return _ref.apply(this, arguments);
      };
    }()
  }
};
/* harmony default export */ const gopher_buddy_api_service = (GopherBuddyApiService);
;// CONCATENATED MODULE: ./apps/gopher-for-chrome/gopher-buddy/src/background-service-worker/services/check-in/check-in.state.ts





const check_in_state_initialState = {
  isCustomerValid: false,
  error: null,
  status: StateStatus.IDLE,
  lastCheckIn: new Date(Date.now()).toString() // Default to now
};
const setLastCheckinTime = /*#__PURE__*/function () {
  var _ref = asyncToGenerator_asyncToGenerator(function* () {
    const extensionApi = ExtensionApiFactory();
    yield extensionApi.setLocalStorage({
      checkinTime: String(new Date().getTime())
    });
  });
  return function setLastCheckinTime() {
    return _ref.apply(this, arguments);
  };
}();
const inCheckinWindow = /*#__PURE__*/function () {
  var _ref2 = asyncToGenerator_asyncToGenerator(function* () {
    const extensionApi = ExtensionApiFactory();
    const notificationTimes = yield extensionApi.getLocalStorage('checkinTime');
    if (!notificationTimes?.checkinTime) {
      return true;
    }
    const currentTime = new Date().getTime();
    return currentTime - Number(notificationTimes.checkinTime) > 1 * 60 * 1000; // 1 minuets
  });
  return function inCheckinWindow() {
    return _ref2.apply(this, arguments);
  };
}();
const CheckInEffects = {
  checkIn: createAsyncThunk('CheckIn/checkIn', /*#__PURE__*/function () {
    var _ref3 = asyncToGenerator_asyncToGenerator(function* (arg, thunkState) {
      const state = thunkState.getState();
      // limit the checkin to once every 1 minutes
      // prevents the user from spamming the reload button or prevents the extension from spamming the server
      if (state?.checkInState?.extensionCheckinResponse && !(yield inCheckinWindow())) {
        return undefined;
      }
      yield setLastCheckinTime();
      return gopher_buddy_api_service.CheckIn.get(state.userProfile.userProfile.domain, state.deviceDetails.details.id, state.userProfile.userProfile.email);
    });
    return function (_x, _x2) {
      return _ref3.apply(this, arguments);
    };
  }())
};
const CheckInState = createSlice({
  name: 'CheckIn',
  initialState: check_in_state_initialState,
  reducers: {
    setCustomerValid: (mutableState, action) => {
      Object.assign(mutableState, {
        isCustomerValid: action.payload
      });
    }
  },
  extraReducers: builder => {
    builder.addCase(CheckInEffects.checkIn.pending, mutableState => {
      mutableState.status = StateStatus.LOADING;
    });
    builder.addCase(CheckInEffects.checkIn.fulfilled, (mutableState, action) => {
      if (!action.payload) return;
      mutableState.status = StateStatus.SUCCESS;
      mutableState.extensionCheckinResponse = action.payload;
      mutableState.lastCheckIn = new Date(Date.now()).toString();
      mutableState.isCustomerValid = !('error' in action.payload) && action.payload.isLicensed && action.payload.isAuthorized && action.payload.isConfigured;
    });
    builder.addCase(CheckInEffects.checkIn.rejected, (mutableState, action) => {
      mutableState.isCustomerValid = false;
      mutableState.status = StateStatus.FAILED;
      mutableState.error = action.error;
    });
  }
});
const {
  setCustomerValid
} = CheckInState.actions;
const getCheckInStatus = state => state.checkInState.status;
const isCustomerValid = state => state.checkInState.isCustomerValid;
;// CONCATENATED MODULE: ./apps/gopher-for-chrome/gopher-buddy/src/background-service-worker/services/customer/customer.state.ts


var CustomerTier = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => {
  (function (CustomerTier) {
    CustomerTier["UNLICENSED"] = "unlicensed";
    CustomerTier["PREMIUM"] = "premium";
  })(CustomerTier || (CustomerTier = {}));
  return CustomerTier;
})()));
const customer_state_initialState = {
  error: null,
  status: StateStatus.IDLE
};
const CustomerSettingsState = createSlice({
  name: 'CustomerSettingsReducer',
  initialState: customer_state_initialState,
  reducers: {
    setCustomerSettings: (mutableState, action) => {
      mutableState.status = StateStatus.SUCCESS;
      mutableState.customerSettings = action.payload;
    }
  }
});
const {
  setCustomerSettings
} = CustomerSettingsState.actions;
const getCustomerSettings = state => state.customerState.customerSettings;
;// CONCATENATED MODULE: ./apps/gopher-for-chrome/gopher-buddy/src/background-service-worker/services/device/device.state.ts




const device_state_initialState = {
  error: null,
  status: StateStatus.IDLE,
  detailStatus: StateStatus.IDLE,
  resourceStatus: StateStatus.IDLE,
  details: {
    id: '',
    assetId: '',
    serialNumber: '',
    OSVersion: ''
  }
};
const isStatusComplete = status => status.detailStatus === StateStatus.SUCCESS && status.resourceStatus === StateStatus.SUCCESS ? StateStatus.SUCCESS : StateStatus.LOADING;
const DeviceEffects = {
  fetchDeviceDetails: createAsyncThunk('DeviceDetails/fetchDeviceDetails', /*#__PURE__*/asyncToGenerator_asyncToGenerator(function* () {
    const extensionApi = ExtensionApiFactory();
    return extensionApi.getDevice();
  }))
};
const DeviceDetailsState = createSlice({
  name: 'DeviceDetails',
  initialState: device_state_initialState,
  reducers: {
    setId: (mutableState, action) => {
      mutableState.details.id = action.payload;
    },
    setAssetId: (mutableState, action) => {
      mutableState.details.assetId = action.payload;
    },
    setSerialNumber: (mutableState, action) => {
      mutableState.details.serialNumber = action.payload;
    },
    setOSVersion: (mutableState, action) => {
      mutableState.details.OSVersion = action.payload;
    },
    setDeviceResource: (mutableState, action) => {
      mutableState.deviceResource = action.payload;
      mutableState.resourceStatus = StateStatus.SUCCESS;
      mutableState.status = isStatusComplete(mutableState);
    }
  },
  extraReducers(builder) {
    builder.addCase(DeviceEffects.fetchDeviceDetails.pending, mutableState => {
      mutableState.status = StateStatus.LOADING;
      mutableState.detailStatus = StateStatus.LOADING;
    });
    builder.addCase(DeviceEffects.fetchDeviceDetails.fulfilled, (mutableState, action) => {
      mutableState.details = action.payload;
      mutableState.detailStatus = StateStatus.SUCCESS;
      mutableState.status = isStatusComplete(mutableState);
    });
    builder.addCase(DeviceEffects.fetchDeviceDetails.rejected, (mutableState, action) => {
      mutableState.detailStatus = StateStatus.FAILED;
      mutableState.error = action.error;
    });
  }
});
const {
  setId,
  setAssetId,
  setOSVersion,
  setSerialNumber,
  setDeviceResource
} = DeviceDetailsState.actions;
;// CONCATENATED MODULE: ./apps/gopher-for-chrome/gopher-buddy/src/background-service-worker/services/licensing/licensing.state.ts


const licensing_state_initialState = {
  status: StateStatus.IDLE,
  error: null,
  licenseState: {
    isLicensed: false
  }
};
const LicenseState = createSlice({
  name: 'LicenseStateReducer',
  initialState: licensing_state_initialState,
  reducers: {
    setLicensed: mutableState => {
      mutableState.licenseState.isLicensed = true;
    },
    setUnlicensed: mutableState => {
      mutableState.licenseState.isLicensed = false;
    },
    setLicenseStatus: (mutableState, action) => {
      mutableState.licenseState.isLicensed = action.payload;
    }
  }
});
const {
  setLicensed,
  setUnlicensed,
  setLicenseStatus
} = LicenseState.actions;
const isLicensed = state => state.licenseState.isLicensed;
;// CONCATENATED MODULE: ./apps/gopher-for-chrome/gopher-buddy/src/background-service-worker/services/network-status/network-status.state.ts




const network_status_state_initialState = {
  error: null,
  status: StateStatus.IDLE,
  privateIpStatus: StateStatus.IDLE,
  publicIpStatus: StateStatus.IDLE,
  networkStatus: {
    isOnline: false,
    publicIp: '',
    privateIp: ''
  }
};
const NetworkEffects = {
  getPrivateIp: createAsyncThunk('NetworkStatus/getPrivateIp', /*#__PURE__*/asyncToGenerator_asyncToGenerator(function* () {
    const extensionApi = ExtensionApiFactory();
    const config = yield extensionApi.getNetworkDetails();
    return config.ipv4 || config.ipv6 || 'unknown';
  }))
};
const NetworkStatusState = createSlice({
  name: 'NetworkStatusReducer',
  initialState: network_status_state_initialState,
  reducers: {
    setOnline: mutableState => {
      mutableState.networkStatus.isOnline = true;
    },
    setOffline: mutableState => {
      mutableState.networkStatus.isOnline = false;
    },
    setPublicIp: (mutableState, action) => {
      mutableState.networkStatus.publicIp = action.payload;
      mutableState.publicIpStatus = StateStatus.SUCCESS;
      if (mutableState.privateIpStatus === StateStatus.SUCCESS) {
        mutableState.status = StateStatus.SUCCESS;
      }
    },
    setPrivateIp: (mutableState, action) => {
      mutableState.networkStatus.privateIp = action.payload;
      mutableState.privateIpStatus = StateStatus.SUCCESS;
      if (mutableState.publicIpStatus === StateStatus.SUCCESS) {
        mutableState.status = StateStatus.SUCCESS;
      }
    }
  },
  extraReducers: builder => {
    builder.addCase(NetworkEffects.getPrivateIp.pending, mutableState => {
      mutableState.status = StateStatus.LOADING;
      mutableState.privateIpStatus = StateStatus.LOADING;
    });
    builder.addCase(NetworkEffects.getPrivateIp.fulfilled, (mutableState, action) => {
      mutableState.networkStatus.privateIp = action.payload;
      mutableState.privateIpStatus = StateStatus.SUCCESS;
      if (mutableState.publicIpStatus === StateStatus.SUCCESS) {
        mutableState.status = StateStatus.SUCCESS;
      }
    });
    builder.addCase(NetworkEffects.getPrivateIp.rejected, (mutableState, action) => {
      mutableState.privateIpStatus = StateStatus.FAILED;
      mutableState.error = action.error;
    });
  }
});
const {
  setOnline,
  setOffline,
  setPublicIp,
  setPrivateIp
} = NetworkStatusState.actions;
const getOnlineStatus = state => state.networkStatus.networkStatus.isOnline;
const getPublicIp = state => state.networkStatus.networkStatus.publicIp;
const getPrivateIp = state => state.networkStatus.networkStatus.privateIp;
;// CONCATENATED MODULE: ./apps/gopher-for-chrome/gopher-buddy/src/background-service-worker/services/pubsub/pubsub.service.ts

let pubsubConfig = {
  topic: 'NOT_SET',
  project: 'NOT_SET',
  apiKey: 'NOT_SET',
  attributes: []
};
const makeAttributes = (payload, attributes) => {
  const result = {};
  attributes.forEach(attr => {
    if (attr in payload) {
      result[attr] = payload[attr];
    }
  });
  return result;
};
const generateMessages = (payloads, attributes) => payloads.map(payload => ({
  data: globalThis.btoa(JSON.stringify(payload)),
  attributes: makeAttributes(payload, attributes)
}));
const postMessages = /*#__PURE__*/function () {
  var _ref = asyncToGenerator_asyncToGenerator(function* (payloads) {
    const key = pubsubConfig.apiKey;
    const url = `https://pubsub.googleapis.com/v1/projects/${pubsubConfig.project}/topics/${pubsubConfig.topic}:publish?key=${key}`;
    const response = yield fetch(url, {
      method: 'POST',
      body: JSON.stringify({
        messages: generateMessages(payloads, pubsubConfig.attributes)
      })
    });
    yield response.json();
    return {
      success: true
    };
  });
  return function postMessages(_x) {
    return _ref.apply(this, arguments);
  };
}();
const PubsubService = {
  init: function () {
    var _ref2 = asyncToGenerator_asyncToGenerator(function* (config) {
      pubsubConfig = {
        topic: config.topic,
        project: config.project,
        apiKey: config.apiKey,
        attributes: config.attributes ?? []
      };
    });
    return function init(_x2) {
      return _ref2.apply(this, arguments);
    };
  }(),
  publishToTopic: function () {
    var _ref3 = asyncToGenerator_asyncToGenerator(function* (payload) {
      return postMessages(Array.isArray(payload) ? payload : [payload]);
    });
    return function publishToTopic(_x3) {
      return _ref3.apply(this, arguments);
    };
  }()
};
/* harmony default export */ const pubsub_service = (PubsubService);
;// CONCATENATED MODULE: ./apps/gopher-for-chrome/gopher-buddy/src/background-service-worker/services/update-session/update-session.state.ts





const update_session_state_initialState = {
  sessionPings: [],
  offlineSessionPings: [],
  error: null,
  status: StateStatus.IDLE
};
const UpdateSessionEffects = {
  sendSessionPings: createAsyncThunk('UpdateSession/sendSessionPings', /*#__PURE__*/function () {
    var _ref = asyncToGenerator_asyncToGenerator(function* (sessionPings) {
      return {
        publishStatus: yield pubsub_service.publishToTopic(sessionPings.map(sp => sp.sessionPayload)),
        sessions: sessionPings
      };
    });
    return function (_x) {
      return _ref.apply(this, arguments);
    };
  }())
};
const UpdateSessionState = createSlice({
  name: 'UpdateSession',
  initialState: update_session_state_initialState,
  reducers: {
    addOfflineSessionPing: {
      reducer(mutableState, action) {
        mutableState.offlineSessionPings.push(action.payload);
      },
      prepare(sessionPayload) {
        return {
          payload: {
            sessionPayload: {
              ...sessionPayload,
              timestamp: sessionPayload.timestamp ?? new Date().toISOString()
            },
            id: nanoid()
          }
        };
      }
    },
    addHydratedSessionPing: (mutableState, action) => {
      mutableState.sessionPings.push(action.payload);
    },
    addSessionPing: {
      reducer(mutableState, action) {
        mutableState.sessionPings.push(action.payload);
      },
      prepare(sessionPayload) {
        return {
          payload: {
            sessionPayload: {
              ...sessionPayload,
              timestamp: sessionPayload.timestamp ?? new Date().toISOString()
            },
            id: nanoid()
          }
        };
      }
    },
    removeSessionPing: (mutableState, action) => {
      mutableState.sessionPings = mutableState.sessionPings.filter(sp => sp.id !== action.payload);
    },
    clearOfflineSessionPings: mutableState => {
      mutableState.offlineSessionPings = [];
    }
  },
  extraReducers: builder => {
    builder.addCase(UpdateSessionEffects.sendSessionPings.pending, mutableState => {
      mutableState.status = StateStatus.LOADING;
    });
    builder.addCase(UpdateSessionEffects.sendSessionPings.fulfilled, (mutableState, action) => {
      const isSessionPingComplete = sessionPing => !action.payload.sessions.some(session => session.id === sessionPing.id);
      mutableState.sessionPings = mutableState.sessionPings.filter(isSessionPingComplete);
      mutableState.status = StateStatus.SUCCESS;
    });
    builder.addCase(UpdateSessionEffects.sendSessionPings.rejected, (mutableState, action) => {
      utils_service.debugLog('UpdateSessionEffects.sendSessionPings.rejected', action.error);
      mutableState.status = StateStatus.FAILED;
      mutableState.error = action.error;
    });
  }
});
const {
  addSessionPing,
  removeSessionPing,
  addOfflineSessionPing,
  clearOfflineSessionPings,
  addHydratedSessionPing
} = UpdateSessionState.actions;
const getUpdateSessions = state => state.updateSessionState.sessionPings;
;// CONCATENATED MODULE: ./apps/gopher-for-chrome/gopher-buddy/src/background-service-worker/services/user-activity/user-activity.state.ts

const UserActivityState = createSlice({
  name: 'UserActivityReducer',
  initialState: {
    isActive: true
  },
  reducers: {
    setActive: mutableState => {
      mutableState.isActive = true;
    },
    setInactive: mutableState => {
      mutableState.isActive = false;
    }
  }
});
const {
  setActive,
  setInactive
} = UserActivityState.actions;
;// CONCATENATED MODULE: ./apps/gopher-for-chrome/gopher-buddy/src/background-service-worker/services/user-profile/user-profile.state.ts


var UserAccessType = /*#__PURE__*/(() => {
  (function (UserAccessType) {
    UserAccessType["NONE"] = "none";
    UserAccessType["BASIC"] = "basic";
    UserAccessType["FULL"] = "full";
  })(UserAccessType || (UserAccessType = {}));
  return UserAccessType;
})();
const user_profile_state_initialState = {
  error: null,
  status: StateStatus.IDLE,
  userProfile: {
    email: '',
    id: '',
    domain: '',
    accessLevel: UserAccessType.NONE
  }
};
const UserProfileEffects = {
  fetchUserProfile: () => {
    console.log('fetchUserProfile');
  }
};
const UserProfileState = createSlice({
  name: 'UserProfileReducer',
  initialState: user_profile_state_initialState,
  reducers: {
    setProfileDetails: (mutableState, action) => {
      mutableState.userProfile.accessLevel = action.payload.accessLevel;
      mutableState.userProfile.userOrgUnitPath = action.payload.userOrgUnitPath;
      mutableState.userProfile.userJWT = action.payload.userJWT;
      mutableState.status = StateStatus.SUCCESS;
    },
    setEmail: (mutableState, action) => {
      mutableState.userProfile.email = action.payload;
    },
    setId: (mutableState, action) => {
      mutableState.userProfile.id = action.payload;
    },
    setDomain: (mutableState, action) => {
      mutableState.userProfile.domain = action.payload;
    },
    setUserAccessLevel: (mutableState, action) => {
      mutableState.userProfile.accessLevel = action.payload;
    },
    setUserJWT: (mutableState, action) => {
      mutableState.userProfile.userJWT = action.payload;
    }
  }
});
const {
  setEmail,
  setId: user_profile_state_setId,
  setDomain,
  setUserAccessLevel,
  setUserJWT,
  setProfileDetails
} = UserProfileState.actions;
const getUserProfile = state => state.userProfile;
;// CONCATENATED MODULE: ./apps/gopher-for-chrome/gopher-buddy/src/background-service-worker/services/version-update/version-update.state.ts


const version_update_state_initialState = {
  error: null,
  status: StateStatus.IDLE,
  updateNeeded: false,
  updateVersion: ''
};
const VersionUpdateState = createSlice({
  name: 'VersionUpdateReducer',
  initialState: version_update_state_initialState,
  reducers: {
    setUpdateNeeded: (mutableState, action) => {
      mutableState.updateNeeded = action.payload;
      mutableState.status = StateStatus.SUCCESS;
    },
    setUpdateVersion: (mutableState, action) => {
      mutableState.updateVersion = action.payload;
    }
  }
});
const {
  setUpdateNeeded,
  setUpdateVersion
} = VersionUpdateState.actions;
;// CONCATENATED MODULE: ./apps/gopher-for-chrome/gopher-buddy/src/background-service-worker/services/extension-store/extension.store.ts













const rootReducer = combineReducers({
  networkStatus: NetworkStatusState.reducer,
  userActivity: UserActivityState.reducer,
  userProfile: UserProfileState.reducer,
  deviceDetails: DeviceDetailsState.reducer,
  alarmState: AlarmStatus.reducer,
  licenseState: LicenseState.reducer,
  checkInState: CheckInState.reducer,
  customerState: CustomerSettingsState.reducer,
  updateSessionState: UpdateSessionState.reducer,
  versionUpdateState: VersionUpdateState.reducer,
  globalAppFlagsState: GlobalAppFlagsState.reducer
});
const rootStore = configureStore({
  reducer: rootReducer
});
;// CONCATENATED MODULE: ./apps/gopher-for-chrome/gopher-buddy/src/background-service-worker/services/alerts/alerts-service.ts





const MAIN_ALARM_NAME = 'gopher-buddy-main-alarm';
let extensionApi;
const AlertService = {
  init: function () {
    var _ref = asyncToGenerator_asyncToGenerator(function* () {
      utils_service.debugLog('Main Alarm Init');
      extensionApi = ExtensionApiFactory();
      yield extensionApi.clearAllAlarms();
      const alarm = yield extensionApi.getAlarm(MAIN_ALARM_NAME);
      if (typeof alarm === 'undefined') {
        utils_service.debugLog(`Creating main alarm: ${MAIN_ALARM_NAME}`);
        yield extensionApi.createAlarm(MAIN_ALARM_NAME, {
          periodInMinutes: 1
        });
      } else {
        utils_service.debugLog(`Creating main alarm: ${MAIN_ALARM_NAME}. ${JSON.stringify(alarm)}`);
      }
      extensionApi.addAlarmListener(alarmtrigger => {
        if (alarmtrigger.name === MAIN_ALARM_NAME) {
          utils_service.debugLog(`Main alarm triggered: ${MAIN_ALARM_NAME}`, `Saving State`);
          rootStore.dispatch(setLastUpated(Date.now()));
        }
      });
    });
    return function init() {
      return _ref.apply(this, arguments);
    };
  }()
};
/* harmony default export */ const alerts_service = (AlertService);
;// CONCATENATED MODULE: ./node_modules/rxjs/dist/esm/internal/util/ObjectUnsubscribedError.js

const ObjectUnsubscribedError = createErrorClass(_super => function ObjectUnsubscribedErrorImpl() {
  _super(this);
  this.name = 'ObjectUnsubscribedError';
  this.message = 'object unsubscribed';
});
//# sourceMappingURL=ObjectUnsubscribedError.js.map
;// CONCATENATED MODULE: ./node_modules/rxjs/dist/esm/internal/Subject.js





let Subject = /*#__PURE__*/(() => {
  class Subject extends Observable {
    constructor() {
      super();
      this.closed = false;
      this.currentObservers = null;
      this.observers = [];
      this.isStopped = false;
      this.hasError = false;
      this.thrownError = null;
    }
    lift(operator) {
      const subject = new AnonymousSubject(this, this);
      subject.operator = operator;
      return subject;
    }
    _throwIfClosed() {
      if (this.closed) {
        throw new ObjectUnsubscribedError();
      }
    }
    next(value) {
      errorContext(() => {
        this._throwIfClosed();
        if (!this.isStopped) {
          if (!this.currentObservers) {
            this.currentObservers = Array.from(this.observers);
          }
          for (const observer of this.currentObservers) {
            observer.next(value);
          }
        }
      });
    }
    error(err) {
      errorContext(() => {
        this._throwIfClosed();
        if (!this.isStopped) {
          this.hasError = this.isStopped = true;
          this.thrownError = err;
          const {
            observers
          } = this;
          while (observers.length) {
            observers.shift().error(err);
          }
        }
      });
    }
    complete() {
      errorContext(() => {
        this._throwIfClosed();
        if (!this.isStopped) {
          this.isStopped = true;
          const {
            observers
          } = this;
          while (observers.length) {
            observers.shift().complete();
          }
        }
      });
    }
    unsubscribe() {
      this.isStopped = this.closed = true;
      this.observers = this.currentObservers = null;
    }
    get observed() {
      var _a;
      return ((_a = this.observers) === null || _a === void 0 ? void 0 : _a.length) > 0;
    }
    _trySubscribe(subscriber) {
      this._throwIfClosed();
      return super._trySubscribe(subscriber);
    }
    _subscribe(subscriber) {
      this._throwIfClosed();
      this._checkFinalizedStatuses(subscriber);
      return this._innerSubscribe(subscriber);
    }
    _innerSubscribe(subscriber) {
      const {
        hasError,
        isStopped,
        observers
      } = this;
      if (hasError || isStopped) {
        return EMPTY_SUBSCRIPTION;
      }
      this.currentObservers = null;
      observers.push(subscriber);
      return new Subscription(() => {
        this.currentObservers = null;
        arrRemove(observers, subscriber);
      });
    }
    _checkFinalizedStatuses(subscriber) {
      const {
        hasError,
        thrownError,
        isStopped
      } = this;
      if (hasError) {
        subscriber.error(thrownError);
      } else if (isStopped) {
        subscriber.complete();
      }
    }
    asObservable() {
      const observable = new Observable();
      observable.source = this;
      return observable;
    }
  }
  Subject.create = (destination, source) => {
    return new AnonymousSubject(destination, source);
  };
  return Subject;
})();
class AnonymousSubject extends Subject {
  constructor(destination, source) {
    super();
    this.destination = destination;
    this.source = source;
  }
  next(value) {
    var _a, _b;
    (_b = (_a = this.destination) === null || _a === void 0 ? void 0 : _a.next) === null || _b === void 0 ? void 0 : _b.call(_a, value);
  }
  error(err) {
    var _a, _b;
    (_b = (_a = this.destination) === null || _a === void 0 ? void 0 : _a.error) === null || _b === void 0 ? void 0 : _b.call(_a, err);
  }
  complete() {
    var _a, _b;
    (_b = (_a = this.destination) === null || _a === void 0 ? void 0 : _a.complete) === null || _b === void 0 ? void 0 : _b.call(_a);
  }
  _subscribe(subscriber) {
    var _a, _b;
    return (_b = (_a = this.source) === null || _a === void 0 ? void 0 : _a.subscribe(subscriber)) !== null && _b !== void 0 ? _b : EMPTY_SUBSCRIPTION;
  }
}
//# sourceMappingURL=Subject.js.map
;// CONCATENATED MODULE: ./apps/gopher-for-chrome/gopher-buddy/src/background-service-worker/services/check-in/check-in.service.ts












const checkInTimer = timer(0, environment.defaultTimings.checkInIntervalInSeconds * 1000);
const forceCheckinTrigger = new Subject();
let retries = 0;
let retryBackoffInSeconds = 5;
const retryCheckIn = () => {
  timer(retryBackoffInSeconds * 1000).subscribe(() => {
    utils_service.debugLog(`CheckInService CheckforRetry`, `Retrying checkin attempt ${retries}`, `Retrying in ${retryBackoffInSeconds} seconds`);
    retries++;
    retryBackoffInSeconds = retryBackoffInSeconds < 60 ? retryBackoffInSeconds *= 2 : 60;
    forceCheckinTrigger.next();
  });
};
const checkforRetry = () => {
  const MAX_RETRIES = 15;
  const newAppState = rootStore.getState();
  if (retries >= MAX_RETRIES) {
    utils_service.debugLog(`CheckInService Max retries reached`);
  }
  return (getCheckInStatus(newAppState) === StateStatus.FAILED || !isCustomerValid(newAppState)) && retries < MAX_RETRIES;
};
const saveDeviceDetails = deviceDetails => {
  if (!deviceDetails) return;
  rootStore.dispatch(setPublicIp(deviceDetails?.publicIP ?? 'NOTE_SET'));
  rootStore.dispatch(setDeviceResource(deviceDetails));
};
const saveCustomerSettings = customerDetails => {
  if (!customerDetails) return;
  rootStore.dispatch(setCustomerSettings(customerDetails));
};
const saveUserDetails = userDetails => {
  if (!userDetails) return;
  rootStore.dispatch(setProfileDetails(userDetails));
};
const saveLicenseState = isLicensed => {
  rootStore.dispatch(setLicenseStatus(isLicensed ?? false));
};
const CheckInService = {
  init: function () {
    var _ref = asyncToGenerator_asyncToGenerator(function* () {
      forceCheckinTrigger.subscribe( /*#__PURE__*/asyncToGenerator_asyncToGenerator(function* () {
        utils_service.debugLog(`CheckInService Forced Triggered`);
        yield rootStore.dispatch(CheckInEffects.checkIn());
        if (checkforRetry()) {
          retryCheckIn();
        }
      }));
      checkInTimer.subscribe( /*#__PURE__*/asyncToGenerator_asyncToGenerator(function* () {
        utils_service.debugLog(`CheckInService Time Triggered`);
        yield rootStore.dispatch(CheckInEffects.checkIn());
        if (checkforRetry()) {
          retryCheckIn();
        }
        const newAppState = rootStore.getState();
        saveDeviceDetails(newAppState.checkInState.extensionCheckinResponse?.deviceDetails);
        saveCustomerSettings(newAppState.checkInState.extensionCheckinResponse?.customerDetails);
        saveUserDetails(newAppState.checkInState.extensionCheckinResponse?.userDetails);
        saveLicenseState(newAppState.checkInState.extensionCheckinResponse?.isLicensed);
      }));
    });
    return function init() {
      return _ref.apply(this, arguments);
    };
  }()
};
/* harmony default export */ const check_in_service = (CheckInService);
;// CONCATENATED MODULE: ./apps/gopher-for-chrome/gopher-buddy/src/background-service-worker/services/customer/customer.service.ts


const CustomerService = {
  init: function () {
    var _ref = asyncToGenerator_asyncToGenerator(function* () {
      utils_service.debugLog('Customer Service Init');
    });
    return function init() {
      return _ref.apply(this, arguments);
    };
  }()
};
/* harmony default export */ const customer_service = (CustomerService);
;// CONCATENATED MODULE: ./apps/gopher-for-chrome/gopher-buddy/src/background-service-worker/services/device/device.service.ts

/// <reference types="user-agent-data-types" />






// Will return the Chrome version with the minor versions if available (e.g. 122.0.6261.95)
// If not available, it will return the major version (e.g. 122.0.0.0)
const getOSVersion = /*#__PURE__*/function () {
  var _ref = asyncToGenerator_asyncToGenerator(function* () {
    if (environment.environment === RuntimeEnvironment.LOCAL && environment.localApiOverrides?.osVersion) {
      return environment.localApiOverrides?.osVersion;
    }
    let version = 'UNKNOWN';
    if (navigator.userAgentData) {
      const versionList = yield navigator.userAgentData.getHighEntropyValues(['fullVersionList']);
      utils_service.debugLog(`Detected Browser Agents`, versionList);
      version = versionList.fullVersionList?.find(osVersion => osVersion.brand === 'Google Chrome')?.version ?? 'UNKNOWN';
      if (version !== 'UNKNOWN') {
        return version;
      }
    }
    const {
      userAgent
    } = navigator; // may not contain the minor version
    const verExp = /Chrome\/([0-9.]+)/;
    version = verExp.exec(userAgent)?.[1] ?? 'UNKNOWN';
    return version;
  });
  return function getOSVersion() {
    return _ref.apply(this, arguments);
  };
}();
const DeviceService = {
  init: function () {
    var _ref2 = asyncToGenerator_asyncToGenerator(function* () {
      utils_service.debugLog('Device Service Init');
      // Fetch the device details from chrome api
      yield rootStore.dispatch(DeviceEffects.fetchDeviceDetails());
      // Set the OS version
      const osVersion = yield getOSVersion();
      rootStore.dispatch(setOSVersion(osVersion));
    });
    return function init() {
      return _ref2.apply(this, arguments);
    };
  }(),
  setManagedStatus: function () {
    var _ref3 = asyncToGenerator_asyncToGenerator(function* () {
      const currentState = rootStore.getState();
      if (currentState.deviceDetails.detailStatus === StateStatus.FAILED || currentState.networkStatus.status === StateStatus.FAILED) {
        rootStore.dispatch(setdeviceManagedState(DeviceManagedState.NOT_MANAGED));
      }
    });
    return function setManagedStatus() {
      return _ref3.apply(this, arguments);
    };
  }()
};
/* harmony default export */ const device_service = (DeviceService);
;// CONCATENATED MODULE: ./apps/gopher-for-chrome/gopher-buddy/src/background-service-worker/services/licensing/licensing.service.ts


const LicenseService = {
  init: function () {
    var _ref = asyncToGenerator_asyncToGenerator(function* () {
      utils_service.debugLog('License Service Init');
    });
    return function init() {
      return _ref.apply(this, arguments);
    };
  }()
};
/* harmony default export */ const licensing_service = (LicenseService);
;// CONCATENATED MODULE: ./apps/gopher-for-chrome/gopher-buddy/src/background-service-worker/services/message-handler/message-handler.interfaces.ts
var GBMessages = /*#__PURE__*/(() => {
  (function (GBMessages) {
    GBMessages["GET_EXTENSION_STATE"] = "getExtensionState";
    GBMessages["CLEAR_CACHE"] = "clearCache";
    GBMessages["RELOAD_EXTENSION"] = "reloadExtension";
    GBMessages["RESYNC_EXTENSION"] = "resyncExtension";
    GBMessages["OPEN_HELP"] = "openChromeHelp";
    GBMessages["OPEN_DEVICE_INFO"] = "openDeviceInfo";
    GBMessages["CHECK_VERSION"] = "checkVersion";
    GBMessages["FIX_VERSION"] = "fixVersion";
    GBMessages["OPEN_FAQ"] = "openFAQ";
  })(GBMessages || (GBMessages = {}));
  return GBMessages;
})();
;// CONCATENATED MODULE: ./apps/gopher-for-chrome/gopher-buddy/src/background-service-worker/services/version-update/version-update.service.ts







const openRemoteHelp = /*#__PURE__*/function () {
  var _ref = asyncToGenerator_asyncToGenerator(function* () {
    const extensionApi = ExtensionApiFactory();
    const state = rootStore.getState();
    const url = utils_service.appendUrlArguments(`${environment.apiServer}/support`, {
      method: 'help',
      domain: state.customerState.customerSettings?.customerId ?? 'NOT_SET',
      uuid: state.deviceDetails.details.id,
      source: 'popup'
    });
    yield extensionApi.createTab({
      url
    });
  });
  return function openRemoteHelp() {
    return _ref.apply(this, arguments);
  };
}();
const showFixVersionNotification = () => {
  const NOTIFICATION_ID = 'fixVersionId';
  const extensionApi = ExtensionApiFactory();
  const fixVersionOptions = {
    type: 'basic',
    iconUrl: 'assets/images/gb_default_icon.png',
    title: "Let's update Chrome.",
    message: 'Please read the "About Chrome" page carefully and follow Google\'s instructions to update Chrome.',
    buttons: [{
      title: 'I got it!'
    }, {
      title: 'I need more help'
    }],
    requireInteraction: true
  };
  extensionApi.clearNotification(NOTIFICATION_ID);
  extensionApi.showNotification(NOTIFICATION_ID, fixVersionOptions);
  extensionApi.setNotificationListener( /*#__PURE__*/function () {
    var _ref2 = asyncToGenerator_asyncToGenerator(function* (notificationId, buttonIndex) {
      if (notificationId === NOTIFICATION_ID) {
        if (buttonIndex === 0) {
          // Will be prompted again next time Button is clicked
        }
        if (buttonIndex === 1) {
          yield openRemoteHelp();
        }
        extensionApi.clearNotification(NOTIFICATION_ID);
      }
    });
    return function (_x, _x2) {
      return _ref2.apply(this, arguments);
    };
  }());
};
const setLastNotificationTime = /*#__PURE__*/function () {
  var _ref3 = asyncToGenerator_asyncToGenerator(function* () {
    const extensionApi = ExtensionApiFactory();
    yield extensionApi.setLocalStorage({
      lastNotificationTime: String(new Date().getTime())
    });
  });
  return function setLastNotificationTime() {
    return _ref3.apply(this, arguments);
  };
}();
const inNotificationWindow = /*#__PURE__*/function () {
  var _ref4 = asyncToGenerator_asyncToGenerator(function* () {
    const extensionApi = ExtensionApiFactory();
    const notificationTimes = yield extensionApi.getLocalStorage('lastNotificationTime');
    if (!notificationTimes) {
      return true;
    }
    const currentTime = new Date().getTime();
    return currentTime - Number(notificationTimes.lastNotificationTime) > 15 * 60 * 1000;
  });
  return function inNotificationWindow() {
    return _ref4.apply(this, arguments);
  };
}();
const showUpdatePopup = /*#__PURE__*/function () {
  var _ref5 = asyncToGenerator_asyncToGenerator(function* () {
    // ensure the notification is shown only once in a 15 minute window
    if (!(yield inNotificationWindow())) {
      return;
    }
    yield setLastNotificationTime();
    const NOTIFICATION_ID = 'updateNotificationId';
    const extensionApi = ExtensionApiFactory();
    const notificationOptions = {
      type: 'basic',
      iconUrl: 'assets/images/gb_default_icon.png',
      title: 'Chrome is out of date',
      message: 'You need to update Chrome.\nClick "Ok" to open the update page, or "Later" to get reminded later.',
      buttons: [{
        title: 'Ok'
      }, {
        title: 'Later'
      }],
      requireInteraction: true
    };
    extensionApi.clearNotification(NOTIFICATION_ID);
    extensionApi.showNotification(NOTIFICATION_ID, notificationOptions);
    extensionApi.setNotificationListener( /*#__PURE__*/function () {
      var _ref6 = asyncToGenerator_asyncToGenerator(function* (notificationId, buttonIndex) {
        if (notificationId === NOTIFICATION_ID) {
          if (buttonIndex === 0) {
            yield extensionApi.createTab({
              url: 'chrome://os-settings/help'
            });
          }
          if (buttonIndex === 1) {
            // Will be prompted again when the extension is reloaded
          }
          extensionApi.clearNotification(NOTIFICATION_ID);
        }
      });
      return function (_x3, _x4) {
        return _ref6.apply(this, arguments);
      };
    }());
  });
  return function showUpdatePopup() {
    return _ref5.apply(this, arguments);
  };
}();
// Specific to Chrome version of Major.Minor.Patch.Build
// We treat the Build as the minor version
const parseVersion = version => {
  const matcher = /(\d+)\.?\d*\.\d*\.(\d+)/;
  const match = version.match(matcher) ?? [];
  return {
    major: Number(match[1]),
    minor: Number(match[2])
  };
};
const updateRequired = (currentOsVersion, latestStableVersion, popupThreshold, minorVersionThreshold, restrictChromeOsVersionUpdates, restrictChromeOsMinorVersion, chromeOsVersionMax, chromeOsMinorVersionMax) => {
  const {
    major: currentMajor,
    minor: currentMinor
  } = parseVersion(currentOsVersion);
  const {
    major: latestMajor,
    minor: latestMinor
  } = parseVersion(latestStableVersion);
  if (currentMajor < latestMajor) {
    return latestMajor - currentMajor >= popupThreshold && (!restrictChromeOsVersionUpdates || latestMajor <= chromeOsVersionMax);
  }
  if (currentMajor === latestMajor) {
    return latestMinor - currentMinor >= minorVersionThreshold && (!restrictChromeOsMinorVersion || latestMinor <= chromeOsMinorVersionMax);
  }
  return false;
};
const VersionUpdateService = {
  init: function () {
    var _ref7 = asyncToGenerator_asyncToGenerator(function* () {
      utils_service.debugLog('VersionUpdateService.init');
      const unSub = rootStore.subscribe( /*#__PURE__*/asyncToGenerator_asyncToGenerator(function* () {
        const state = rootStore.getState();
        const currentOsVersion = state.deviceDetails.details.OSVersion;
        const latestStableVersion = state.deviceDetails.deviceResource?.latestStableVersion;
        if (state.customerState?.customerSettings?.settings.allowChromeOsUpdateReminders && state.versionUpdateState.status === StateStatus.IDLE && currentOsVersion && latestStableVersion) {
          const isUpdateRequired = updateRequired(currentOsVersion, latestStableVersion, state.customerState.customerSettings.settings.popupThreshold, state.customerState.customerSettings.settings.minorVersionThreshold, state.customerState.customerSettings.settings.restrictChromeOsVersionUpdates, state.customerState.customerSettings.settings.restrictChromeOsMinorVersion, state.customerState.customerSettings.settings.chromeOsVersionMax, state.customerState.customerSettings.settings.chromeOsMinorVersionMax);
          if (isUpdateRequired) {
            const extensionApi = ExtensionApiFactory();
            yield extensionApi.setIconBadge({
              backgroundColor: 'red',
              text: '!',
              textColor: 'black'
            }); // Add a badge to call out an action in needed.
            unSub();
            rootStore.dispatch(setUpdateVersion(latestStableVersion));
            rootStore.dispatch(setUpdateNeeded(isUpdateRequired));
            yield showUpdatePopup();
          }
        }
      }));
    });
    return function init() {
      return _ref7.apply(this, arguments);
    };
  }(),
  showFixVersionNotification,
  openRemoteHelp
};
/* harmony default export */ const version_update_service = (VersionUpdateService);
;// CONCATENATED MODULE: ./apps/gopher-for-chrome/gopher-buddy/src/background-service-worker/services/message-handler/message-handler.service.ts








const MessageHandlerService = {
  init: function () {
    var _ref = asyncToGenerator_asyncToGenerator(function* () {
      const extensionApi = ExtensionApiFactory();
      utils_service.debugLog('MessageHandlerService.init');
      extensionApi.addMessageListener(GBMessages.GET_EXTENSION_STATE, /*#__PURE__*/asyncToGenerator_asyncToGenerator(function* () {
        return rootStore.getState();
      }));
      extensionApi.addMessageListener(GBMessages.OPEN_HELP, /*#__PURE__*/asyncToGenerator_asyncToGenerator(function* () {
        yield version_update_service.openRemoteHelp();
      }));
      extensionApi.addMessageListener(GBMessages.OPEN_DEVICE_INFO, /*#__PURE__*/asyncToGenerator_asyncToGenerator(function* () {
        const state = rootStore.getState();
        const url = utils_service.appendUrlArguments(`${environment.apiServer}/support`, {
          method: 'deviceInfo',
          jwtToken: state.userProfile.userProfile.userJWT ?? 'NOT_SET',
          c: state.deviceDetails.details.id,
          d: state.userProfile.userProfile.domain,
          u: state.userProfile.userProfile.id,
          e: state.userProfile.userProfile.email,
          i: extensionApi.getExtensionId()
        });
        yield extensionApi.createTab({
          url
        });
      }));
      extensionApi.addMessageListener(GBMessages.CLEAR_CACHE, /*#__PURE__*/asyncToGenerator_asyncToGenerator(function* () {
        try {
          yield extensionApi.clearStorage();
          return {
            success: true
          };
        } catch (error) {
          return {
            success: false
          };
        }
      }));
      extensionApi.addMessageListener(GBMessages.RELOAD_EXTENSION, /*#__PURE__*/asyncToGenerator_asyncToGenerator(function* () {
        yield extensionApi.reloadExtension();
      }));
      extensionApi.addMessageListener(GBMessages.RESYNC_EXTENSION, /*#__PURE__*/asyncToGenerator_asyncToGenerator(function* () {
        try {
          yield rootStore.dispatch(CheckInEffects.checkIn());
          return {
            success: true
          };
        } catch (error) {
          return {
            success: false
          };
        }
      }));
      extensionApi.addMessageListener(GBMessages.CHECK_VERSION, /*#__PURE__*/asyncToGenerator_asyncToGenerator(function* () {
        try {
          yield version_update_service.init();
          return {
            success: true
          };
        } catch (error) {
          return {
            success: false
          };
        }
      }));
      extensionApi.addMessageListener(GBMessages.FIX_VERSION, /*#__PURE__*/asyncToGenerator_asyncToGenerator(function* () {
        try {
          yield extensionApi.createTab({
            url: 'chrome://os-settings/help'
          });
          version_update_service.showFixVersionNotification();
          return {
            success: true
          };
        } catch (error) {
          return {
            success: false
          };
        }
      }));
      extensionApi.addMessageListener(GBMessages.OPEN_FAQ, /*#__PURE__*/asyncToGenerator_asyncToGenerator(function* () {
        yield extensionApi.createTab({
          url: environment.publicUrls.faqHelp
        });
      }));
    });
    return function init() {
      return _ref.apply(this, arguments);
    };
  }()
};
/* harmony default export */ const message_handler_service = (MessageHandlerService);
;// CONCATENATED MODULE: ./apps/gopher-for-chrome/gopher-buddy/src/background-service-worker/services/network-status/network-status.service.ts






const networkStatusTrigger$ = timer(0, environment.defaultTimings.networkStatusCheckIntervalInSeconds * 1000);
const checkNetworkStatus = /*#__PURE__*/function () {
  var _ref = asyncToGenerator_asyncToGenerator(function* () {
    if (!globalThis.navigator.onLine) {
      rootStore.dispatch(setOffline());
      return;
    }
    // If online check a real URL to verify the network status
    try {
      yield fetch('https://www.google.com'); // TODO: Replace with a more reliable URL
      rootStore.dispatch(setOnline());
    } catch (error) {
      rootStore.dispatch(setOffline());
    }
  });
  return function checkNetworkStatus() {
    return _ref.apply(this, arguments);
  };
}();
const NetworkStatusService = {
  init: function () {
    var _ref2 = asyncToGenerator_asyncToGenerator(function* () {
      utils_service.debugLog('Network Status Service Init');
      yield rootStore.dispatch(NetworkEffects.getPrivateIp());
      networkStatusTrigger$.subscribe( /*#__PURE__*/asyncToGenerator_asyncToGenerator(function* () {
        yield checkNetworkStatus();
      }));
    });
    return function init() {
      return _ref2.apply(this, arguments);
    };
  }()
};
/* harmony default export */ const network_status_service = (NetworkStatusService);
;// CONCATENATED MODULE: ./apps/gopher-for-chrome/gopher-buddy/src/background-service-worker/services/offlineSync/offline-sync.interfaces.ts
const OFFLINE_SYNC_FIELDS = ['offlineSessionPings'];
;// CONCATENATED MODULE: ./apps/gopher-for-chrome/gopher-buddy/src/background-service-worker/services/offlineSync/offline-sync.servce.ts






/**
 * Move the offline session pings to local storage.
 * @param currentOfflineFields - The current offline sync fields.
 * @param appState - The application state.
 * @returns The updated offline sync fields.
 */
const updateOfflineSessionPings = /*#__PURE__*/function () {
  var _ref = asyncToGenerator_asyncToGenerator(function* (mutableCurrentOfflineFields, appState) {
    const extensionApi = ExtensionApiFactory();
    if (Array.isArray(appState.updateSessionState.offlineSessionPings) && appState.updateSessionState.offlineSessionPings.length > 0) {
      if (!Array.isArray(mutableCurrentOfflineFields.offlineSessionPings)) {
        mutableCurrentOfflineFields.offlineSessionPings = [];
      }
      mutableCurrentOfflineFields.offlineSessionPings = [...mutableCurrentOfflineFields.offlineSessionPings, ...appState.updateSessionState.offlineSessionPings];
      yield extensionApi.setLocalStorage({
        ...mutableCurrentOfflineFields
      });
      rootStore.dispatch(clearOfflineSessionPings());
    }
  });
  return function updateOfflineSessionPings(_x, _x2) {
    return _ref.apply(this, arguments);
  };
}();
const OfflineSyncService = {
  init: function () {
    var _ref2 = asyncToGenerator_asyncToGenerator(function* () {
      utils_service.debugLog('Offline Sync Service Init');
      const extensionApi = ExtensionApiFactory();
      rootStore.subscribe( /*#__PURE__*/asyncToGenerator_asyncToGenerator(function* () {
        const appState = rootStore.getState();
        const offlineFields = yield extensionApi.getLocalStorage(OFFLINE_SYNC_FIELDS);
        utils_service.debugLog('offlineFields', offlineFields, 'appState', appState);
        yield updateOfflineSessionPings(offlineFields, appState);
      }));
    });
    return function init() {
      return _ref2.apply(this, arguments);
    };
  }(),
  getOfflineSyncFields: function () {
    var _ref4 = asyncToGenerator_asyncToGenerator(function* () {
      const extensionApi = ExtensionApiFactory();
      return extensionApi.getLocalStorage(OFFLINE_SYNC_FIELDS);
    });
    return function getOfflineSyncFields() {
      return _ref4.apply(this, arguments);
    };
  }()
};
/* harmony default export */ const offline_sync_servce = (OfflineSyncService);
;// CONCATENATED MODULE: ./node_modules/rxjs/dist/esm/internal/BehaviorSubject.js

class BehaviorSubject extends Subject {
  constructor(_value) {
    super();
    this._value = _value;
  }
  get value() {
    return this.getValue();
  }
  _subscribe(subscriber) {
    const subscription = super._subscribe(subscriber);
    !subscription.closed && subscriber.next(this._value);
    return subscription;
  }
  getValue() {
    const {
      hasError,
      thrownError,
      _value
    } = this;
    if (hasError) {
      throw thrownError;
    }
    this._throwIfClosed();
    return _value;
  }
  next(value) {
    super.next(this._value = value);
  }
}
//# sourceMappingURL=BehaviorSubject.js.map
;// CONCATENATED MODULE: ./node_modules/rxjs/dist/esm/internal/util/lift.js

function hasLift(source) {
  return isFunction(source === null || source === void 0 ? void 0 : source.lift);
}
function operate(init) {
  return source => {
    if (hasLift(source)) {
      return source.lift(function (liftedSource) {
        try {
          return init(liftedSource, this);
        } catch (err) {
          this.error(err);
        }
      });
    }
    throw new TypeError('Unable to lift unknown Observable type');
  };
}
//# sourceMappingURL=lift.js.map
;// CONCATENATED MODULE: ./node_modules/rxjs/dist/esm/internal/operators/OperatorSubscriber.js

function createOperatorSubscriber(destination, onNext, onComplete, onError, onFinalize) {
  return new OperatorSubscriber(destination, onNext, onComplete, onError, onFinalize);
}
class OperatorSubscriber extends Subscriber {
  constructor(destination, onNext, onComplete, onError, onFinalize, shouldUnsubscribe) {
    super(destination);
    this.onFinalize = onFinalize;
    this.shouldUnsubscribe = shouldUnsubscribe;
    this._next = onNext ? function (value) {
      try {
        onNext(value);
      } catch (err) {
        destination.error(err);
      }
    } : super._next;
    this._error = onError ? function (err) {
      try {
        onError(err);
      } catch (err) {
        destination.error(err);
      } finally {
        this.unsubscribe();
      }
    } : super._error;
    this._complete = onComplete ? function () {
      try {
        onComplete();
      } catch (err) {
        destination.error(err);
      } finally {
        this.unsubscribe();
      }
    } : super._complete;
  }
  unsubscribe() {
    var _a;
    if (!this.shouldUnsubscribe || this.shouldUnsubscribe()) {
      const {
        closed
      } = this;
      super.unsubscribe();
      !closed && ((_a = this.onFinalize) === null || _a === void 0 ? void 0 : _a.call(this));
    }
  }
}
//# sourceMappingURL=OperatorSubscriber.js.map
;// CONCATENATED MODULE: ./node_modules/rxjs/dist/esm/internal/operators/filter.js


function filter(predicate, thisArg) {
  return operate((source, subscriber) => {
    let index = 0;
    source.subscribe(createOperatorSubscriber(subscriber, value => predicate.call(thisArg, value, index++) && subscriber.next(value)));
  });
}
//# sourceMappingURL=filter.js.map
;// CONCATENATED MODULE: ./apps/gopher-for-chrome/gopher-buddy/src/background-service-worker/services/update-session/update-session.service.ts







const extensionIsReady$ = new BehaviorSubject(false);
const extensionIsOnline$ = new BehaviorSubject(false);
const sessionUpdateTrigger$ = timer(0, environment.defaultTimings.userSessionCheckinRateInSeconds * 1000).pipe(filter(() => extensionIsReady$.getValue() && extensionIsOnline$.getValue()));
const UpdateSessionService = {
  init: function () {
    var _ref = asyncToGenerator_asyncToGenerator(function* () {
      utils_service.debugLog('UpdateSessionService.init');
      rootStore.subscribe(() => {
        const state = rootStore.getState();
        if (state.checkInState.status === StateStatus.SUCCESS && state.checkInState.isCustomerValid) {
          extensionIsReady$.next(state.checkInState.isCustomerValid);
        }
        if (state.networkStatus.status === StateStatus.SUCCESS && state.networkStatus.networkStatus.isOnline) {
          extensionIsOnline$.next(state.networkStatus.networkStatus.isOnline);
        }
      });
      sessionUpdateTrigger$.subscribe( /*#__PURE__*/asyncToGenerator_asyncToGenerator(function* () {
        utils_service.debugLog('UpdateSessionService: Triggering Session Update');
        const state = rootStore.getState();
        if (state.updateSessionState.status === StateStatus.IDLE || state.updateSessionState.status === StateStatus.SUCCESS) {
          const sessions = getUpdateSessions(state);
          utils_service.debugLog('USER SESSIONS PINGS FOUND ', sessions);
          if (sessions.length > 0) {
            utils_service.debugLog('UpdateSessionService: Sending Session Pings');
            yield rootStore.dispatch(UpdateSessionEffects.sendSessionPings(sessions));
          }
        }
      }));
    });
    return function init() {
      return _ref.apply(this, arguments);
    };
  }()
};
/* harmony default export */ const update_session_service = (UpdateSessionService);
;// CONCATENATED MODULE: ./apps/gopher-for-chrome/gopher-buddy/src/background-service-worker/services/user-activity/user-activity.service.ts










let user_activity_service_extensionApi;
const userActivitySessionTrigger$ = timer(10 * 1000, environment.defaultTimings.userSessionCreateRateInSeconds * 1000);
const checkAndSendOfflinePings = /*#__PURE__*/function () {
  var _ref = asyncToGenerator_asyncToGenerator(function* (appState) {
    user_activity_service_extensionApi = ExtensionApiFactory();
    const offlineFields = yield user_activity_service_extensionApi.getLocalStorage(OFFLINE_SYNC_FIELDS);
    if (!Array.isArray(offlineFields?.offlineSessionPings) || offlineFields.offlineSessionPings.length === 0) {
      return;
    }
    for (const ping of offlineFields.offlineSessionPings) {
      const hydratedSessionPayload = {
        deviceId: ping.sessionPayload.deviceId ?? appState.deviceDetails.details.id,
        userId: ping.sessionPayload.userId ?? appState.userProfile.userProfile.email,
        customerId: ping.sessionPayload.customerId ?? appState.customerState.customerSettings?.customerId ?? 'unknown',
        domain: ping.sessionPayload.domain ?? appState.userProfile.userProfile.domain,
        deviceOrgUnitPath: ping.sessionPayload.deviceOrgUnitPath ?? appState.deviceDetails.deviceResource?.deviceOrgUnitPath ?? 'unknown',
        userOrgUnitPath: ping.sessionPayload.userOrgUnitPath ?? appState.userProfile.userProfile.userOrgUnitPath ?? 'unknown',
        publicIp: ping.sessionPayload.publicIp ?? appState.networkStatus.networkStatus.publicIp,
        privateIp: ping.sessionPayload.privateIp ?? appState.networkStatus.networkStatus.privateIp,
        crosVersion: ping.sessionPayload.crosVersion ?? appState.deviceDetails.details.OSVersion ?? 'unknown',
        extensionVersion: ping.sessionPayload.extensionVersion ?? user_activity_service_extensionApi.getManifest().version,
        timestamp: ping.sessionPayload.timestamp ?? new Date().toISOString()
      };
      rootStore.dispatch(addHydratedSessionPing({
        id: ping.id,
        sessionPayload: hydratedSessionPayload
      }));
    }
    yield user_activity_service_extensionApi.setLocalStorage({
      offlineSessionPings: []
    });
  });
  return function checkAndSendOfflinePings(_x) {
    return _ref.apply(this, arguments);
  };
}();
const UserActivityService = {
  init: () => {
    utils_service.debugLog('User Activity Service Init');
    user_activity_service_extensionApi = ExtensionApiFactory();
    user_activity_service_extensionApi.setIdleStateDetectionInterval(environment.defaultTimings.idleDetectionIntervalInSeconds);
    user_activity_service_extensionApi.addIdleStateChangeListener(idleState => {
      if (idleState === 'active') {
        rootStore.dispatch(setActive());
        return;
      }
      rootStore.dispatch(setInactive());
    });
    userActivitySessionTrigger$.subscribe( /*#__PURE__*/asyncToGenerator_asyncToGenerator(function* () {
      utils_service.debugLog('User Activity Service: Triggering Session Update');
      const state = rootStore.getState();
      if (state.userActivity.isActive && state.networkStatus.networkStatus.isOnline === true && state.checkInState.status === StateStatus.SUCCESS && state.checkInState.isCustomerValid) {
        yield checkAndSendOfflinePings(state);
        rootStore.dispatch(addSessionPing({
          deviceId: state.deviceDetails.details.id,
          userId: state.userProfile.userProfile.email,
          customerId: state.customerState.customerSettings?.customerId ?? 'unknown',
          domain: state.userProfile.userProfile.domain,
          deviceOrgUnitPath: state.deviceDetails.deviceResource?.deviceOrgUnitPath ?? 'unknown',
          userOrgUnitPath: state.userProfile.userProfile.userOrgUnitPath ?? 'unknown',
          publicIp: state.networkStatus.networkStatus.publicIp,
          privateIp: state.networkStatus.networkStatus.privateIp,
          crosVersion: state.deviceDetails.details.OSVersion ?? 'unknown',
          extensionVersion: user_activity_service_extensionApi.getManifest().version,
          timestamp: new Date().toISOString()
        }));
        return;
      }
      // Save the offline session pings
      if (state.userActivity.isActive && state.networkStatus.networkStatus.isOnline === false) {
        rootStore.dispatch(addOfflineSessionPing({
          deviceOrgUnitPath: state.deviceDetails?.deviceResource?.deviceOrgUnitPath,
          userOrgUnitPath: state.userProfile?.userProfile?.userOrgUnitPath,
          publicIp: state.networkStatus?.networkStatus?.publicIp,
          privateIp: state.networkStatus?.networkStatus?.privateIp,
          crosVersion: state.deviceDetails?.details?.OSVersion,
          extensionVersion: user_activity_service_extensionApi.getManifest().version,
          timestamp: new Date().toISOString()
        }));
      }
    }));
  }
};
/* harmony default export */ const user_activity_service = (UserActivityService);
;// CONCATENATED MODULE: ./apps/gopher-for-chrome/gopher-buddy/src/background-service-worker/services/user-profile/user-profile.service.ts





const {
  setEmail: user_profile_service_setEmail,
  setId: user_profile_service_setId,
  setDomain: user_profile_service_setDomain
} = UserProfileState.actions;
let user_profile_service_extensionApi;
const UserProfileService = {
  init: function () {
    var _ref = asyncToGenerator_asyncToGenerator(function* () {
      utils_service.debugLog('User Profile Service Init');
      user_profile_service_extensionApi = ExtensionApiFactory();
      return user_profile_service_extensionApi.getUserProfile({
        accountStatus: AccountStatus.SYNC
      }).then(userProfile => {
        if (userProfile.email) {
          rootStore.dispatch(user_profile_service_setDomain(userProfile.email.split('@')[1]));
        }
        rootStore.dispatch(user_profile_service_setEmail(userProfile.email));
        rootStore.dispatch(user_profile_service_setId(userProfile.id));
        utils_service.debugLog('User Profile:', {
          ...userProfile,
          domain: userProfile.email.split('@')[1]
        });
      });
    });
    return function init() {
      return _ref.apply(this, arguments);
    };
  }()
};
/* harmony default export */ const user_profile_service = (UserProfileService);
;// CONCATENATED MODULE: ./apps/gopher-for-chrome/gopher-buddy/src/background-service-worker/extension-serviceworker.ts





















// Initialize the Extension API. This will set this Globally.
console.log('Extension API Strategy:', environment.extensionApiStrategy);
setApiStrategy(environment.extensionApiStrategy);
if (environment.environment === RuntimeEnvironment.LOCAL) {
  setLocalOverrides(environment.localApiOverrides);
}
const extension_serviceworker_extensionApi = ExtensionApiFactory();
const appLoadedTrigger = timer(30 * 1000, 120 * 1000);
const ServiceWorkerInit = /*#__PURE__*/function () {
  var _ref = asyncToGenerator_asyncToGenerator(function* () {
    const manifestData = extension_serviceworker_extensionApi.getManifest();
    console.log('Gopher Buddy Service Worker');
    console.log('Environment:', environment.environment);
    console.log('Extension Version:', manifestData.version);
    rootStore.subscribe( /*#__PURE__*/asyncToGenerator_asyncToGenerator(function* () {
      const appState = rootStore.getState();
      utils_service.debugLog('State update');
      utils_service.debugLog(appState);
    }));
    yield alerts_service.init().then(user_profile_service.init).then(device_service.init).then(network_status_service.init).then(message_handler_service.init).then(device_service.setManagedStatus).catch(error => console.error('Error starting managed services', error));
    if (rootStore.getState().globalAppFlagsState.deviceManagedState === DeviceManagedState.MANAGED) {
      yield pubsub_service.init(environment.pubsubConfig).then(user_activity_service.init).then(licensing_service.init).then(customer_service.init).then(check_in_service.init).then(update_session_service.init).then(version_update_service.init).then(offline_sync_servce.init).catch(error => console.error('Error starting additional Services', error));
    }
    console.log('Extension Init Complete');
    rootStore.dispatch(setLoaded());
  });
  return function ServiceWorkerInit() {
    return _ref.apply(this, arguments);
  };
}();
// Run specific actions when the extension is installed, upodated, or chrome browser/OS  has been updated
extension_serviceworker_extensionApi.onInstalled( /*#__PURE__*/asyncToGenerator_asyncToGenerator(function* () {
  yield ServiceWorkerInit();
}));
// Run specific actions when the Browser/OS is started
extension_serviceworker_extensionApi.onStartup( /*#__PURE__*/asyncToGenerator_asyncToGenerator(function* () {
  yield ServiceWorkerInit();
}));
// Sometimes there is a state where onStartup and onInstalled is not triggered
// This is a fallback to ensure the extension is loaded
appLoadedTrigger.subscribe( /*#__PURE__*/asyncToGenerator_asyncToGenerator(function* () {
  const appState = rootStore.getState();
  if (appState.globalAppFlagsState.isLoaded) {
    utils_service.debugLog('App Already Loaded');
    return;
  }
  yield ServiceWorkerInit();
}));
/******/ })()
;