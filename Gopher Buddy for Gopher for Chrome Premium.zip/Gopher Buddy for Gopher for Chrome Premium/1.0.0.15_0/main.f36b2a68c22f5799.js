/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 1308:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {


// EXTERNAL MODULE: ./node_modules/@angular/platform-browser/fesm2020/platform-browser.mjs
var platform_browser = __webpack_require__(1481);
// EXTERNAL MODULE: ./node_modules/@angular/platform-browser/fesm2020/animations.mjs + 1 modules
var animations = __webpack_require__(1516);
// EXTERNAL MODULE: ./node_modules/@angular/router/fesm2020/router.mjs + 10 modules
var router = __webpack_require__(2965);
// EXTERNAL MODULE: ./node_modules/@ngrx/effects/fesm2020/ngrx-effects.mjs + 6 modules
var ngrx_effects = __webpack_require__(2655);
// EXTERNAL MODULE: ./node_modules/@ngrx/router-store/fesm2020/ngrx-router-store.mjs
var ngrx_router_store = __webpack_require__(6943);
// EXTERNAL MODULE: ./node_modules/@ngrx/store/fesm2020/ngrx-store.mjs + 4 modules
var ngrx_store = __webpack_require__(6814);
// EXTERNAL MODULE: ./node_modules/rxjs/dist/esm/internal/observable/timer.js
var timer = __webpack_require__(2805);
;// CONCATENATED MODULE: ./apps/gopher-for-chrome/gopher-buddy/src/app/+state/app.actions.ts

const initApp = (0,ngrx_store/* createAction */.PH)('[App Page] Init');
const syncAppState = (0,ngrx_store/* createAction */.PH)('[App Page] SyncAppState');
const loadAppSuccess = (0,ngrx_store/* createAction */.PH)('[App/API] Load App Success', (0,ngrx_store/* props */.Ky)());
const loadAppFailure = (0,ngrx_store/* createAction */.PH)('[App/API] Load App Failure', (0,ngrx_store/* props */.Ky)());
const toggleHelp = (0,ngrx_store/* createAction */.PH)('[App Help] Toggle Help', (0,ngrx_store/* props */.Ky)());
// EXTERNAL MODULE: ./node_modules/@angular/core/fesm2020/core.mjs
var core = __webpack_require__(4650);
// EXTERNAL MODULE: ./node_modules/rxjs/dist/esm/internal/operators/switchMap.js
var switchMap = __webpack_require__(3900);
// EXTERNAL MODULE: ./node_modules/rxjs/dist/esm/internal/observable/of.js
var of = __webpack_require__(9646);
// EXTERNAL MODULE: ./node_modules/rxjs/dist/esm/internal/operators/catchError.js
var catchError = __webpack_require__(262);
;// CONCATENATED MODULE: ./apps/gopher-for-chrome/gopher-buddy/src/background-service-worker/services/message-handler/message-handler.interfaces.ts
var GBMessages = /*#__PURE__*/(() => {
  (function (GBMessages) {
    GBMessages["GET_EXTENSION_STATE"] = "getExtensionState";
    GBMessages["CLEAR_CACHE"] = "clearCache";
    GBMessages["RELOAD_EXTENSION"] = "reloadExtension";
    GBMessages["RESYNC_EXTENSION"] = "resyncExtension";
    GBMessages["OPEN_HELP"] = "openChromeHelp";
    GBMessages["OPEN_DEVICE_INFO"] = "openDeviceInfo";
    GBMessages["CHECK_VERSION"] = "checkVersion";
    GBMessages["FIX_VERSION"] = "fixVersion";
    GBMessages["OPEN_FAQ"] = "openFAQ";
  })(GBMessages || (GBMessages = {}));
  return GBMessages;
})();
;// CONCATENATED MODULE: ./apps/gopher-for-chrome/gopher-buddy/src/app/+state/services/app-state.service.ts


let AppStateService = /*#__PURE__*/(() => {
  class AppStateService {
    constructor() {
      this.loadState = () => chrome.runtime.sendMessage(GBMessages.GET_EXTENSION_STATE);
    }
    static #_ = this.ɵfac = function AppStateService_Factory(t) {
      return new (t || AppStateService)();
    };
    static #_2 = this.ɵprov = /*@__PURE__*/core/* ɵɵdefineInjectable */.Yz7({
      token: AppStateService,
      factory: AppStateService.ɵfac,
      providedIn: 'root'
    });
  }
  return AppStateService;
})();
;// CONCATENATED MODULE: ./apps/gopher-for-chrome/gopher-buddy/src/app/+state/app.effects.ts







let AppEffects = /*#__PURE__*/(() => {
  class AppEffects {
    constructor(actions$) {
      this.actions$ = actions$;
      this.appStateService = (0,core/* inject */.f3M)(AppStateService);
      this.init$ = (0,ngrx_effects/* createEffect */.GW)(() => this.actions$.pipe((0,ngrx_effects/* ofType */.l4)(ngrx_effects/* ROOT_EFFECTS_INIT */.jK), (0,switchMap/* switchMap */.w)(() => this.appStateService.loadState()), (0,switchMap/* switchMap */.w)(appState => (0,of.of)(loadAppSuccess({
        app: {
          settings: appState
        }
      }))), (0,catchError/* catchError */.K)(error => (0,of.of)(loadAppFailure({
        error: error
      })))));
      this.sync$ = (0,ngrx_effects/* createEffect */.GW)(() => this.actions$.pipe((0,ngrx_effects/* ofType */.l4)(syncAppState), (0,switchMap/* switchMap */.w)(() => this.appStateService.loadState()), (0,switchMap/* switchMap */.w)(appState => (0,of.of)(loadAppSuccess({
        app: {
          settings: appState
        }
      }))), (0,catchError/* catchError */.K)(error => (0,of.of)(loadAppFailure({
        error: error
      })))));
    }
    static #_ = this.ɵfac = function AppEffects_Factory(t) {
      return new (t || AppEffects)(core/* ɵɵinject */.LFG(ngrx_effects/* Actions */.eX));
    };
    static #_2 = this.ɵprov = /*@__PURE__*/core/* ɵɵdefineInjectable */.Yz7({
      token: AppEffects,
      factory: AppEffects.ɵfac
    });
  }
  return AppEffects;
})();
;// CONCATENATED MODULE: ./apps/gopher-for-chrome/gopher-buddy/src/app/+state/app.reducer.ts


const APP_FEATURE_KEY = 'app';
const initialAppState = {
  loaded: false,
  helpOpen: false
};
const reducer = (0,ngrx_store/* createReducer */.Lq)(initialAppState, (0,ngrx_store.on)(initApp, state => ({
  ...state,
  loaded: false,
  error: null
})), (0,ngrx_store.on)(loadAppSuccess, (state, {
  app
}) => ({
  ...app,
  loaded: true,
  helpOpen: state.helpOpen
})), (0,ngrx_store.on)(loadAppFailure, (state, {
  error
}) => ({
  ...state,
  error
})), (0,ngrx_store.on)(toggleHelp, (state, {
  open
}) => ({
  ...state,
  helpOpen: open
})));
function appReducer(state, action) {
  return reducer(state, action);
}
;// CONCATENATED MODULE: ./apps/gopher-for-chrome/gopher-buddy/src/app/app.component.ts


let AppComponent = /*#__PURE__*/(() => {
  class AppComponent {
    constructor() {
      this.title = 'gopher-buddy-extension';
    }
    static #_ = this.ɵfac = function AppComponent_Factory(t) {
      return new (t || AppComponent)();
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/core/* ɵɵdefineComponent */.Xpm({
      type: AppComponent,
      selectors: [["app-root"]],
      decls: 1,
      vars: 0,
      template: function AppComponent_Template(rf, ctx) {
        if (rf & 1) {
          core/* ɵɵelement */._UZ(0, "router-outlet");
        }
      },
      dependencies: [router/* RouterOutlet */.lC]
    });
  }
  return AppComponent;
})();
// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js
var asyncToGenerator = __webpack_require__(5861);
;// CONCATENATED MODULE: ./apps/gopher-for-chrome/gopher-buddy/src/app/+state/app.selectors.ts


// Lookup the 'App' feature state managed by NgRx
const selectAppState = (0,ngrx_store/* createFeatureSelector */.ZF)(APP_FEATURE_KEY);
const isAppLoaded = (0,ngrx_store/* createSelector */.P1)(selectAppState, state => state.loaded);
const getAppError = (0,ngrx_store/* createSelector */.P1)(selectAppState, state => state.error);
const getAppSettings = (0,ngrx_store/* createSelector */.P1)(selectAppState, state => state.settings);
const getHelpState = (0,ngrx_store/* createSelector */.P1)(selectAppState, state => state.helpOpen);
;// CONCATENATED MODULE: ./apps/gopher-for-chrome/gopher-buddy/src/background-service-worker/services/extension-store/interfaces/extension-store.interfaces.ts
var StateStatus = /*#__PURE__*/(() => {
  (function (StateStatus) {
    StateStatus["IDLE"] = "idle";
    StateStatus["LOADING"] = "loading";
    StateStatus["SUCCESS"] = "success";
    StateStatus["FAILED"] = "failed";
  })(StateStatus || (StateStatus = {}));
  return StateStatus;
})();
var DeviceManagedState = /*#__PURE__*/(() => {
  (function (DeviceManagedState) {
    DeviceManagedState["MANAGED"] = "managed";
    DeviceManagedState["NOT_MANAGED"] = "notManaged";
  })(DeviceManagedState || (DeviceManagedState = {}));
  return DeviceManagedState;
})();
// EXTERNAL MODULE: ./node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs
var redux_toolkit_modern = __webpack_require__(6158);
;// CONCATENATED MODULE: ./apps/gopher-for-chrome/gopher-buddy/src/background-service-worker/services/user-profile/user-profile.state.ts


var UserAccessType = /*#__PURE__*/(() => {
  (function (UserAccessType) {
    UserAccessType["NONE"] = "none";
    UserAccessType["BASIC"] = "basic";
    UserAccessType["FULL"] = "full";
  })(UserAccessType || (UserAccessType = {}));
  return UserAccessType;
})();
const initialState = {
  error: null,
  status: StateStatus.IDLE,
  userProfile: {
    email: '',
    id: '',
    domain: '',
    accessLevel: UserAccessType.NONE
  }
};
const UserProfileEffects = {
  fetchUserProfile: () => {
    console.log('fetchUserProfile');
  }
};
const UserProfileState = (0,redux_toolkit_modern/* createSlice */.oM)({
  name: 'UserProfileReducer',
  initialState,
  reducers: {
    setProfileDetails: (mutableState, action) => {
      mutableState.userProfile.accessLevel = action.payload.accessLevel;
      mutableState.userProfile.userOrgUnitPath = action.payload.userOrgUnitPath;
      mutableState.userProfile.userJWT = action.payload.userJWT;
      mutableState.status = StateStatus.SUCCESS;
    },
    setEmail: (mutableState, action) => {
      mutableState.userProfile.email = action.payload;
    },
    setId: (mutableState, action) => {
      mutableState.userProfile.id = action.payload;
    },
    setDomain: (mutableState, action) => {
      mutableState.userProfile.domain = action.payload;
    },
    setUserAccessLevel: (mutableState, action) => {
      mutableState.userProfile.accessLevel = action.payload;
    },
    setUserJWT: (mutableState, action) => {
      mutableState.userProfile.userJWT = action.payload;
    }
  }
});
const {
  setEmail,
  setId,
  setDomain,
  setUserAccessLevel,
  setUserJWT,
  setProfileDetails
} = UserProfileState.actions;
const getUserProfile = state => state.userProfile;
;// CONCATENATED MODULE: ./apps/gopher-for-chrome/gopher-buddy/src/app/common/services/ui.service.ts

let UiService = /*#__PURE__*/(() => {
  class UiService {
    constructor() {
      this.showNotification = (id, message, title = 'Gopher Buddy') => {
        chrome.notifications.clear(id, () => {});
        chrome.notifications.create(id, {
          message,
          title,
          type: 'basic',
          iconUrl: 'assets/images/gb_default_icon.png'
        }, () => {});
      };
    }
    static #_ = this.ɵfac = function UiService_Factory(t) {
      return new (t || UiService)();
    };
    static #_2 = this.ɵprov = /*@__PURE__*/core/* ɵɵdefineInjectable */.Yz7({
      token: UiService,
      factory: UiService.ɵfac,
      providedIn: 'root'
    });
  }
  return UiService;
})();
// EXTERNAL MODULE: ./node_modules/@angular/common/fesm2020/common.mjs
var common = __webpack_require__(6895);
// EXTERNAL MODULE: ./node_modules/@angular/material/fesm2020/button.mjs
var fesm2020_button = __webpack_require__(4859);
// EXTERNAL MODULE: ./node_modules/@angular/material/fesm2020/icon.mjs + 2 modules
var icon = __webpack_require__(4218);
// EXTERNAL MODULE: ./node_modules/@angular/material/fesm2020/sidenav.mjs
var sidenav = __webpack_require__(3267);
// EXTERNAL MODULE: ./node_modules/@angular/material/fesm2020/tabs.mjs
var tabs = __webpack_require__(3848);
// EXTERNAL MODULE: ./node_modules/@angular/cdk/fesm2020/clipboard.mjs
var clipboard = __webpack_require__(4425);
// EXTERNAL MODULE: ./node_modules/@angular/material/fesm2020/snack-bar.mjs
var snack_bar = __webpack_require__(7009);
// EXTERNAL MODULE: ./node_modules/@angular/material/fesm2020/tooltip.mjs
var tooltip = __webpack_require__(266);
;// CONCATENATED MODULE: ./apps/gopher-for-chrome/gopher-buddy/src/app/common/material/material.module.ts/material/material.module.ts









let MaterialModule = /*#__PURE__*/(() => {
  class MaterialModule {
    static #_ = this.ɵfac = function MaterialModule_Factory(t) {
      return new (t || MaterialModule)();
    };
    static #_2 = this.ɵmod = /*@__PURE__*/core/* ɵɵdefineNgModule */.oAB({
      type: MaterialModule
    });
    static #_3 = this.ɵinj = /*@__PURE__*/core/* ɵɵdefineInjector */.cJS({
      imports: [common/* CommonModule */.ez, fesm2020_button/* MatButtonModule */.ot, snack_bar/* MatSnackBarModule */.ZX, icon/* MatIconModule */.Ps, tooltip/* MatTooltipModule */.AV, sidenav/* MatSidenavModule */.SJ, tabs/* MatTabsModule */.Nh, clipboard/* ClipboardModule */.Iq, fesm2020_button/* MatButtonModule */.ot, snack_bar/* MatSnackBarModule */.ZX, icon/* MatIconModule */.Ps, tooltip/* MatTooltipModule */.AV, sidenav/* MatSidenavModule */.SJ, tabs/* MatTabsModule */.Nh, clipboard/* ClipboardModule */.Iq]
    });
  }
  return MaterialModule;
})();
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && core/* ɵɵsetNgModuleScope */.kYT(MaterialModule, {
    imports: [common/* CommonModule */.ez, fesm2020_button/* MatButtonModule */.ot, snack_bar/* MatSnackBarModule */.ZX, icon/* MatIconModule */.Ps, tooltip/* MatTooltipModule */.AV, sidenav/* MatSidenavModule */.SJ, tabs/* MatTabsModule */.Nh, clipboard/* ClipboardModule */.Iq],
    exports: [fesm2020_button/* MatButtonModule */.ot, snack_bar/* MatSnackBarModule */.ZX, icon/* MatIconModule */.Ps, tooltip/* MatTooltipModule */.AV, sidenav/* MatSidenavModule */.SJ, tabs/* MatTabsModule */.Nh, clipboard/* ClipboardModule */.Iq]
  });
})();
;// CONCATENATED MODULE: ./apps/gopher-for-chrome/gopher-buddy/src/app/common/components/gb-footer/gb-footer.component.ts













function GbFooterComponent_div_0_button_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = core/* ɵɵgetCurrentView */.EpF();
    core/* ɵɵelementStart */.TgZ(0, "button", 7);
    core/* ɵɵlistener */.NdJ("click", function GbFooterComponent_div_0_button_5_Template_button_click_0_listener() {
      core/* ɵɵrestoreView */.CHM(_r4);
      const ctx_r3 = core/* ɵɵnextContext */.oxw(2);
      return core/* ɵɵresetView */.KtG(ctx_r3.recheckBrowserVersion());
    });
    core/* ɵɵelementStart */.TgZ(1, "mat-icon", 3);
    core/* ɵɵtext */._uU(2, "browser_updated");
    core/* ɵɵelementEnd */.qZA()();
  }
}
function GbFooterComponent_div_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r6 = core/* ɵɵgetCurrentView */.EpF();
    core/* ɵɵelementStart */.TgZ(0, "div", 1)(1, "button", 2);
    core/* ɵɵlistener */.NdJ("click", function GbFooterComponent_div_0_Template_button_click_1_listener() {
      core/* ɵɵrestoreView */.CHM(_r6);
      const ctx_r5 = core/* ɵɵnextContext */.oxw();
      return core/* ɵɵresetView */.KtG(ctx_r5.openFAQ());
    });
    core/* ɵɵelementStart */.TgZ(2, "mat-icon", 3);
    core/* ɵɵtext */._uU(3, "help");
    core/* ɵɵelementEnd */.qZA()();
    core/* ɵɵelement */._UZ(4, "span", 4);
    core/* ɵɵtemplate */.YNc(5, GbFooterComponent_div_0_button_5_Template, 3, 0, "button", 5);
    core/* ɵɵelementStart */.TgZ(6, "button", 6);
    core/* ɵɵlistener */.NdJ("click", function GbFooterComponent_div_0_Template_button_click_6_listener() {
      core/* ɵɵrestoreView */.CHM(_r6);
      const ctx_r7 = core/* ɵɵnextContext */.oxw();
      return core/* ɵɵresetView */.KtG(ctx_r7.reloadExtension());
    });
    core/* ɵɵelementStart */.TgZ(7, "mat-icon", 3);
    core/* ɵɵtext */._uU(8, "restart_alt");
    core/* ɵɵelementEnd */.qZA()()();
  }
  if (rf & 2) {
    const appState_r1 = ctx.ngIf;
    const ctx_r0 = core/* ɵɵnextContext */.oxw();
    core/* ɵɵadvance */.xp6(5);
    core/* ɵɵproperty */.Q6J("ngIf", ctx_r0.checkVersionEnabled(appState_r1));
  }
}
let GbFooterComponent = /*#__PURE__*/(() => {
  class GbFooterComponent {
    constructor(uiService, appStore) {
      this.uiService = uiService;
      this.appStore = appStore;
      this.appState = this.appStore;
      this.appSyncing = false;
      this.checkVersionEnabled = appState => appState.app.settings?.customerState.customerSettings?.settings.allowChromeOsUpdateReminders ?? false;
      this.recheckBrowserVersion = () => {
        this.appSyncing = true;
        chrome.runtime.sendMessage(GBMessages.CHECK_VERSION, response => {
          this.appSyncing = false;
          const message = response.success ? 'Version check successful' : 'Version check failed';
          this.uiService.showNotification('version_check', message);
        });
      };
      this.resyncExtension = () => {
        this.appSyncing = true;
        chrome.runtime.sendMessage(GBMessages.RESYNC_EXTENSION, response => {
          this.appSyncing = false;
          const message = response.success ? 'Resync successful' : 'Resync failed';
          this.uiService.showNotification('resync', message);
        });
      };
      this.reloadExtension = () => {
        chrome.runtime.sendMessage(GBMessages.RELOAD_EXTENSION, () => {});
      };
      this.showHelp = appState => {
        this.appStore.dispatch(toggleHelp({
          open: !appState.app.helpOpen
        }));
      };
      this.openFAQ = () => {
        chrome.runtime.sendMessage(GBMessages.OPEN_FAQ, () => {});
      };
    }
    static #_ = this.ɵfac = function GbFooterComponent_Factory(t) {
      return new (t || GbFooterComponent)(core/* ɵɵdirectiveInject */.Y36(UiService), core/* ɵɵdirectiveInject */.Y36(ngrx_store/* Store */.yh));
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/core/* ɵɵdefineComponent */.Xpm({
      type: GbFooterComponent,
      selectors: [["app-gb-footer"]],
      standalone: true,
      features: [core/* ɵɵStandaloneFeature */.jDz],
      decls: 2,
      vars: 3,
      consts: [["class", "flex justify-between items-center footer-bg", 4, "ngIf"], [1, "flex", "justify-between", "items-center", "footer-bg"], ["matTooltip", "Get help", "mat-icon-button", "", 3, "click"], [1, "text-white"], [1, "grow"], ["matTooltip", "Recheck browser version", "mat-icon-button", "", 3, "click", 4, "ngIf"], ["matTooltip", "Reload extension", "mat-icon-button", "", 3, "click"], ["matTooltip", "Recheck browser version", "mat-icon-button", "", 3, "click"]],
      template: function GbFooterComponent_Template(rf, ctx) {
        if (rf & 1) {
          core/* ɵɵtemplate */.YNc(0, GbFooterComponent_div_0_Template, 9, 1, "div", 0);
          core/* ɵɵpipe */.ALo(1, "async");
        }
        if (rf & 2) {
          core/* ɵɵproperty */.Q6J("ngIf", core/* ɵɵpipeBind1 */.lcZ(1, 1, ctx.appState));
        }
      },
      dependencies: [common/* CommonModule */.ez, common/* NgIf */.O5, common/* AsyncPipe */.Ov, MaterialModule, fesm2020_button/* MatIconButton */.RK, icon/* MatIcon */.Hw, tooltip/* MatTooltip */.gM],
      styles: [".footer-bg[_ngcontent-%COMP%] {\n  background-color: #a6192e;\n}"]
    });
  }
  return GbFooterComponent;
})();
;// CONCATENATED MODULE: ./apps/gopher-for-chrome/gopher-buddy/src/app/common/components/help/help.component.ts








let HelpComponent = /*#__PURE__*/(() => {
  class HelpComponent {
    constructor(appStore) {
      this.appStore = appStore;
      this.openFAQ = () => {
        chrome.runtime.sendMessage(GBMessages.OPEN_FAQ, () => {});
      };
    }
    static #_ = this.ɵfac = function HelpComponent_Factory(t) {
      return new (t || HelpComponent)(core/* ɵɵdirectiveInject */.Y36(ngrx_store/* Store */.yh));
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/core/* ɵɵdefineComponent */.Xpm({
      type: HelpComponent,
      selectors: [["app-gb-help"]],
      standalone: true,
      features: [core/* ɵɵProvidersFeature */._Bn([UiService]), core/* ɵɵStandaloneFeature */.jDz],
      decls: 92,
      vars: 0,
      consts: [[1, "app-bg"], [1, "flex", "flex-col", "justify-center", "items-center", "gap-y-2"], [1, "flex", "flex-col", "h-[250px]", "overflow-y-auto", "gap-y-2"], [1, "flex", "flex-col"], [1, "text-base", "font-bold"], [1, "flex", "flex-col", "mt-2"], [1, "flex", "flex-row", "items-center", "gap-x-2"], ["src", "assets/images/help/show-help.png", "alt", "show help icon", 1, "h-[30px]"], [1, "font-bold"], ["src", "assets/images/help/recheck-version.png", "alt", "recheck version icon", 1, "h-[30px]"], ["src", "assets/images/help/reload-extension.png", "alt", "reload extension icon", 1, "h-[30px]"], ["src", "assets/images/help/chrome-update.png", "alt", "chrome update icon", 1, "h-[30px]"], ["src", "assets/images/help/quick-device-info.png", "alt", "quick device info icon", 1, "h-[30px]"], ["src", "assets/images/help/clear-cache.png", "alt", "clear cache button", 1, "h-[30px]"], ["src", "assets/images/help/device-info.png", "alt", "device info button", 1, "h-[30px]"], ["src", "assets/images/help/fix-it.png", "alt", "Fix-it button", 1, "h-[30px]"], ["mat-raised-button", "", "color", "primary", 3, "click"]],
      template: function HelpComponent_Template(rf, ctx) {
        if (rf & 1) {
          core/* ɵɵelementStart */.TgZ(0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "div");
          core/* ɵɵtext */._uU(4, "Gopher Buddy is a tool to help your school keep up-to-date with all of their Chromebooks.");
          core/* ɵɵelementEnd */.qZA();
          core/* ɵɵelementStart */.TgZ(5, "div", 3)(6, "div");
          core/* ɵɵtext */._uU(7, "It ");
          core/* ɵɵelementStart */.TgZ(8, "strong");
          core/* ɵɵtext */._uU(9, "does");
          core/* ɵɵelementEnd */.qZA();
          core/* ɵɵtext */._uU(10, " let your school:");
          core/* ɵɵelementEnd */.qZA();
          core/* ɵɵelementStart */.TgZ(11, "div");
          core/* ɵɵtext */._uU(12, "\u2022 know who is using the Chromebook");
          core/* ɵɵelementEnd */.qZA();
          core/* ɵɵelementStart */.TgZ(13, "div");
          core/* ɵɵtext */._uU(14, "\u2022 know when the Chromebook is used");
          core/* ɵɵelementEnd */.qZA();
          core/* ɵɵelementStart */.TgZ(15, "div");
          core/* ɵɵtext */._uU(16, "\u2022 notify you if the Chromebook needs updating");
          core/* ɵɵelementEnd */.qZA()();
          core/* ɵɵelementStart */.TgZ(17, "div", 3)(18, "div");
          core/* ɵɵtext */._uU(19, "It does ");
          core/* ɵɵelementStart */.TgZ(20, "strong");
          core/* ɵɵtext */._uU(21, "NOT");
          core/* ɵɵelementEnd */.qZA();
          core/* ɵɵtext */._uU(22, " record:");
          core/* ɵɵelementEnd */.qZA();
          core/* ɵɵelementStart */.TgZ(23, "div");
          core/* ɵɵtext */._uU(24, "\u2022 what you type");
          core/* ɵɵelementEnd */.qZA();
          core/* ɵɵelementStart */.TgZ(25, "div");
          core/* ɵɵtext */._uU(26, "\u2022 websites you visit");
          core/* ɵɵelementEnd */.qZA();
          core/* ɵɵelementStart */.TgZ(27, "div");
          core/* ɵɵtext */._uU(28, "\u2022 images, video or audio");
          core/* ɵɵelementEnd */.qZA();
          core/* ɵɵelementStart */.TgZ(29, "div");
          core/* ɵɵtext */._uU(30, "\u2022 the files on your chromebook");
          core/* ɵɵelementEnd */.qZA()();
          core/* ɵɵelementStart */.TgZ(31, "div", 3)(32, "div", 4);
          core/* ɵɵtext */._uU(33, "What do all the buttons do?");
          core/* ɵɵelementEnd */.qZA();
          core/* ɵɵelementStart */.TgZ(34, "div", 5)(35, "div", 6);
          core/* ɵɵelement */._UZ(36, "img", 7);
          core/* ɵɵelementStart */.TgZ(37, "div", 8);
          core/* ɵɵtext */._uU(38, "Show help");
          core/* ɵɵelementEnd */.qZA()();
          core/* ɵɵelementStart */.TgZ(39, "div");
          core/* ɵɵtext */._uU(40, "Opens and closes this help page.");
          core/* ɵɵelementEnd */.qZA()();
          core/* ɵɵelementStart */.TgZ(41, "div", 5)(42, "div", 6);
          core/* ɵɵelement */._UZ(43, "img", 9);
          core/* ɵɵelementStart */.TgZ(44, "div", 8);
          core/* ɵɵtext */._uU(45, "Recheck Chrome verions");
          core/* ɵɵelementEnd */.qZA()();
          core/* ɵɵelementStart */.TgZ(46, "div");
          core/* ɵɵtext */._uU(47, "Forces Gopher Buddy to recheck your version of Chrome.");
          core/* ɵɵelementEnd */.qZA()();
          core/* ɵɵelementStart */.TgZ(48, "div", 5)(49, "div", 6);
          core/* ɵɵelement */._UZ(50, "img", 10);
          core/* ɵɵelementStart */.TgZ(51, "div", 8);
          core/* ɵɵtext */._uU(52, "Reload Gopher Buddy");
          core/* ɵɵelementEnd */.qZA()();
          core/* ɵɵelementStart */.TgZ(53, "div");
          core/* ɵɵtext */._uU(54, "Reloads the Gopher Buddy Extension. Use this if the extension is acting odd.");
          core/* ɵɵelementEnd */.qZA()();
          core/* ɵɵelementStart */.TgZ(55, "div", 5)(56, "div", 6);
          core/* ɵɵelement */._UZ(57, "img", 11);
          core/* ɵɵelementStart */.TgZ(58, "div", 8);
          core/* ɵɵtext */._uU(59, "Chrome update info");
          core/* ɵɵelementEnd */.qZA()();
          core/* ɵɵelementStart */.TgZ(60, "div");
          core/* ɵɵtext */._uU(61, "Shows info about the current version of Chrome.");
          core/* ɵɵelementEnd */.qZA()();
          core/* ɵɵelementStart */.TgZ(62, "div", 5)(63, "div", 6);
          core/* ɵɵelement */._UZ(64, "img", 12);
          core/* ɵɵelementStart */.TgZ(65, "div", 8);
          core/* ɵɵtext */._uU(66, "Quick device info");
          core/* ɵɵelementEnd */.qZA()();
          core/* ɵɵelementStart */.TgZ(67, "div");
          core/* ɵɵtext */._uU(68, "Shows a short list of info about this Chromebook");
          core/* ɵɵelementEnd */.qZA()();
          core/* ɵɵelementStart */.TgZ(69, "div", 5)(70, "div", 6);
          core/* ɵɵelement */._UZ(71, "img", 13);
          core/* ɵɵelementStart */.TgZ(72, "div", 8);
          core/* ɵɵtext */._uU(73, "Clear cache");
          core/* ɵɵelementEnd */.qZA()();
          core/* ɵɵelementStart */.TgZ(74, "div");
          core/* ɵɵtext */._uU(75, "Clears the Chromebook's cache. Useful if a website is missbehaving.");
          core/* ɵɵelementEnd */.qZA()();
          core/* ɵɵelementStart */.TgZ(76, "div", 5)(77, "div", 6);
          core/* ɵɵelement */._UZ(78, "img", 14);
          core/* ɵɵelementStart */.TgZ(79, "div", 8);
          core/* ɵɵtext */._uU(80, "Device info");
          core/* ɵɵelementEnd */.qZA()();
          core/* ɵɵelementStart */.TgZ(81, "div");
          core/* ɵɵtext */._uU(82, " Takes you to a Gopher Buddy webapp to see addition information about this Chromebook. This button may be turned off by your school. ");
          core/* ɵɵelementEnd */.qZA()();
          core/* ɵɵelementStart */.TgZ(83, "div", 5)(84, "div", 6);
          core/* ɵɵelement */._UZ(85, "img", 15);
          core/* ɵɵelementStart */.TgZ(86, "div", 8);
          core/* ɵɵtext */._uU(87, "Fix it");
          core/* ɵɵelementEnd */.qZA()();
          core/* ɵɵelementStart */.TgZ(88, "div");
          core/* ɵɵtext */._uU(89, "Opens the settings page in Chrome. Chrome update settings are on this page.");
          core/* ɵɵelementEnd */.qZA()()()();
          core/* ɵɵelementStart */.TgZ(90, "button", 16);
          core/* ɵɵlistener */.NdJ("click", function HelpComponent_Template_button_click_90_listener() {
            return ctx.openFAQ();
          });
          core/* ɵɵtext */._uU(91, "Read the faq");
          core/* ɵɵelementEnd */.qZA()()();
        }
      },
      dependencies: [common/* CommonModule */.ez, MaterialModule, fesm2020_button/* MatButton */.lW],
      styles: [".app-bg[_ngcontent-%COMP%] {\n  background-color: #f8fafe;\n}"]
    });
  }
  return HelpComponent;
})();
;// CONCATENATED MODULE: ./apps/gopher-for-chrome/gopher-buddy/src/app/common/components/device-info/device-info.component.ts










function DeviceInfoComponent_div_0_Template(rf, ctx) {
  if (rf & 1) {
    core/* ɵɵelementStart */.TgZ(0, "div", 1)(1, "div", 2)(2, "div", 3)(3, "div", 4)(4, "div");
    core/* ɵɵtext */._uU(5, "Model:");
    core/* ɵɵelementEnd */.qZA();
    core/* ɵɵelementStart */.TgZ(6, "div", 5);
    core/* ɵɵtext */._uU(7);
    core/* ɵɵelementEnd */.qZA()();
    core/* ɵɵelementStart */.TgZ(8, "button", 6)(9, "mat-icon", 7);
    core/* ɵɵtext */._uU(10, "content_copy");
    core/* ɵɵelementEnd */.qZA()()();
    core/* ɵɵelementStart */.TgZ(11, "div", 3)(12, "div", 4)(13, "div");
    core/* ɵɵtext */._uU(14, "Serial number:");
    core/* ɵɵelementEnd */.qZA();
    core/* ɵɵelementStart */.TgZ(15, "div", 5);
    core/* ɵɵtext */._uU(16);
    core/* ɵɵelementEnd */.qZA()();
    core/* ɵɵelementStart */.TgZ(17, "button", 6)(18, "mat-icon", 7);
    core/* ɵɵtext */._uU(19, "content_copy");
    core/* ɵɵelementEnd */.qZA()()();
    core/* ɵɵelementStart */.TgZ(20, "div", 3)(21, "div", 4)(22, "div");
    core/* ɵɵtext */._uU(23, "Chrome version:");
    core/* ɵɵelementEnd */.qZA();
    core/* ɵɵelementStart */.TgZ(24, "div", 5);
    core/* ɵɵtext */._uU(25);
    core/* ɵɵelementEnd */.qZA()();
    core/* ɵɵelementStart */.TgZ(26, "button", 6)(27, "mat-icon", 7);
    core/* ɵɵtext */._uU(28, "content_copy");
    core/* ɵɵelementEnd */.qZA()()();
    core/* ɵɵelementStart */.TgZ(29, "div", 3)(30, "div", 4)(31, "div");
    core/* ɵɵtext */._uU(32, "Id:");
    core/* ɵɵelementEnd */.qZA();
    core/* ɵɵelementStart */.TgZ(33, "div", 5);
    core/* ɵɵtext */._uU(34);
    core/* ɵɵelementEnd */.qZA()();
    core/* ɵɵelementStart */.TgZ(35, "button", 6)(36, "mat-icon", 7);
    core/* ɵɵtext */._uU(37, "content_copy");
    core/* ɵɵelementEnd */.qZA()()()()();
  }
  if (rf & 2) {
    const appStateData_r1 = ctx.ngIf;
    let tmp_0_0;
    let tmp_2_0;
    let tmp_3_0;
    let tmp_5_0;
    let tmp_6_0;
    let tmp_8_0;
    let tmp_9_0;
    let tmp_11_0;
    core/* ɵɵadvance */.xp6(6);
    core/* ɵɵproperty */.Q6J("matTooltip", (tmp_0_0 = appStateData_r1.app.settings == null ? null : appStateData_r1.app.settings.deviceDetails == null ? null : appStateData_r1.app.settings.deviceDetails.deviceResource == null ? null : appStateData_r1.app.settings.deviceDetails.deviceResource.model) !== null && tmp_0_0 !== undefined ? tmp_0_0 : "");
    core/* ɵɵadvance */.xp6(1);
    core/* ɵɵtextInterpolate1 */.hij(" ", appStateData_r1.app.settings == null ? null : appStateData_r1.app.settings.deviceDetails == null ? null : appStateData_r1.app.settings.deviceDetails.deviceResource == null ? null : appStateData_r1.app.settings.deviceDetails.deviceResource.model, " ");
    core/* ɵɵadvance */.xp6(1);
    core/* ɵɵproperty */.Q6J("cdkCopyToClipboard", (tmp_2_0 = appStateData_r1.app.settings == null ? null : appStateData_r1.app.settings.deviceDetails == null ? null : appStateData_r1.app.settings.deviceDetails.deviceResource == null ? null : appStateData_r1.app.settings.deviceDetails.deviceResource.model) !== null && tmp_2_0 !== undefined ? tmp_2_0 : "");
    core/* ɵɵadvance */.xp6(7);
    core/* ɵɵproperty */.Q6J("matTooltip", (tmp_3_0 = appStateData_r1.app.settings == null ? null : appStateData_r1.app.settings.deviceDetails == null ? null : appStateData_r1.app.settings.deviceDetails.details == null ? null : appStateData_r1.app.settings.deviceDetails.details.serialNumber) !== null && tmp_3_0 !== undefined ? tmp_3_0 : "");
    core/* ɵɵadvance */.xp6(1);
    core/* ɵɵtextInterpolate1 */.hij(" ", appStateData_r1.app.settings == null ? null : appStateData_r1.app.settings.deviceDetails == null ? null : appStateData_r1.app.settings.deviceDetails.details == null ? null : appStateData_r1.app.settings.deviceDetails.details.serialNumber, " ");
    core/* ɵɵadvance */.xp6(1);
    core/* ɵɵproperty */.Q6J("cdkCopyToClipboard", (tmp_5_0 = appStateData_r1.app.settings == null ? null : appStateData_r1.app.settings.deviceDetails == null ? null : appStateData_r1.app.settings.deviceDetails.details == null ? null : appStateData_r1.app.settings.deviceDetails.details.serialNumber) !== null && tmp_5_0 !== undefined ? tmp_5_0 : "");
    core/* ɵɵadvance */.xp6(7);
    core/* ɵɵproperty */.Q6J("matTooltip", (tmp_6_0 = appStateData_r1.app.settings == null ? null : appStateData_r1.app.settings.deviceDetails == null ? null : appStateData_r1.app.settings.deviceDetails.details == null ? null : appStateData_r1.app.settings.deviceDetails.details.OSVersion) !== null && tmp_6_0 !== undefined ? tmp_6_0 : "");
    core/* ɵɵadvance */.xp6(1);
    core/* ɵɵtextInterpolate1 */.hij(" ", appStateData_r1.app.settings == null ? null : appStateData_r1.app.settings.deviceDetails == null ? null : appStateData_r1.app.settings.deviceDetails.details == null ? null : appStateData_r1.app.settings.deviceDetails.details.OSVersion, " ");
    core/* ɵɵadvance */.xp6(1);
    core/* ɵɵproperty */.Q6J("cdkCopyToClipboard", (tmp_8_0 = appStateData_r1.app.settings == null ? null : appStateData_r1.app.settings.deviceDetails == null ? null : appStateData_r1.app.settings.deviceDetails.details == null ? null : appStateData_r1.app.settings.deviceDetails.details.OSVersion) !== null && tmp_8_0 !== undefined ? tmp_8_0 : "");
    core/* ɵɵadvance */.xp6(7);
    core/* ɵɵproperty */.Q6J("matTooltip", (tmp_9_0 = appStateData_r1.app.settings == null ? null : appStateData_r1.app.settings.deviceDetails == null ? null : appStateData_r1.app.settings.deviceDetails.details == null ? null : appStateData_r1.app.settings.deviceDetails.details.id) !== null && tmp_9_0 !== undefined ? tmp_9_0 : "");
    core/* ɵɵadvance */.xp6(1);
    core/* ɵɵtextInterpolate1 */.hij(" ", appStateData_r1.app.settings == null ? null : appStateData_r1.app.settings.deviceDetails == null ? null : appStateData_r1.app.settings.deviceDetails.details == null ? null : appStateData_r1.app.settings.deviceDetails.details.id, " ");
    core/* ɵɵadvance */.xp6(1);
    core/* ɵɵproperty */.Q6J("cdkCopyToClipboard", (tmp_11_0 = appStateData_r1.app.settings == null ? null : appStateData_r1.app.settings.deviceDetails == null ? null : appStateData_r1.app.settings.deviceDetails.details == null ? null : appStateData_r1.app.settings.deviceDetails.details.id) !== null && tmp_11_0 !== undefined ? tmp_11_0 : "");
  }
}
let DeviceInfoComponent = /*#__PURE__*/(() => {
  class DeviceInfoComponent {
    constructor(appState) {
      this.appState = appState;
    }
    static #_ = this.ɵfac = function DeviceInfoComponent_Factory(t) {
      return new (t || DeviceInfoComponent)(core/* ɵɵdirectiveInject */.Y36(ngrx_store/* Store */.yh));
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/core/* ɵɵdefineComponent */.Xpm({
      type: DeviceInfoComponent,
      selectors: [["app-gb-deviceinfo"]],
      standalone: true,
      features: [core/* ɵɵStandaloneFeature */.jDz],
      decls: 2,
      vars: 3,
      consts: [["class", "app-bg p-4", 4, "ngIf"], [1, "app-bg", "p-4"], [1, "flex", "flex-col", "gap-y-1"], [1, "flex", "justify-between", "items-end"], [1, "flex", "flex-col"], [1, "font-bold", "truncate", "max-w-[200px]", 3, "matTooltip"], ["mat-icon-button", "", 3, "cdkCopyToClipboard"], [1, "text-base"]],
      template: function DeviceInfoComponent_Template(rf, ctx) {
        if (rf & 1) {
          core/* ɵɵtemplate */.YNc(0, DeviceInfoComponent_div_0_Template, 38, 12, "div", 0);
          core/* ɵɵpipe */.ALo(1, "async");
        }
        if (rf & 2) {
          core/* ɵɵproperty */.Q6J("ngIf", core/* ɵɵpipeBind1 */.lcZ(1, 1, ctx.appState));
        }
      },
      dependencies: [common/* CommonModule */.ez, common/* NgIf */.O5, common/* AsyncPipe */.Ov, MaterialModule, fesm2020_button/* MatIconButton */.RK, icon/* MatIcon */.Hw, tooltip/* MatTooltip */.gM, clipboard/* CdkCopyToClipboard */.i3],
      styles: [".app-bg[_ngcontent-%COMP%] {\n  background-color: #f8fafe;\n}"]
    });
  }
  return DeviceInfoComponent;
})();
;// CONCATENATED MODULE: ./apps/gopher-for-chrome/gopher-buddy/src/app/common/external/launcher/launcher.component.ts




















const _c0 = ["helpDrawer"];
function LauncherComponent_div_5_ng_template_8_Template(rf, ctx) {
  if (rf & 1) {
    core/* ɵɵelementStart */.TgZ(0, "mat-icon");
    core/* ɵɵtext */._uU(1, "system_update_alt");
    core/* ɵɵelementEnd */.qZA();
  }
}
const _c1 = function (a0) {
  return {
    appStateData: a0
  };
};
function LauncherComponent_div_5_ng_container_9_Template(rf, ctx) {
  if (rf & 1) {
    core/* ɵɵelementContainer */.GkF(0, 18);
  }
  if (rf & 2) {
    const appStateData_r11 = core/* ɵɵnextContext */.oxw().ngIf;
    core/* ɵɵnextContext */.oxw();
    const _r5 = core/* ɵɵreference */.MAs(13);
    core/* ɵɵproperty */.Q6J("ngTemplateOutlet", _r5)("ngTemplateOutletContext", core/* ɵɵpureFunction1 */.VKq(2, _c1, appStateData_r11));
  }
}
function LauncherComponent_div_5_ng_container_10_Template(rf, ctx) {
  if (rf & 1) {
    core/* ɵɵelementContainer */.GkF(0, 18);
  }
  if (rf & 2) {
    const appStateData_r11 = core/* ɵɵnextContext */.oxw().ngIf;
    const ctx_r15 = core/* ɵɵnextContext */.oxw();
    const _r3 = core/* ɵɵreference */.MAs(11);
    const _r9 = core/* ɵɵreference */.MAs(17);
    const _r7 = core/* ɵɵreference */.MAs(15);
    const _r1 = core/* ɵɵreference */.MAs(9);
    core/* ɵɵproperty */.Q6J("ngTemplateOutlet", ctx_r15.isLoaded(appStateData_r11) ? ctx_r15.isManaged(appStateData_r11) ? ctx_r15.isValidCustomer(appStateData_r11) ? _r3 : _r9 : _r7 : _r1)("ngTemplateOutletContext", core/* ɵɵpureFunction1 */.VKq(2, _c1, appStateData_r11));
  }
}
function LauncherComponent_div_5_ng_template_12_Template(rf, ctx) {
  if (rf & 1) {
    core/* ɵɵelementStart */.TgZ(0, "mat-icon");
    core/* ɵɵtext */._uU(1, "laptop_chromebook");
    core/* ɵɵelementEnd */.qZA();
  }
}
function LauncherComponent_div_5_Template(rf, ctx) {
  if (rf & 1) {
    core/* ɵɵelementStart */.TgZ(0, "div", 11)(1, "mat-drawer-container", 11)(2, "mat-drawer", 12, 13);
    core/* ɵɵelement */._UZ(4, "app-gb-help");
    core/* ɵɵelementEnd */.qZA();
    core/* ɵɵelementStart */.TgZ(5, "mat-drawer-content", 11)(6, "mat-tab-group", 11)(7, "mat-tab", 14);
    core/* ɵɵtemplate */.YNc(8, LauncherComponent_div_5_ng_template_8_Template, 2, 0, "ng-template", 15);
    core/* ɵɵtemplate */.YNc(9, LauncherComponent_div_5_ng_container_9_Template, 1, 4, "ng-container", 16);
    core/* ɵɵtemplate */.YNc(10, LauncherComponent_div_5_ng_container_10_Template, 1, 4, "ng-container", 16);
    core/* ɵɵelementEnd */.qZA();
    core/* ɵɵelementStart */.TgZ(11, "mat-tab", 17);
    core/* ɵɵtemplate */.YNc(12, LauncherComponent_div_5_ng_template_12_Template, 2, 0, "ng-template", 15);
    core/* ɵɵelement */._UZ(13, "app-gb-deviceinfo");
    core/* ɵɵelementEnd */.qZA()()()()();
  }
  if (rf & 2) {
    const appStateData_r11 = ctx.ngIf;
    const ctx_r0 = core/* ɵɵnextContext */.oxw();
    core/* ɵɵadvance */.xp6(9);
    core/* ɵɵproperty */.Q6J("ngIf", ctx_r0.hasErrors(appStateData_r11));
    core/* ɵɵadvance */.xp6(1);
    core/* ɵɵproperty */.Q6J("ngIf", !ctx_r0.hasErrors(appStateData_r11));
    core/* ɵɵadvance */.xp6(1);
    core/* ɵɵproperty */.Q6J("disabled", !ctx_r0.isManaged(appStateData_r11));
  }
}
function LauncherComponent_ng_template_8_Template(rf, ctx) {
  if (rf & 1) {
    core/* ɵɵelementStart */.TgZ(0, "div", 19);
    core/* ɵɵelement */._UZ(1, "div", 20);
    core/* ɵɵelementStart */.TgZ(2, "span", 21);
    core/* ɵɵtext */._uU(3, "Checking In");
    core/* ɵɵelementEnd */.qZA()();
  }
}
function LauncherComponent_ng_template_10_div_1_Template(rf, ctx) {
  if (rf & 1) {
    core/* ɵɵelementStart */.TgZ(0, "div")(1, "p");
    core/* ɵɵtext */._uU(2, " Checking Chrome version");
    core/* ɵɵelement */._UZ(3, "br");
    core/* ɵɵtext */._uU(4, " in Gopher Buddy");
    core/* ɵɵelement */._UZ(5, "br");
    core/* ɵɵtext */._uU(6, " is disabled by your admin ");
    core/* ɵɵelementEnd */.qZA()();
  }
}
function LauncherComponent_ng_template_10_div_2_div_1_Template(rf, ctx) {
  if (rf & 1) {
    core/* ɵɵelementStart */.TgZ(0, "div", 29)(1, "div");
    core/* ɵɵtext */._uU(2, "Gopher Buddy says");
    core/* ɵɵelementEnd */.qZA();
    core/* ɵɵelementStart */.TgZ(3, "div", 21);
    core/* ɵɵtext */._uU(4, "Chrome is up to date!");
    core/* ɵɵelementEnd */.qZA();
    core/* ɵɵelementStart */.TgZ(5, "div");
    core/* ɵɵtext */._uU(6, "\u00A0");
    core/* ɵɵelementEnd */.qZA();
    core/* ɵɵelementStart */.TgZ(7, "div");
    core/* ɵɵtext */._uU(8, "Last Checked:");
    core/* ɵɵelementEnd */.qZA();
    core/* ɵɵelementStart */.TgZ(9, "div", 21);
    core/* ɵɵtext */._uU(10);
    core/* ɵɵpipe */.ALo(11, "date");
    core/* ɵɵelementEnd */.qZA()();
  }
  if (rf & 2) {
    const appState_r20 = core/* ɵɵnextContext */.oxw(2).appStateData;
    const ctx_r24 = core/* ɵɵnextContext */.oxw();
    core/* ɵɵadvance */.xp6(10);
    core/* ɵɵtextInterpolate */.Oqu(core/* ɵɵpipeBind2 */.xi3(11, 1, ctx_r24.lastVersionCheck(appState_r20), "short"));
  }
}
function LauncherComponent_ng_template_10_div_2_div_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r28 = core/* ɵɵgetCurrentView */.EpF();
    core/* ɵɵelementStart */.TgZ(0, "div", 30)(1, "div", 21);
    core/* ɵɵtext */._uU(2, "Chrome needs to update!");
    core/* ɵɵelementEnd */.qZA();
    core/* ɵɵelementStart */.TgZ(3, "div", 19)(4, "div");
    core/* ɵɵtext */._uU(5, "Your version:");
    core/* ɵɵelementEnd */.qZA();
    core/* ɵɵelementStart */.TgZ(6, "div", 21);
    core/* ɵɵtext */._uU(7);
    core/* ɵɵelementEnd */.qZA()();
    core/* ɵɵelementStart */.TgZ(8, "div", 19)(9, "div");
    core/* ɵɵtext */._uU(10, "Newest version:");
    core/* ɵɵelementEnd */.qZA();
    core/* ɵɵelementStart */.TgZ(11, "div", 21);
    core/* ɵɵtext */._uU(12);
    core/* ɵɵelementEnd */.qZA()();
    core/* ɵɵelementStart */.TgZ(13, "button", 31);
    core/* ɵɵlistener */.NdJ("click", function LauncherComponent_ng_template_10_div_2_div_2_Template_button_click_13_listener() {
      core/* ɵɵrestoreView */.CHM(_r28);
      const ctx_r27 = core/* ɵɵnextContext */.oxw(3);
      return core/* ɵɵresetView */.KtG(ctx_r27.onFixVersion());
    });
    core/* ɵɵtext */._uU(14, "Fix it");
    core/* ɵɵelementEnd */.qZA()();
  }
  if (rf & 2) {
    const appState_r20 = core/* ɵɵnextContext */.oxw(2).appStateData;
    core/* ɵɵadvance */.xp6(7);
    core/* ɵɵtextInterpolate */.Oqu(appState_r20.app.settings == null ? null : appState_r20.app.settings.deviceDetails == null ? null : appState_r20.app.settings.deviceDetails.details.OSVersion);
    core/* ɵɵadvance */.xp6(5);
    core/* ɵɵtextInterpolate */.Oqu(appState_r20.app.settings == null ? null : appState_r20.app.settings.deviceDetails.deviceResource == null ? null : appState_r20.app.settings.deviceDetails.deviceResource.latestStableVersion);
  }
}
function LauncherComponent_ng_template_10_div_2_Template(rf, ctx) {
  if (rf & 1) {
    core/* ɵɵelementStart */.TgZ(0, "div");
    core/* ɵɵtemplate */.YNc(1, LauncherComponent_ng_template_10_div_2_div_1_Template, 12, 4, "div", 27);
    core/* ɵɵtemplate */.YNc(2, LauncherComponent_ng_template_10_div_2_div_2_Template, 15, 2, "div", 28);
    core/* ɵɵelementEnd */.qZA();
  }
  if (rf & 2) {
    const appState_r20 = core/* ɵɵnextContext */.oxw().appStateData;
    const ctx_r22 = core/* ɵɵnextContext */.oxw();
    core/* ɵɵadvance */.xp6(1);
    core/* ɵɵproperty */.Q6J("ngIf", ctx_r22.versionIsCurrent(appState_r20));
    core/* ɵɵadvance */.xp6(1);
    core/* ɵɵproperty */.Q6J("ngIf", !ctx_r22.versionIsCurrent(appState_r20));
  }
}
function LauncherComponent_ng_template_10_div_7_Template(rf, ctx) {
  if (rf & 1) {
    const _r32 = core/* ɵɵgetCurrentView */.EpF();
    core/* ɵɵelementStart */.TgZ(0, "div", 2)(1, "button", 32);
    core/* ɵɵlistener */.NdJ("click", function LauncherComponent_ng_template_10_div_7_Template_button_click_1_listener() {
      core/* ɵɵrestoreView */.CHM(_r32);
      const ctx_r31 = core/* ɵɵnextContext */.oxw(2);
      return core/* ɵɵresetView */.KtG(ctx_r31.openDeviceDetails());
    });
    core/* ɵɵtext */._uU(2, "Device info");
    core/* ɵɵelementEnd */.qZA()();
  }
}
function LauncherComponent_ng_template_10_Template(rf, ctx) {
  if (rf & 1) {
    const _r34 = core/* ɵɵgetCurrentView */.EpF();
    core/* ɵɵelementStart */.TgZ(0, "div", 22);
    core/* ɵɵtemplate */.YNc(1, LauncherComponent_ng_template_10_div_1_Template, 7, 0, "div", 23);
    core/* ɵɵtemplate */.YNc(2, LauncherComponent_ng_template_10_div_2_Template, 3, 2, "div", 23);
    core/* ɵɵelementEnd */.qZA();
    core/* ɵɵelementStart */.TgZ(3, "div", 24)(4, "div", 2)(5, "button", 25);
    core/* ɵɵlistener */.NdJ("click", function LauncherComponent_ng_template_10_Template_button_click_5_listener() {
      core/* ɵɵrestoreView */.CHM(_r34);
      const ctx_r33 = core/* ɵɵnextContext */.oxw();
      return core/* ɵɵresetView */.KtG(ctx_r33.clearCache());
    });
    core/* ɵɵtext */._uU(6, "Clear cache");
    core/* ɵɵelementEnd */.qZA()();
    core/* ɵɵtemplate */.YNc(7, LauncherComponent_ng_template_10_div_7_Template, 3, 0, "div", 26);
    core/* ɵɵelementEnd */.qZA();
  }
  if (rf & 2) {
    const appState_r20 = ctx.appStateData;
    const ctx_r4 = core/* ɵɵnextContext */.oxw();
    core/* ɵɵadvance */.xp6(1);
    core/* ɵɵproperty */.Q6J("ngIf", !ctx_r4.checkVersionEnabled(appState_r20));
    core/* ɵɵadvance */.xp6(1);
    core/* ɵɵproperty */.Q6J("ngIf", ctx_r4.checkVersionEnabled(appState_r20));
    core/* ɵɵadvance */.xp6(3);
    core/* ɵɵproperty */.Q6J("disabled", ctx_r4.cacheClearing);
    core/* ɵɵadvance */.xp6(2);
    core/* ɵɵproperty */.Q6J("ngIf", ctx_r4.hasDeviceInfoAccess(appState_r20));
  }
}
function LauncherComponent_ng_template_12_Template(rf, ctx) {
  if (rf & 1) {
    core/* ɵɵelementStart */.TgZ(0, "div", 29)(1, "div");
    core/* ɵɵtext */._uU(2, "Error loading Gopher Buddy ");
    core/* ɵɵelementStart */.TgZ(3, "strong");
    core/* ɵɵtext */._uU(4, ":(");
    core/* ɵɵelementEnd */.qZA()();
    core/* ɵɵelementStart */.TgZ(5, "div");
    core/* ɵɵtext */._uU(6, "We'll keep trying...");
    core/* ɵɵelementEnd */.qZA();
    core/* ɵɵelementStart */.TgZ(7, "div");
    core/* ɵɵtext */._uU(8, "\u00A0");
    core/* ɵɵelementEnd */.qZA();
    core/* ɵɵelementStart */.TgZ(9, "div");
    core/* ɵɵtext */._uU(10, "If you continue to see this message,");
    core/* ɵɵelementEnd */.qZA();
    core/* ɵɵelementStart */.TgZ(11, "div");
    core/* ɵɵtext */._uU(12, "contact your school's computer support");
    core/* ɵɵelementEnd */.qZA();
    core/* ɵɵelementStart */.TgZ(13, "div");
    core/* ɵɵtext */._uU(14, "and let them know.");
    core/* ɵɵelementEnd */.qZA()();
  }
}
function LauncherComponent_ng_template_14_Template(rf, ctx) {
  if (rf & 1) {
    core/* ɵɵelementStart */.TgZ(0, "div", 19)(1, "div");
    core/* ɵɵtext */._uU(2, "Gopher Buddy is an admin tool for");
    core/* ɵɵelementEnd */.qZA();
    core/* ɵɵelementStart */.TgZ(3, "div");
    core/* ɵɵtext */._uU(4, "managed Chromebooks on");
    core/* ɵɵelementEnd */.qZA();
    core/* ɵɵelementStart */.TgZ(5, "div", 21);
    core/* ɵɵtext */._uU(6);
    core/* ɵɵelementEnd */.qZA();
    core/* ɵɵelementStart */.TgZ(7, "div");
    core/* ɵɵtext */._uU(8, "\u00A0");
    core/* ɵɵelementEnd */.qZA();
    core/* ɵɵelementStart */.TgZ(9, "div");
    core/* ɵɵtext */._uU(10, "It performs no actions on Chrome browsers.");
    core/* ɵɵelementEnd */.qZA()();
  }
  if (rf & 2) {
    const appState_r36 = ctx.appStateData;
    core/* ɵɵadvance */.xp6(6);
    core/* ɵɵtextInterpolate */.Oqu(appState_r36.app.settings == null ? null : appState_r36.app.settings.userProfile.userProfile.domain);
  }
}
function LauncherComponent_ng_template_16_Template(rf, ctx) {
  if (rf & 1) {
    core/* ɵɵelementStart */.TgZ(0, "div", 19)(1, "div");
    core/* ɵɵtext */._uU(2, "Gopher Buddy is installed correctly");
    core/* ɵɵelementEnd */.qZA();
    core/* ɵɵelementStart */.TgZ(3, "div");
    core/* ɵɵtext */._uU(4, "on your Chromebook,");
    core/* ɵɵelementEnd */.qZA();
    core/* ɵɵelementStart */.TgZ(5, "div");
    core/* ɵɵtext */._uU(6, "but your school's settings");
    core/* ɵɵelementEnd */.qZA();
    core/* ɵɵelementStart */.TgZ(7, "div");
    core/* ɵɵtext */._uU(8, "may need some help.");
    core/* ɵɵelementEnd */.qZA();
    core/* ɵɵelementStart */.TgZ(9, "div");
    core/* ɵɵtext */._uU(10, "\u00A0");
    core/* ɵɵelementEnd */.qZA();
    core/* ɵɵelementStart */.TgZ(11, "div");
    core/* ɵɵtext */._uU(12, "If you continue to see this message,");
    core/* ɵɵelementEnd */.qZA();
    core/* ɵɵelementStart */.TgZ(13, "div");
    core/* ɵɵtext */._uU(14, "contact your school's computer support");
    core/* ɵɵelementEnd */.qZA();
    core/* ɵɵelementStart */.TgZ(15, "div");
    core/* ɵɵtext */._uU(16, "and let them know.");
    core/* ɵɵelementEnd */.qZA()();
  }
}
let LauncherComponent = /*#__PURE__*/(() => {
  class LauncherComponent {
    constructor(appState, uiService) {
      this.appState = appState;
      this.uiService = uiService;
      this.cacheClearing = false;
      this.isCheckedIn = appState => appState.app.settings?.checkInState.status === StateStatus.SUCCESS;
      this.isLoaded = appState => appState.app.settings?.globalAppFlagsState.isLoaded === true;
      this.isValidCustomer = appState => appState.app.settings?.checkInState.isCustomerValid ?? false;
      this.isManaged = appState => appState.app.settings?.globalAppFlagsState.deviceManagedState === DeviceManagedState.MANAGED;
      this.hasErrors = appState => appState.app.settings?.checkInState.status === StateStatus.FAILED;
      this.hasDeviceInfoAccess = appState => appState.app.settings?.userProfile.userProfile?.accessLevel === UserAccessType.BASIC || appState.app.settings?.userProfile.userProfile?.accessLevel === UserAccessType.FULL;
      this.checkVersionEnabled = appState => appState.app.settings?.customerState.customerSettings?.settings.allowChromeOsUpdateReminders ?? false;
      this.versionIsCurrent = appState => appState.app.settings?.versionUpdateState.updateNeeded === false;
      this.lastVersionCheck = appState => new Date(appState.app.settings?.checkInState.lastCheckIn ?? Date.now());
      this.clearCache = () => {
        this.cacheClearing = true;
        chrome.runtime.sendMessage(GBMessages.CLEAR_CACHE, response => {
          this.cacheClearing = false;
          const message = response.success ? 'Your device cache has successfully been cleared.' : 'Your device cache failed to clear';
          this.uiService.showNotification('clear_cache', message);
        });
      };
      this.openDeviceDetails = () => {
        chrome.runtime.sendMessage(GBMessages.OPEN_DEVICE_INFO, () => {});
      };
      this.openUpdateHelp = () => {
        chrome.runtime.sendMessage(GBMessages.OPEN_HELP, () => {});
      };
      this.onFixVersion = () => {
        chrome.runtime.sendMessage(GBMessages.FIX_VERSION, () => {});
      };
    }
    ngAfterViewInit() {
      var _this = this;
      this.appState.select(getHelpState).subscribe( /*#__PURE__*/function () {
        var _ref = (0,asyncToGenerator/* default */.Z)(function* (helpState) {
          if (helpState) {
            yield _this.helpDrawer.open();
            return;
          }
          yield _this.helpDrawer.close();
        });
        return function (_x) {
          return _ref.apply(this, arguments);
        };
      }());
      // If the user closes the infoDrawer mark all toggle-able Panels as closed.
      this.helpDrawer.openedChange.subscribe(isOpen => {
        if (!isOpen) {
          this.appState.dispatch(toggleHelp({
            open: false
          }));
        }
      });
    }
    static #_ = this.ɵfac = function LauncherComponent_Factory(t) {
      return new (t || LauncherComponent)(core/* ɵɵdirectiveInject */.Y36(ngrx_store/* Store */.yh), core/* ɵɵdirectiveInject */.Y36(UiService));
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/core/* ɵɵdefineComponent */.Xpm({
      type: LauncherComponent,
      selectors: [["app-launcher"]],
      viewQuery: function LauncherComponent_Query(rf, ctx) {
        if (rf & 1) {
          core/* ɵɵviewQuery */.Gf(_c0, 5);
        }
        if (rf & 2) {
          let _t;
          core/* ɵɵqueryRefresh */.iGM(_t = core/* ɵɵloadQuery */.CRH()) && (ctx.helpDrawer = _t.first);
        }
      },
      decls: 18,
      vars: 3,
      consts: [[1, "w-80", "min-h-[485px]", "flex", "flex-col", "rounded-md"], [1, "flex", "flex-col", "grow"], [1, "flex", "justify-center", "items-center"], [1, "flex", "flex-col", "items-center"], ["src", "assets/images/gopher_buddy_logo.png", "alt", "Gopher Buddy Logo", 1, "h-[100px]"], ["class", "!flex flex-col grow", 4, "ngIf"], ["LoadingPanel", ""], ["ValidCustomerPanel", ""], ["ErrorPanel", ""], ["NotManagedPanel", ""], ["NotValidCustomerPanel", ""], [1, "!flex", "flex-col", "grow"], ["mode", "over", "position", "end", 1, "w-[300px]", "p-2"], ["helpDrawer", ""], ["label", "Chrome update info"], ["mat-tab-label", ""], [3, "ngTemplateOutlet", "ngTemplateOutletContext", 4, "ngIf"], ["label", "Your device info", 3, "disabled"], [3, "ngTemplateOutlet", "ngTemplateOutletContext"], [1, "flex", "flex-col", "justify-center", "items-center"], [1, "animate-spin", "rounded-full", "h-12", "w-12", "border-t-2", "border-b-2", "border-gray-600"], [1, "font-bold"], [1, "flex", "flex-col", "flex-justify-center", "items-center"], [4, "ngIf"], [1, "flex", "justify-center", "items-center", "gap-x-2"], ["mat-raised-button", "", 3, "disabled", "click"], ["class", "flex justify-center items-center", 4, "ngIf"], ["class", "flex flex-col justify-center items-center text-base", 4, "ngIf"], ["class", "flex flex-col justify-center items-center gap-y-1 text-base", 4, "ngIf"], [1, "flex", "flex-col", "justify-center", "items-center", "text-base"], [1, "flex", "flex-col", "justify-center", "items-center", "gap-y-1", "text-base"], ["mat-raised-button", "", "color", "primary", 1, "w-full", 3, "click"], ["mat-raised-button", "", 3, "click"]],
      template: function LauncherComponent_Template(rf, ctx) {
        if (rf & 1) {
          core/* ɵɵelementStart */.TgZ(0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "div", 3);
          core/* ɵɵelement */._UZ(4, "img", 4);
          core/* ɵɵelementEnd */.qZA()();
          core/* ɵɵtemplate */.YNc(5, LauncherComponent_div_5_Template, 14, 3, "div", 5);
          core/* ɵɵpipe */.ALo(6, "async");
          core/* ɵɵelement */._UZ(7, "app-gb-footer");
          core/* ɵɵelementEnd */.qZA()();
          core/* ɵɵtemplate */.YNc(8, LauncherComponent_ng_template_8_Template, 4, 0, "ng-template", null, 6, core/* ɵɵtemplateRefExtractor */.W1O);
          core/* ɵɵtemplate */.YNc(10, LauncherComponent_ng_template_10_Template, 8, 4, "ng-template", null, 7, core/* ɵɵtemplateRefExtractor */.W1O);
          core/* ɵɵtemplate */.YNc(12, LauncherComponent_ng_template_12_Template, 15, 0, "ng-template", null, 8, core/* ɵɵtemplateRefExtractor */.W1O);
          core/* ɵɵtemplate */.YNc(14, LauncherComponent_ng_template_14_Template, 11, 1, "ng-template", null, 9, core/* ɵɵtemplateRefExtractor */.W1O);
          core/* ɵɵtemplate */.YNc(16, LauncherComponent_ng_template_16_Template, 17, 0, "ng-template", null, 10, core/* ɵɵtemplateRefExtractor */.W1O);
        }
        if (rf & 2) {
          core/* ɵɵadvance */.xp6(5);
          core/* ɵɵproperty */.Q6J("ngIf", core/* ɵɵpipeBind1 */.lcZ(6, 1, ctx.appState));
        }
      },
      dependencies: [common/* NgIf */.O5, common/* NgTemplateOutlet */.tP, fesm2020_button/* MatButton */.lW, icon/* MatIcon */.Hw, sidenav/* MatDrawer */.jA, sidenav/* MatDrawerContainer */.kh, sidenav/* MatDrawerContent */.LW, tabs/* MatTabLabel */.uD, tabs/* MatTab */.uX, tabs/* MatTabGroup */.SP, GbFooterComponent, HelpComponent, DeviceInfoComponent, common/* AsyncPipe */.Ov, common/* DatePipe */.uU],
      styles: [".mat-mdc-tab-body-wrapper {\n  flex-grow: 1;\n}\n\n  .mat-mdc-tab-body-content {\n  display: flex;\n  flex-direction: column;\n  justify-content: space-around;\n}"]
    });
  }
  return LauncherComponent;
})();
;// CONCATENATED MODULE: ./apps/gopher-for-chrome/gopher-buddy/src/app/app.routes.ts

const appRoutes = [{
  path: '**',
  component: LauncherComponent
}];
;// CONCATENATED MODULE: ./apps/gopher-for-chrome/gopher-buddy/src/app/common/internal/gb-options/gb-options.component.ts

let GbOptionsComponent = /*#__PURE__*/(() => {
  class GbOptionsComponent {
    static #_ = this.ɵfac = function GbOptionsComponent_Factory(t) {
      return new (t || GbOptionsComponent)();
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/core/* ɵɵdefineComponent */.Xpm({
      type: GbOptionsComponent,
      selectors: [["app-gb-options"]],
      decls: 2,
      vars: 0,
      template: function GbOptionsComponent_Template(rf, ctx) {
        if (rf & 1) {
          core/* ɵɵelementStart */.TgZ(0, "p");
          core/* ɵɵtext */._uU(1, "Maybe in the Future we will add a logged in settings page.");
          core/* ɵɵelementEnd */.qZA();
        }
      },
      styles: ["[_nghost-%COMP%] {\n  display: block;\n}"],
      changeDetection: 0
    });
  }
  return GbOptionsComponent;
})();
;// CONCATENATED MODULE: ./apps/gopher-for-chrome/gopher-buddy/src/app/app.module.ts

























let AppModule = /*#__PURE__*/(() => {
  class AppModule {
    constructor(appState) {
      this.appState = appState;
      this.appStateSyncTimer$ = (0,timer/* timer */.H)(5000, 10 * 1000);
      this.appStateSyncTimer$.subscribe(() => {
        appState.dispatch(syncAppState());
      });
    }
    static #_ = this.ɵfac = function AppModule_Factory(t) {
      return new (t || AppModule)(core/* ɵɵinject */.LFG(ngrx_store/* Store */.yh));
    };
    static #_2 = this.ɵmod = /*@__PURE__*/core/* ɵɵdefineNgModule */.oAB({
      type: AppModule,
      bootstrap: [AppComponent]
    });
    static #_3 = this.ɵinj = /*@__PURE__*/core/* ɵɵdefineInjector */.cJS({
      providers: [AppStateService, UiService],
      imports: [platform_browser/* BrowserModule */.b2, router/* RouterModule.forRoot */.Bz.forRoot(appRoutes), ngrx_store/* StoreModule.forRoot */.Aw.forRoot({
        [APP_FEATURE_KEY]: appReducer
      }, {
        metaReducers: [],
        runtimeChecks: {
          strictActionImmutability: true,
          strictStateImmutability: true
        }
      }), ngrx_effects/* EffectsModule.forRoot */.sQ.forRoot([AppEffects]), ngrx_router_store/* StoreRouterConnectingModule.forRoot */.Qi.forRoot(), animations/* BrowserAnimationsModule */.PW, MaterialModule, GbFooterComponent, HelpComponent, DeviceInfoComponent]
    });
  }
  return AppModule;
})();
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && core/* ɵɵsetNgModuleScope */.kYT(AppModule, {
    declarations: [AppComponent, LauncherComponent, GbOptionsComponent],
    imports: [platform_browser/* BrowserModule */.b2, router/* RouterModule */.Bz, ngrx_store/* StoreRootModule */.cr, ngrx_effects/* EffectsRootModule */.pU, ngrx_router_store/* StoreRouterConnectingModule */.Qi, animations/* BrowserAnimationsModule */.PW, MaterialModule, GbFooterComponent, HelpComponent, DeviceInfoComponent]
  });
})();
;// CONCATENATED MODULE: ./apps/gopher-for-chrome/gopher-buddy/src/main.ts


platform_browser/* platformBrowser */.q6().bootstrapModule(AppModule).catch(err => console.error(err));

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = __webpack_modules__;
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/chunk loaded */
/******/ 	(() => {
/******/ 		var deferred = [];
/******/ 		__webpack_require__.O = (result, chunkIds, fn, priority) => {
/******/ 			if(chunkIds) {
/******/ 				priority = priority || 0;
/******/ 				for(var i = deferred.length; i > 0 && deferred[i - 1][2] > priority; i--) deferred[i] = deferred[i - 1];
/******/ 				deferred[i] = [chunkIds, fn, priority];
/******/ 				return;
/******/ 			}
/******/ 			var notFulfilled = Infinity;
/******/ 			for (var i = 0; i < deferred.length; i++) {
/******/ 				var [chunkIds, fn, priority] = deferred[i];
/******/ 				var fulfilled = true;
/******/ 				for (var j = 0; j < chunkIds.length; j++) {
/******/ 					if ((priority & 1 === 0 || notFulfilled >= priority) && Object.keys(__webpack_require__.O).every((key) => (__webpack_require__.O[key](chunkIds[j])))) {
/******/ 						chunkIds.splice(j--, 1);
/******/ 					} else {
/******/ 						fulfilled = false;
/******/ 						if(priority < notFulfilled) notFulfilled = priority;
/******/ 					}
/******/ 				}
/******/ 				if(fulfilled) {
/******/ 					deferred.splice(i--, 1)
/******/ 					var r = fn();
/******/ 					if (r !== undefined) result = r;
/******/ 				}
/******/ 			}
/******/ 			return result;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/jsonp chunk loading */
/******/ 	(() => {
/******/ 		// no baseURI
/******/ 		
/******/ 		// object to store loaded and loading chunks
/******/ 		// undefined = chunk not loaded, null = chunk preloaded/prefetched
/******/ 		// [resolve, reject, Promise] = chunk loading, 0 = chunk loaded
/******/ 		var installedChunks = {
/******/ 			"main": 0
/******/ 		};
/******/ 		
/******/ 		// no chunk on demand loading
/******/ 		
/******/ 		// no prefetching
/******/ 		
/******/ 		// no preloaded
/******/ 		
/******/ 		// no HMR
/******/ 		
/******/ 		// no HMR manifest
/******/ 		
/******/ 		__webpack_require__.O.j = (chunkId) => (installedChunks[chunkId] === 0);
/******/ 		
/******/ 		// install a JSONP callback for chunk loading
/******/ 		var webpackJsonpCallback = (parentChunkLoadingFunction, data) => {
/******/ 			var [chunkIds, moreModules, runtime] = data;
/******/ 			// add "moreModules" to the modules object,
/******/ 			// then flag all "chunkIds" as loaded and fire callback
/******/ 			var moduleId, chunkId, i = 0;
/******/ 			if(chunkIds.some((id) => (installedChunks[id] !== 0))) {
/******/ 				for(moduleId in moreModules) {
/******/ 					if(__webpack_require__.o(moreModules, moduleId)) {
/******/ 						__webpack_require__.m[moduleId] = moreModules[moduleId];
/******/ 					}
/******/ 				}
/******/ 				if(runtime) var result = runtime(__webpack_require__);
/******/ 			}
/******/ 			if(parentChunkLoadingFunction) parentChunkLoadingFunction(data);
/******/ 			for(;i < chunkIds.length; i++) {
/******/ 				chunkId = chunkIds[i];
/******/ 				if(__webpack_require__.o(installedChunks, chunkId) && installedChunks[chunkId]) {
/******/ 					installedChunks[chunkId][0]();
/******/ 				}
/******/ 				installedChunks[chunkId] = 0;
/******/ 			}
/******/ 			return __webpack_require__.O(result);
/******/ 		}
/******/ 		
/******/ 		var chunkLoadingGlobal = self["webpackChunkgopher_buddy_extension"] = self["webpackChunkgopher_buddy_extension"] || [];
/******/ 		chunkLoadingGlobal.forEach(webpackJsonpCallback.bind(null, 0));
/******/ 		chunkLoadingGlobal.push = webpackJsonpCallback.bind(null, chunkLoadingGlobal.push.bind(chunkLoadingGlobal));
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module depends on other loaded chunks and execution need to be delayed
/******/ 	var __webpack_exports__ = __webpack_require__.O(undefined, ["vendor"], () => (__webpack_require__(1308)))
/******/ 	__webpack_exports__ = __webpack_require__.O(__webpack_exports__);
/******/ 	
/******/ })()
;